// Proyecto raíz: solo declara los plugins; se aplican en :app.
// AGP 9 trae Kotlin integrado, por eso NO se usa org.jetbrains.kotlin.android.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
