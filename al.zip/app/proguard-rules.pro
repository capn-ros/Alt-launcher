# El launcher usa reflexión solo sobre clases del framework (StatusBarManager),
# que R8 no ofusca. No hace falta ninguna regla extra por ahora.
-keep class app.al.launcher.widgets.LauncherWidgetView { *; }
