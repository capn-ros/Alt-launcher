package app.yaal.launcher.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class DrawerFoldersTest {

    @Test
    fun `crear y sumar apps a una carpeta`() {
        val one = DrawerFolders.create(emptyList(), "Juegos", "a")
        val two = DrawerFolders.add(one, one[0].id, "b")
        assertEquals(listOf("a", "b"), two[0].keys)
    }

    @Test
    fun `una app esta en una sola carpeta y las vacias desaparecen`() {
        val first = DrawerFolders.create(emptyList(), "Uno", "a")
        val both = DrawerFolders.create(first, "Dos", "a")
        assertEquals(1, both.size)
        assertEquals("Dos", both[0].name)
        assertNull(DrawerFolders.folderOf(DrawerFolders.remove(both, "a"), "a"))
    }

    @Test
    fun `las carpetas sobreviven al JSON`() {
        val settings = LauncherSettings(
            drawerFolders = listOf(DrawerFolder(3, "Redes", listOf("x", "y"))),
            drawerShowSearch = false,
        )
        val restored = LauncherSettings.fromJson(settings.toJson())
        assertEquals(settings.drawerFolders, restored.drawerFolders)
        assertEquals(false, restored.drawerShowSearch)
    }
}
