package app.yaal.launcher.data

import kotlin.test.Test
import kotlin.test.assertEquals
import org.json.JSONObject

class LauncherSettingsTest {

    @Test
    fun jsonRoundTripKeepsValues() {
        val original = LauncherSettings(columns = 6, iconShape = IconShape.CIRCLE, pageEffect = PageEffect.CUBE)
        val restored = LauncherSettings.fromJson(original.toJson())
        assertEquals(6, restored.columns)
        assertEquals(IconShape.CIRCLE, restored.iconShape)
        assertEquals(PageEffect.CUBE, restored.pageEffect)
    }

    @Test
    fun styleOptionsSurviveRoundTrip() {
        val original = LauncherSettings(
            windEffect = false,
            clockStyle = ClockStyle.BLADE,
            pageIndicator = PageIndicator.CURVE,
            drawerStyle = DrawerStyle.ARC,
            radialMenu = false,
        )
        val restored = LauncherSettings.fromJson(original.toJson())
        assertEquals(false, restored.windEffect)
        assertEquals(ClockStyle.BLADE, restored.clockStyle)
        assertEquals(PageIndicator.CURVE, restored.pageIndicator)
        assertEquals(DrawerStyle.ARC, restored.drawerStyle)
        assertEquals(false, restored.radialMenu)
    }

    @Test
    fun emptyJsonGivesDefaults() {
        assertEquals(LauncherSettings().sanitized(), LauncherSettings.fromJson(JSONObject()).sanitized())
    }

    @Test
    fun unknownEnumFallsBackToDefault() {
        val json = LauncherSettings().toJson().put("iconShape", "NOPE")
        assertEquals(LauncherSettings().iconShape, LauncherSettings.fromJson(json).iconShape)
    }

    @Test
    fun sanitizedClampsRanges() {
        val s = LauncherSettings(columns = 99, rows = 0).sanitized()
        assertEquals(6, s.columns)
        assert(s.rows >= 1)
    }
}
