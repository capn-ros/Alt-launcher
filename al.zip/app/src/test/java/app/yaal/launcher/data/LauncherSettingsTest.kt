package app.yaal.launcher.data

import kotlin.test.Test
import kotlin.test.assertEquals
import org.json.JSONObject

class LauncherSettingsTest {

    @Test
    fun jsonRoundTripKeepsValues() {
        val original = LauncherSettings(columns = 6, iconShape = IconShape.CIRCLE, pageEffect = PageEffect.CUBE)
        val restored = LauncherSettings.fromJson(original.toJson())
        assertEquals(6, restored.columns)
        assertEquals(IconShape.CIRCLE, restored.iconShape)
        assertEquals(PageEffect.CUBE, restored.pageEffect)
    }

    @Test
    fun emptyJsonGivesDefaults() {
        assertEquals(LauncherSettings().sanitized(), LauncherSettings.fromJson(JSONObject()).sanitized())
    }

    @Test
    fun unknownEnumFallsBackToDefault() {
        val json = LauncherSettings().toJson().put("iconShape", "NOPE")
        assertEquals(LauncherSettings().iconShape, LauncherSettings.fromJson(json).iconShape)
    }

    @Test
    fun sanitizedClampsRanges() {
        val s = LauncherSettings(columns = 99, rows = 0).sanitized()
        assertEquals(6, s.columns)
        assert(s.rows >= 1)
    }
}
