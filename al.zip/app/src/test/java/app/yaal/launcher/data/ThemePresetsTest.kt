package app.yaal.launcher.data

import kotlin.test.Test
import kotlin.test.assertEquals

class ThemePresetsTest {

    @Test
    fun `aplicar un tema no toca el escritorio ni los datos del usuario`() {
        val mine = LauncherSettings(
            columns = 5,
            rows = 6,
            hidden = setOf("x"),
            labels = mapOf("a" to "Mi app"),
            drawerFolders = listOf(DrawerFolder(1, "Redes", listOf("a", "b"))),
        )
        val themed = ThemePresets.apply(ThemeId.SENSE, mine)
        assertEquals(5, themed.columns)
        assertEquals(6, themed.rows)
        assertEquals(mine.hidden, themed.hidden)
        assertEquals(mine.labels, themed.labels)
        assertEquals(mine.drawerFolders, themed.drawerFolders)
        assertEquals(DockStyle.SENSE, themed.dockStyle)
        assertEquals(ThemeId.SENSE, themed.theme)
    }

    @Test
    fun `volver al tema Yaal limpia lo que puso otro tema`() {
        val back = ThemePresets.apply(ThemeId.YAAL, ThemePresets.apply(ThemeId.HOLO, LauncherSettings()))
        assertEquals(DockStyle.FLOATING, back.dockStyle)
        assertEquals(DrawerStyle.GRID, back.drawerStyle)
        assertEquals(null, back.accentColor)
    }

    @Test
    fun `el tema sobrevive al JSON`() {
        val themed = ThemePresets.apply(ThemeId.MIUI, LauncherSettings())
        val restored = LauncherSettings.fromJson(themed.toJson())
        assertEquals(themed.accentColor, restored.accentColor)
        assertEquals(IconShape.SQUIRCLE, restored.iconShape)
    }
}
