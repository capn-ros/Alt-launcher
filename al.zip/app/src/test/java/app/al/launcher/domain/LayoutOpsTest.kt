package app.al.launcher.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class LayoutOpsTest {

    private val grid = GridSpec(columns = 4, rows = 5, dockSlots = 5)

    private fun app(id: Long, key: String, x: Int, y: Int, page: Int = 0) = HomeItem(
        id = id, kind = ItemKind.APP, container = Container.DESKTOP,
        page = page, x = x, y = y, appKey = key,
    )

    @Test
    fun `soltar una app sobre otra crea una carpeta`() {
        val a = app(1, "a", 0, 0)
        val b = app(2, "b", 1, 0)
        val result = assertNotNull(LayoutOps.placeOnDesktop(listOf(a, b), b, 0, 0, 0, grid))
        val folder = result.single()
        assertEquals(ItemKind.FOLDER, folder.kind)
        assertEquals(listOf("a", "b"), folder.children)
        assertEquals(0, folder.x)
    }

    @Test
    fun `soltar una app sobre una carpeta la agrega`() {
        val folder = HomeItem(
            id = 1, kind = ItemKind.FOLDER, container = Container.DESKTOP,
            children = listOf("a", "b"),
        )
        val c = app(2, "c", 2, 2)
        val result = assertNotNull(LayoutOps.placeOnDesktop(listOf(folder, c), c, 0, 0, 0, grid))
        assertEquals(listOf("a", "b", "c"), result.single().children)
    }

    @Test
    fun `una carpeta con un solo hijo vuelve a ser app`() {
        val folder = HomeItem(
            id = 1, kind = ItemKind.FOLDER, container = Container.DESKTOP,
            children = listOf("a", "b"),
        )
        val result = LayoutOps.removeChild(listOf(folder), 1, "b").single()
        assertEquals(ItemKind.APP, result.kind)
        assertEquals("a", result.appKey)
    }

    @Test
    fun `una carpeta vacia desaparece`() {
        val folder = HomeItem(
            id = 1, kind = ItemKind.FOLDER, container = Container.DESKTOP,
            children = listOf("a"),
        )
        assertTrue(LayoutOps.removeChild(listOf(folder), 1, "a").isEmpty())
    }

    @Test
    fun `mover a una celda ocupada por un widget busca otro hueco`() {
        val widget = HomeItem(
            id = 1, kind = ItemKind.WIDGET, container = Container.DESKTOP,
            x = 0, y = 0, spanX = 4, spanY = 2, widgetId = 7,
        )
        val a = app(2, "a", 0, 4)
        val result = assertNotNull(LayoutOps.placeOnDesktop(listOf(widget, a), a, 0, 1, 1, grid))
        val moved = result.first { it.id == 2L }
        assertTrue(moved.y >= 2, "no debe superponerse con el widget")
    }

    @Test
    fun `una pagina llena manda la app a la pagina siguiente`() {
        val full = (0 until grid.columns * grid.rows).map { app(it + 1L, "k$it", it % grid.columns, it / grid.columns) }
        val extra = HomeItem(id = 100, kind = ItemKind.APP, container = Container.DESKTOP, appKey = "extra")
        val result = assertNotNull(LayoutOps.addAtFree(full, extra, 0, grid))
        assertEquals(1, result.last().page)
    }

    @Test
    fun `el dock rechaza widgets`() {
        val widget = HomeItem(id = 1, kind = ItemKind.WIDGET, container = Container.DESKTOP, widgetId = 3)
        assertNull(LayoutOps.placeInDock(listOf(widget), widget, 0, grid))
    }

    @Test
    fun `el dock lleno reubica en una ranura libre o falla`() {
        val dock = (0 until grid.dockSlots).map {
            HomeItem(id = it + 1L, kind = ItemKind.APP, container = Container.DOCK, x = it, appKey = "d$it")
        }
        val newcomer = HomeItem(id = 50, kind = ItemKind.APP, container = Container.DESKTOP, appKey = "n")
        // Soltar sobre una app del dock crea una carpeta: es válido incluso con el dock lleno.
        val merged = assertNotNull(LayoutOps.placeInDock(dock + newcomer, newcomer, 2, grid))
        assertEquals(ItemKind.FOLDER, merged.first { it.x == 2 && it.container == Container.DOCK }.kind)
    }

    @Test
    fun `redimensionar falla si choca con otro elemento`() {
        val widget = HomeItem(
            id = 1, kind = ItemKind.WIDGET, container = Container.DESKTOP,
            x = 0, y = 0, spanX = 2, spanY = 2, widgetId = 3,
        )
        val blocker = app(2, "a", 2, 0)
        assertNull(LayoutOps.resize(listOf(widget, blocker), 1, 3, 2, grid))
        assertNotNull(LayoutOps.resize(listOf(widget, blocker), 1, 2, 3, grid))
    }

    @Test
    fun `desinstalar un paquete limpia apps y carpetas`() {
        val keep = app(1, "com.keep/.Main@0", 0, 0)
        val gone = app(2, "com.gone/.Main@0", 1, 0)
        val folder = HomeItem(
            id = 3, kind = ItemKind.FOLDER, container = Container.DESKTOP, x = 2,
            children = listOf("com.gone/.A@0", "com.keep/.B@0", "com.keep/.C@0"),
        )
        val result = LayoutOps.removePackage(listOf(keep, gone, folder), "com.gone")
        assertEquals(2, result.size)
        assertEquals(listOf("com.keep/.B@0", "com.keep/.C@0"), result.first { it.id == 3L }.children)
    }

    @Test
    fun `achicar la grilla reacomoda lo que no entra`() {
        val items = listOf(app(1, "a", 3, 4), app(2, "b", 0, 0))
        val smaller = GridSpec(columns = 3, rows = 4, dockSlots = 4)
        val fitted = LayoutOps.fit(items, smaller)
        assertEquals(2, fitted.size)
        fitted.forEach { assertTrue(it.x < 3 && it.y < 4) }
    }

    @Test
    fun `el recuento de paginas nunca es menor a uno`() {
        assertEquals(1, LayoutOps.pageCount(emptyList()))
        assertEquals(3, LayoutOps.pageCount(listOf(app(1, "a", 0, 0, page = 2))))
    }
}
