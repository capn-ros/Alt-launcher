package app.al.launcher.data

import android.content.Context
import app.al.launcher.domain.GridSpec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LauncherSettings(
    val columns: Int = 4,
    val rows: Int = 5,
    val dockSlots: Int = 5,
    val iconScale: Float = 1f,
    val showLabels: Boolean = true,
    val drawerColumns: Int = 4,
    val hidden: Set<String> = emptySet(),
    val swipeDownNotifications: Boolean = true,
    val lockLayout: Boolean = false,
) {
    fun grid() = GridSpec(columns, rows, dockSlots)

    fun sanitized() = copy(
        columns = columns.coerceIn(3, 6),
        rows = rows.coerceIn(4, 8),
        dockSlots = dockSlots.coerceIn(3, 6),
        iconScale = iconScale.coerceIn(0.7f, 1.4f),
        drawerColumns = drawerColumns.coerceIn(3, 6),
    )
}

/** Ajustes persistidos en SharedPreferences y expuestos como StateFlow. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("al_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    fun update(transform: (LauncherSettings) -> LauncherSettings) {
        val next = transform(_settings.value).sanitized()
        if (next == _settings.value) return
        _settings.value = next
        write(next)
    }

    private fun read(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            columns = prefs.getInt("columns", d.columns),
            rows = prefs.getInt("rows", d.rows),
            dockSlots = prefs.getInt("dockSlots", d.dockSlots),
            iconScale = prefs.getFloat("iconScale", d.iconScale),
            showLabels = prefs.getBoolean("showLabels", d.showLabels),
            drawerColumns = prefs.getInt("drawerColumns", d.drawerColumns),
            hidden = prefs.getStringSet("hidden", emptySet())?.toSet().orEmpty(),
            swipeDownNotifications = prefs.getBoolean("swipeDown", d.swipeDownNotifications),
            lockLayout = prefs.getBoolean("lockLayout", d.lockLayout),
        ).sanitized()
    }

    private fun write(s: LauncherSettings) {
        prefs.edit()
            .putInt("columns", s.columns)
            .putInt("rows", s.rows)
            .putInt("dockSlots", s.dockSlots)
            .putFloat("iconScale", s.iconScale)
            .putBoolean("showLabels", s.showLabels)
            .putInt("drawerColumns", s.drawerColumns)
            .putStringSet("hidden", s.hidden.toSet())
            .putBoolean("swipeDown", s.swipeDownNotifications)
            .putBoolean("lockLayout", s.lockLayout)
            .apply()
    }
}
