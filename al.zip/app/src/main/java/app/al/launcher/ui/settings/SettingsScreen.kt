package app.al.launcher.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.al.launcher.R
import app.al.launcher.data.AppEntry
import app.al.launcher.data.LauncherSettings
import app.al.launcher.ui.common.StepperRow
import app.al.launcher.ui.common.SwitchRow

@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    hiddenApps: List<AppEntry>,
    onUpdate: ((LauncherSettings) -> LauncherSettings) -> Unit,
    onShowApp: (AppEntry) -> Unit,
    onDefaultLauncher: () -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF20E1217))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onClose) { Text(stringResource(R.string.done)) }
        }
        HorizontalDivider()

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            StepperRow(stringResource(R.string.set_columns), settings.columns, 3..6) { v ->
                onUpdate { it.copy(columns = v) }
            }
            StepperRow(stringResource(R.string.set_rows), settings.rows, 4..8) { v ->
                onUpdate { it.copy(rows = v) }
            }
            StepperRow(stringResource(R.string.set_dock), settings.dockSlots, 3..6) { v ->
                onUpdate { it.copy(dockSlots = v) }
            }
            StepperRow(stringResource(R.string.set_drawer_cols), settings.drawerColumns, 3..6) { v ->
                onUpdate { it.copy(drawerColumns = v) }
            }

            Text(
                text = stringResource(R.string.set_icon_size),
                modifier = Modifier.padding(top = 8.dp),
            )
            Slider(
                value = settings.iconScale,
                onValueChange = { v -> onUpdate { it.copy(iconScale = v) } },
                valueRange = 0.7f..1.4f,
            )

            SwitchRow(stringResource(R.string.set_labels), settings.showLabels) { v ->
                onUpdate { it.copy(showLabels = v) }
            }
            SwitchRow(stringResource(R.string.set_swipe_down), settings.swipeDownNotifications) { v ->
                onUpdate { it.copy(swipeDownNotifications = v) }
            }
            SwitchRow(stringResource(R.string.set_lock), settings.lockLayout) { v ->
                onUpdate { it.copy(lockLayout = v) }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(
                text = stringResource(R.string.set_hidden),
                style = MaterialTheme.typography.titleMedium,
            )
            if (hiddenApps.isEmpty()) {
                Text(
                    text = stringResource(R.string.set_hidden_none),
                    color = Color.White.copy(alpha = 0.6f),
                )
            } else {
                hiddenApps.forEach { app ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(text = app.label, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onShowApp(app) }) { Text(stringResource(R.string.set_show)) }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            OutlinedButton(onClick = onDefaultLauncher, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.set_default))
            }
            Button(
                onClick = {
                    if (confirmReset) {
                        confirmReset = false
                        onReset()
                    } else {
                        confirmReset = true
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    stringResource(if (confirmReset) R.string.set_reset_confirm else R.string.set_reset),
                )
            }
        }
    }
}
