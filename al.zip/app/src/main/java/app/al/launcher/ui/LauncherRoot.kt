package app.al.launcher.ui

import android.appwidget.AppWidgetProviderInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.al.launcher.R
import app.al.launcher.data.AppEntry
import app.al.launcher.data.LauncherSettings
import app.al.launcher.domain.Container
import app.al.launcher.domain.HomeItem
import app.al.launcher.domain.ItemKind
import app.al.launcher.domain.LayoutOps
import app.al.launcher.ui.drawer.AppDrawer
import app.al.launcher.ui.home.AppCell
import app.al.launcher.ui.home.AppIcon
import app.al.launcher.ui.home.DragController
import app.al.launcher.ui.home.DragPayload
import app.al.launcher.ui.home.DragRelease
import app.al.launcher.ui.home.DropTarget
import app.al.launcher.ui.home.FolderCell
import app.al.launcher.ui.home.FolderPopup
import app.al.launcher.ui.home.WidgetItem
import app.al.launcher.ui.home.dragSource
import app.al.launcher.ui.menu.ActionSheet
import app.al.launcher.ui.menu.SheetAction
import app.al.launcher.ui.settings.SettingsScreen
import app.al.launcher.ui.widgets.ResizeDialog
import app.al.launcher.ui.widgets.WidgetPicker
import app.al.launcher.util.SystemActions
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** Qué elemento tiene abierto el menú contextual. */
private sealed interface SheetTarget {
    data class OnHomeItem(val item: HomeItem) : SheetTarget
    data class OnDrawerApp(val entry: AppEntry) : SheetTarget
}

private val BaseIconSize = 56.dp
private val DockIconSize = 52.dp

/**
 * Pantalla del launcher: escritorio con páginas, dock, cajón de apps, carpetas, menús y ajustes.
 * Todo el arrastre (escritorio, dock, cajón, carpetas, widgets) pasa por un único [DragController].
 */
@Composable
fun LauncherRoot(vm: LauncherViewModel, onPickWidget: (AppWidgetProviderInfo) -> Unit) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val settings by vm.settings.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val appsByKey by vm.appsByKey.collectAsStateWithLifecycle()
    val visibleApps by vm.visibleApps.collectAsStateWithLifecycle()
    val hiddenApps by vm.hiddenApps.collectAsStateWithLifecycle()
    val grid = settings.grid()

    val drag = remember { DragController() }
    val drawer = remember { Animatable(0f) }
    val drawerVisible by remember { derivedStateOf { drawer.value > 0.001f } }

    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    var gridBounds by remember { mutableStateOf(Rect.Zero) }
    var dockBounds by remember { mutableStateOf(Rect.Zero) }
    var openFolderId by remember { mutableStateOf<Long?>(null) }
    var sheet by remember { mutableStateOf<SheetTarget?>(null) }
    var showDesktopMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showWidgets by remember { mutableStateOf(false) }
    var resizeItemId by remember { mutableStateOf<Long?>(null) }
    var lastDrawerDy by remember { mutableFloatStateOf(0f) }

    val pageCount = LayoutOps.pageCount(items) + if (drag.active) 1 else 0
    val pagerState = rememberPagerState(pageCount = { pageCount })

    val statusTopPx = WindowInsets.statusBars.getTop(density)
    val topZonePx = statusTopPx + with(density) { 72.dp.toPx() }

    // ---------------------------------------------------------------- cajón

    val drawerHeightPx = rootSize.height.toFloat().coerceAtLeast(1f)
    val dragDrawer: (Float) -> Unit = { dy ->
        lastDrawerDy = dy
        scope.launch { drawer.snapTo((drawer.value - dy / drawerHeightPx).coerceIn(0f, 1f)) }
    }
    val settleDrawer: () -> Unit = {
        scope.launch {
            val value = drawer.value
            val open = when {
                lastDrawerDy < -2f -> value > 0.08f
                lastDrawerDy > 2f -> value > 0.92f
                else -> value > 0.5f
            }
            drawer.animateTo(if (open) 1f else 0f, tween(220))
        }
    }
    val currentDragDrawer by rememberUpdatedState(dragDrawer)
    val currentSettleDrawer by rememberUpdatedState(settleDrawer)

    // ---------------------------------------------------------------- arrastre

    fun entryOf(payload: DragPayload): AppEntry? = when (payload) {
        is DragPayload.Home -> payload.item.appKey?.let { appsByKey[it] }
        is DragPayload.Drawer -> payload.entry
        is DragPayload.FolderChild -> payload.entry
    }

    fun resolveTarget(payload: DragPayload, pos: Offset): DropTarget {
        if (pos.y < topZonePx) {
            val third = (pos.x / rootSize.width.coerceAtLeast(1) * 3).toInt()
            return when (third) {
                0 -> DropTarget.Remove
                1 -> DropTarget.Info
                else -> DropTarget.Uninstall
            }
        }
        if (dockBounds.contains(pos)) {
            val slot = ((pos.x - dockBounds.left) / dockBounds.width * grid.dockSlots).toInt()
            return DropTarget.Dock(slot.coerceIn(0, grid.dockSlots - 1))
        }
        if (gridBounds.contains(pos)) {
            val cellW = gridBounds.width / grid.columns
            val cellH = gridBounds.height / grid.rows
            var cx = ((pos.x - gridBounds.left) / cellW).toInt()
            var cy = ((pos.y - gridBounds.top) / cellH).toInt()
            if (payload is DragPayload.Home && payload.item.kind == ItemKind.WIDGET) {
                // El widget se centra bajo el dedo en vez de colgar de su esquina.
                cx -= payload.item.spanX / 2
                cy -= payload.item.spanY / 2
            }
            return DropTarget.Desktop(
                page = pagerState.currentPage,
                x = cx.coerceIn(0, grid.columns - 1),
                y = cy.coerceIn(0, grid.rows - 1),
            )
        }
        return DropTarget.None
    }

    val onRelease: DragRelease = { payload, pos, moved ->
        if (!moved) {
            // Mantener apretado y soltar sin mover: menú contextual.
            when (payload) {
                is DragPayload.Home -> sheet = SheetTarget.OnHomeItem(payload.item)
                is DragPayload.Drawer -> sheet = SheetTarget.OnDrawerApp(payload.entry)
                is DragPayload.FolderChild -> Unit
            }
        } else {
            when (val target = resolveTarget(payload, pos)) {
                DropTarget.Remove -> if (payload is DragPayload.Home) vm.removeItem(payload.item)
                DropTarget.Info -> entryOf(payload)?.let { vm.showAppInfo(it) }
                DropTarget.Uninstall -> entryOf(payload)?.let { vm.uninstall(it) }
                is DropTarget.Desktop -> vm.drop(payload, target)
                is DropTarget.Dock -> vm.drop(payload, target)
                DropTarget.None -> Unit
            }
            if (payload is DragPayload.FolderChild) openFolderId = null
        }
    }

    // ---------------------------------------------------------------- efectos

    LaunchedEffect(pagerState.currentPage) { vm.currentPage = pagerState.currentPage }

    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(context, context.getString(it), Toast.LENGTH_SHORT).show() }
    }

    LaunchedEffect(Unit) {
        vm.homeEvents.collect {
            openFolderId = null
            sheet = null
            showDesktopMenu = false
            showSettings = false
            showWidgets = false
            resizeItemId = null
            drawer.animateTo(0f, tween(200))
            pagerState.animateScrollToPage(0)
        }
    }

    // Arrastrar una app del cajón hacia el escritorio: el cajón se retira.
    LaunchedEffect(drag.payload) {
        if (drag.payload is DragPayload.Drawer) drawer.animateTo(0f, tween(180))
    }

    // Mantener el dedo en un borde mientras se arrastra cambia de página.
    LaunchedEffect(drag.active) {
        if (!drag.active) return@LaunchedEffect
        val edge = with(density) { 40.dp.toPx() }
        snapshotFlow {
            val x = drag.position.x
            when {
                x < edge -> -1
                x > rootSize.width - edge -> 1
                else -> 0
            }
        }.collectLatest { direction ->
            if (direction != 0) {
                while (true) {
                    delay(650)
                    val y = drag.position.y
                    if (y > topZonePx && y < dockBounds.top) {
                        val target = pagerState.currentPage + direction
                        if (target in 0 until pagerState.pageCount) pagerState.animateScrollToPage(target)
                    }
                }
            }
        }
    }

    BackHandler(enabled = drawerVisible) {
        scope.launch { drawer.animateTo(0f, tween(200)) }
    }
    BackHandler(enabled = !drawerVisible) {
        scope.launch { pagerState.animateScrollToPage(0) }
    }

    // ---------------------------------------------------------------- interfaz

    val iconSize = BaseIconSize * settings.iconScale
    val cellWidthDp = with(density) { (gridBounds.width / grid.columns).toDp() }
    val cellHeightDp = with(density) { (gridBounds.height / grid.rows).toDp() }

    Box(modifier = Modifier.fillMaxSize().onSizeChanged { rootSize = it }) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.10f)))

        // Capa del escritorio; se desvanece al abrirse el cajón.
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = 1f - drawer.value }
                .statusBarsPadding(),
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onGloballyPositioned { coordinates ->
                        val bounds = coordinates.boundsInWindow()
                        gridBounds = bounds
                        vm.cellWidthPx = bounds.width / grid.columns
                        vm.cellHeightPx = bounds.height / grid.rows
                    }
                    .pointerInput(settings.swipeDownNotifications) {
                        // Deslizar hacia arriba abre el cajón; hacia abajo, las notificaciones.
                        var total = 0f
                        val notifyThreshold = 96.dp.toPx()
                        detectVerticalDragGestures(
                            onDragStart = {
                                total = 0f
                                lastDrawerDy = 0f
                            },
                            onDragEnd = {
                                if (total > notifyThreshold && settings.swipeDownNotifications && drawer.value < 0.01f) {
                                    SystemActions.expandNotifications(context)
                                } else {
                                    currentSettleDrawer()
                                }
                            },
                            onDragCancel = { currentSettleDrawer() },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                total += dy
                                currentDragDrawer(dy)
                            },
                        )
                    },
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    userScrollEnabled = !drag.active,
                ) { page ->
                    DesktopPage(
                        page = page,
                        items = items.filter { it.container == Container.DESKTOP && it.page == page },
                        appsByKey = appsByKey,
                        settings = settings,
                        drag = drag,
                        iconSize = iconSize,
                        onLongPressEmpty = { showDesktopMenu = true },
                        onLaunch = { vm.launch(it) },
                        onOpenFolder = { openFolderId = it.id },
                        onRelease = onRelease,
                        onMissingWidget = { vm.removeItem(it) },
                    )
                }
            }

            PageDots(count = pageCount, current = pagerState.currentPage)

            Box(modifier = Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color.Black.copy(alpha = 0.22f))
                        .onGloballyPositioned { dockBounds = it.boundsInWindow() }
                        .padding(vertical = 6.dp),
                ) {
                    for (slot in 0 until grid.dockSlots) {
                        Box(
                            modifier = Modifier.weight(1f).height(72.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            val item = items.firstOrNull { it.container == Container.DOCK && it.x == slot }
                            if (item != null) {
                                PlacedItem(
                                    item = item,
                                    appsByKey = appsByKey,
                                    drag = drag,
                                    lock = settings.lockLayout,
                                    iconSize = DockIconSize * settings.iconScale,
                                    showLabel = false,
                                    onLaunch = { vm.launch(it) },
                                    onOpenFolder = { openFolderId = it.id },
                                    onRelease = onRelease,
                                    modifier = Modifier,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (drawerVisible || drag.payload is DragPayload.Drawer) {
            AppDrawer(
                apps = visibleApps,
                columns = settings.drawerColumns,
                iconScale = settings.iconScale,
                showLabels = settings.showLabels,
                progress = { drawer.value },
                drag = drag,
                onLaunch = { vm.launch(it) },
                onRelease = onRelease,
                onDrawerDrag = dragDrawer,
                onDrawerSettle = settleDrawer,
            )
        }

        val openFolder = openFolderId?.let { id -> items.firstOrNull { it.id == id } }
        if (openFolderId != null && openFolder == null) {
            LaunchedEffect(openFolderId) { openFolderId = null }
        }
        if (openFolder != null) {
            FolderPopup(
                folder = openFolder,
                entries = openFolder.children.mapNotNull { appsByKey[it] },
                drag = drag,
                iconSize = iconSize,
                onLaunch = { entry ->
                    openFolderId = null
                    vm.launch(entry)
                },
                onRelease = onRelease,
                onRename = { title -> vm.renameFolder(openFolder.id, title) },
                onDismiss = { openFolderId = null },
            )
        }

        sheet?.let { target ->
            val dismiss = { sheet = null }
            when (target) {
                is SheetTarget.OnDrawerApp -> AppSheet(
                    vm = vm,
                    entry = target.entry,
                    fromDrawer = true,
                    homeItem = null,
                    onAddedToDesktop = { scope.launch { drawer.animateTo(0f, tween(200)) } },
                    onDismiss = dismiss,
                )
                is SheetTarget.OnHomeItem -> {
                    val item = target.item
                    val entry = item.appKey?.let { appsByKey[it] }
                    when {
                        item.kind == ItemKind.APP && entry != null -> AppSheet(
                            vm = vm,
                            entry = entry,
                            fromDrawer = false,
                            homeItem = item,
                            onAddedToDesktop = {},
                            onDismiss = dismiss,
                        )
                        item.kind == ItemKind.FOLDER -> {
                            val rename = stringResource(R.string.menu_rename)
                            val remove = stringResource(R.string.menu_remove)
                            ActionSheet(
                                title = item.title.ifBlank { stringResource(R.string.folder_default) },
                                actions = listOf(
                                    SheetAction(rename) { openFolderId = item.id },
                                    SheetAction(remove, destructive = true) { vm.removeItem(item) },
                                ),
                                onDismiss = dismiss,
                            )
                        }
                        item.kind == ItemKind.WIDGET -> {
                            val resize = stringResource(R.string.menu_resize)
                            val remove = stringResource(R.string.menu_remove)
                            ActionSheet(
                                title = "",
                                actions = listOf(
                                    SheetAction(resize) { resizeItemId = item.id },
                                    SheetAction(remove, destructive = true) { vm.removeItem(item) },
                                ),
                                onDismiss = dismiss,
                            )
                        }
                        else -> LaunchedEffect(target) { sheet = null }
                    }
                }
            }
        }

        if (showDesktopMenu) {
            val widgets = stringResource(R.string.menu_widgets)
            val wallpaper = stringResource(R.string.menu_wallpaper)
            val settingsLabel = stringResource(R.string.menu_settings)
            ActionSheet(
                title = "",
                actions = listOf(
                    SheetAction(widgets) { showWidgets = true },
                    SheetAction(wallpaper) { SystemActions.openWallpaperPicker(context) },
                    SheetAction(settingsLabel) { showSettings = true },
                ),
                onDismiss = { showDesktopMenu = false },
            )
        }

        if (showWidgets) {
            WidgetPicker(
                onPick = { info ->
                    showWidgets = false
                    onPickWidget(info)
                },
                onDismiss = { showWidgets = false },
            )
        }

        if (showSettings) {
            SettingsScreen(
                settings = settings,
                hiddenApps = hiddenApps,
                onUpdate = { transform -> vm.updateSettings(transform) },
                onShowApp = { vm.showApp(it) },
                onDefaultLauncher = { SystemActions.openDefaultLauncherSettings(context) },
                onReset = {
                    vm.resetLayout()
                    showSettings = false
                },
                onClose = { showSettings = false },
            )
        }

        val resizeItem = resizeItemId?.let { id -> items.firstOrNull { it.id == id } }
        if (resizeItem != null) {
            ResizeDialog(
                item = resizeItem,
                grid = grid,
                onApply = { spanX, spanY -> if (vm.resize(resizeItem, spanX, spanY)) resizeItemId = null },
                onDismiss = { resizeItemId = null },
            )
        }

        if (drag.active) {
            TopDropZones(drag = drag, zoneHeightPx = topZonePx, rootWidthPx = rootSize.width)
            DragGhost(
                drag = drag,
                appsByKey = appsByKey,
                iconSize = iconSize,
                cellWidth = cellWidthDp,
                cellHeight = cellHeightDp,
            )
        }
    }
}

// ---------------------------------------------------------------------- piezas

@Composable
private fun DesktopPage(
    page: Int,
    items: List<HomeItem>,
    appsByKey: Map<String, AppEntry>,
    settings: LauncherSettings,
    drag: DragController,
    iconSize: Dp,
    onLongPressEmpty: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onOpenFolder: (HomeItem) -> Unit,
    onRelease: DragRelease,
    onMissingWidget: (HomeItem) -> Unit,
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val cellW = maxWidth / settings.columns
        val cellH = maxHeight / settings.rows

        // Fondo: mantener apretado en un lugar vacío abre el menú del escritorio.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(page) { detectTapGestures(onLongPress = { onLongPressEmpty() }) },
        )

        items.forEach { item ->
            key(item.id) {
                val frame = Modifier
                    .offset(cellW * item.x, cellH * item.y)
                    .size(cellW * item.spanX, cellH * item.spanY)
                if (item.kind == ItemKind.WIDGET) {
                    val hidden = (drag.payload as? DragPayload.Home)?.item?.id == item.id
                    WidgetItem(
                        item = item,
                        drag = drag,
                        dragEnabled = !settings.lockLayout,
                        width = cellW * item.spanX,
                        height = cellH * item.spanY,
                        onRelease = onRelease,
                        onMissing = { onMissingWidget(item) },
                        modifier = frame.graphicsLayer { alpha = if (hidden) 0f else 1f },
                    )
                } else {
                    PlacedItem(
                        item = item,
                        appsByKey = appsByKey,
                        drag = drag,
                        lock = settings.lockLayout,
                        iconSize = iconSize,
                        showLabel = settings.showLabels,
                        onLaunch = onLaunch,
                        onOpenFolder = onOpenFolder,
                        onRelease = onRelease,
                        modifier = frame,
                    )
                }
            }
        }
    }
}

/** App o carpeta ya colocada (escritorio o dock); se oculta mientras se la arrastra. */
@Composable
private fun PlacedItem(
    item: HomeItem,
    appsByKey: Map<String, AppEntry>,
    drag: DragController,
    lock: Boolean,
    iconSize: Dp,
    showLabel: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onOpenFolder: (HomeItem) -> Unit,
    onRelease: DragRelease,
    modifier: Modifier,
) {
    val hidden = (drag.payload as? DragPayload.Home)?.item?.id == item.id
    val base = modifier.graphicsLayer { alpha = if (hidden) 0f else 1f }
    when (item.kind) {
        ItemKind.APP -> {
            val entry = item.appKey?.let { appsByKey[it] } ?: return
            AppCell(
                entry = entry,
                iconSize = iconSize,
                showLabel = showLabel,
                modifier = base.dragSource(
                    drag = drag,
                    payload = { DragPayload.Home(item) },
                    onTap = { onLaunch(entry) },
                    onRelease = onRelease,
                    enabled = !lock,
                ),
            )
        }
        ItemKind.FOLDER -> {
            val entries = item.children.mapNotNull { appsByKey[it] }
            FolderCell(
                title = item.title,
                entries = entries,
                iconSize = iconSize,
                showLabel = showLabel,
                modifier = base.dragSource(
                    drag = drag,
                    payload = { DragPayload.Home(item) },
                    onTap = { onOpenFolder(item) },
                    onRelease = onRelease,
                    enabled = !lock,
                ),
            )
        }
        ItemKind.WIDGET -> Unit
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    Row(
        modifier = Modifier.fillMaxWidth().height(18.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (count > 1) {
            repeat(count) { index ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = if (index == current) 0.95f else 0.4f)),
                )
            }
        }
    }
}

/** Franja superior que aparece al arrastrar: Quitar / Info / Desinstalar. */
@Composable
private fun TopDropZones(drag: DragController, zoneHeightPx: Float, rootWidthPx: Int) {
    val payload = drag.payload ?: return
    val pos = drag.position
    val hovered = if (pos.y < zoneHeightPx && rootWidthPx > 0) {
        (pos.x / rootWidthPx * 3).toInt().coerceIn(0, 2)
    } else {
        -1
    }
    val labels = listOf(R.string.drop_remove, R.string.drop_info, R.string.drop_uninstall)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(72.dp)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val usable = index != 0 || payload is DragPayload.Home
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (hovered == index && usable) Color.White.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.4f),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(label),
                    color = Color.White.copy(alpha = if (usable) 1f else 0.35f),
                )
            }
        }
    }
}

/** Lo que "flota" bajo el dedo mientras se arrastra. */
@Composable
private fun DragGhost(
    drag: DragController,
    appsByKey: Map<String, AppEntry>,
    iconSize: Dp,
    cellWidth: Dp,
    cellHeight: Dp,
) {
    val payload = drag.payload ?: return
    val widget = (payload as? DragPayload.Home)?.item?.takeIf { it.kind == ItemKind.WIDGET }
    val width = if (widget != null) cellWidth * widget.spanX else iconSize + 16.dp
    val height = if (widget != null) cellHeight * widget.spanY else iconSize + 16.dp

    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    (drag.position.x - width.toPx() / 2f).roundToInt(),
                    (drag.position.y - height.toPx() / 2f).roundToInt(),
                )
            }
            .size(width, height)
            .graphicsLayer {
                scaleX = 1.1f
                scaleY = 1.1f
                alpha = 0.92f
            },
        contentAlignment = Alignment.Center,
    ) {
        when {
            widget != null -> Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.3f)),
            )
            payload is DragPayload.Drawer -> AppIcon(payload.entry, iconSize)
            payload is DragPayload.FolderChild -> AppIcon(payload.entry, iconSize)
            payload is DragPayload.Home -> {
                val item = payload.item
                if (item.kind == ItemKind.FOLDER) {
                    FolderCell(
                        title = item.title,
                        entries = item.children.mapNotNull { appsByKey[it] },
                        iconSize = iconSize,
                        showLabel = false,
                    )
                } else {
                    item.appKey?.let { appsByKey[it] }?.let { AppIcon(it, iconSize) }
                }
            }
        }
    }
}

/** Menú contextual de una app, desde el escritorio o desde el cajón. */
@Composable
private fun AppSheet(
    vm: LauncherViewModel,
    entry: AppEntry,
    fromDrawer: Boolean,
    homeItem: HomeItem?,
    onAddedToDesktop: () -> Unit,
    onDismiss: () -> Unit,
) {
    val shortcuts = remember(entry.key) { vm.shortcutsFor(entry) }
    val addLabel = stringResource(R.string.menu_add_desktop)
    val hideLabel = stringResource(R.string.menu_hide)
    val removeLabel = stringResource(R.string.menu_remove)
    val infoLabel = stringResource(R.string.menu_app_info)
    val uninstallLabel = stringResource(R.string.menu_uninstall)

    val actions = buildList {
        shortcuts.forEach { shortcut ->
            val label = shortcut.shortLabel?.toString().orEmpty().ifBlank { shortcut.id }
            add(SheetAction(label) { vm.startShortcut(shortcut) })
        }
        if (fromDrawer) {
            add(SheetAction(addLabel) { if (vm.addToDesktop(entry)) onAddedToDesktop() })
            add(SheetAction(hideLabel) { vm.hideApp(entry) })
        } else if (homeItem != null) {
            add(SheetAction(removeLabel) { vm.removeItem(homeItem) })
        }
        add(SheetAction(infoLabel) { vm.showAppInfo(entry) })
        add(SheetAction(uninstallLabel, destructive = true) { vm.uninstall(entry) })
    }
    ActionSheet(title = entry.label, actions = actions, onDismiss = onDismiss)
}
