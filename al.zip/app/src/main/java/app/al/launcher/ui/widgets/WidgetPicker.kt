package app.al.launcher.ui.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import app.al.launcher.R
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class WidgetEntry(val info: AppWidgetProviderInfo, val label: String)

private fun loadWidgets(context: Context): List<WidgetEntry> {
    val manager = AppWidgetManager.getInstance(context)
    val packageManager = context.packageManager
    return manager.installedProviders
        .filter { it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN != 0 }
        .filter { it.provider.packageName != context.packageName }
        .map { WidgetEntry(it, it.loadLabel(packageManager).orEmpty()) }
        .sortedBy { it.label.lowercase() }
}

/** Lista de widgets instalados con su vista previa y tamaño aproximado en celdas. */
@Composable
fun WidgetPicker(onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    BackHandler(onBack = onDismiss)
    val context = LocalContext.current
    val widgets = remember { loadWidgets(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF20E1217))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.widgets_title),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
        HorizontalDivider()
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(widgets, key = { it.info.provider.flattenToString() }) { entry ->
                WidgetRow(entry = entry, onClick = { onPick(entry.info) })
            }
        }
    }
}

@Composable
private fun WidgetRow(entry: WidgetEntry, onClick: () -> Unit) {
    val context = LocalContext.current
    val density = context.resources.displayMetrics.density
    val cellsX = cells(entry.info.minWidth / density)
    val cellsY = cells(entry.info.minHeight / density)

    val preview by produceState<ImageBitmap?>(null, entry.info) {
        value = withContext(Dispatchers.Default) {
            try {
                val drawable = entry.info.loadPreviewImage(context, 0) ?: entry.info.loadIcon(context, 0)
                if (drawable == null) {
                    null
                } else {
                    val w = drawable.intrinsicWidth.coerceAtLeast(1)
                    val h = drawable.intrinsicHeight.coerceAtLeast(1)
                    val scale = min(1f, 360f / max(w, h))
                    drawable.toBitmap(
                        (w * scale).toInt().coerceAtLeast(1),
                        (h * scale).toInt().coerceAtLeast(1),
                    ).asImageBitmap()
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.size(96.dp), contentAlignment = Alignment.Center) {
            preview?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Column(modifier = Modifier.padding(start = 16.dp)) {
            Text(text = entry.label, style = MaterialTheme.typography.titleMedium)
            Text(
                text = stringResource(R.string.widget_size, cellsX, cellsY),
                color = Color.White.copy(alpha = 0.6f),
            )
        }
    }
}

/** Fórmula clásica de Android: celdas = ceil((dp + 30) / 70). */
private fun cells(sizeDp: Float): Int = max(1, ceil((sizeDp + 30f) / 70f).toInt())
