package app.al.launcher.data

import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Caché en memoria de íconos ya dibujados, por app y tamaño. */
class IconCache(private val apps: AppsRepository) {
    private val cache = LruCache<String, ImageBitmap>(400)

    private fun cacheKey(entry: AppEntry, px: Int) = "${entry.key}#$px"

    fun peek(entry: AppEntry, px: Int): ImageBitmap? = cache.get(cacheKey(entry, px))

    suspend fun load(entry: AppEntry, px: Int): ImageBitmap? {
        val key = cacheKey(entry, px)
        cache.get(key)?.let { return it }
        val bitmap = withContext(Dispatchers.Default) { apps.loadIcon(entry, px)?.asImageBitmap() }
            ?: return null
        cache.put(key, bitmap)
        return bitmap
    }

    fun clear() = cache.evictAll()
}
