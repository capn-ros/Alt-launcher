package app.al.launcher

import android.app.Application
import android.content.Context
import app.al.launcher.data.AppsRepository
import app.al.launcher.data.IconCache
import app.al.launcher.data.LayoutRepository
import app.al.launcher.data.SettingsRepository
import app.al.launcher.widgets.AlWidgetHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class AlApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** Contenedor de dependencias manual: un solo juego de repositorios para toda la app. */
class AppContainer(app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings = SettingsRepository(app)
    val apps = AppsRepository(app, scope)
    val layout = LayoutRepository(app, scope)
    val icons = IconCache(apps)
    val widgetHost = AlWidgetHost(app)

    init {
        apps.onRefreshed = { icons.clear() }
    }
}

val Context.container: AppContainer
    get() = (applicationContext as AlApp).container
