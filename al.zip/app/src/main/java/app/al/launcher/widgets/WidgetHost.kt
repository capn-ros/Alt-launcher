package app.al.launcher.widgets

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.hypot

/** Host de widgets del launcher; crea vistas que además detectan "mantener y arrastrar". */
class AlWidgetHost(context: Context) : AppWidgetHost(context, HOST_ID) {

    override fun onCreateView(
        context: Context,
        appWidgetId: Int,
        appWidget: AppWidgetProviderInfo?,
    ): AppWidgetHostView = LauncherWidgetView(context)

    companion object {
        const val HOST_ID = 0x414C
    }
}

/**
 * Vista de widget que avisa cuando el usuario la mantiene apretada y la arrastra.
 * Las coordenadas que informa están en el sistema de la ventana (igual que Compose).
 */
class LauncherWidgetView(context: Context) : AppWidgetHostView(context) {

    var dragEnabled: Boolean = true
    var onDragStart: ((Float, Float) -> Unit)? = null
    var onDragMove: ((Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val location = IntArray(2)
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private val longPress = Runnable {
        if (!dragEnabled) return@Runnable
        dragging = true
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        getLocationInWindow(location)
        onDragStart?.invoke(location[0] + lastX, location[1] + lastY)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false
                downX = ev.x
                downY = ev.y
                lastX = ev.x
                lastY = ev.y
                removeCallbacks(longPress)
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = ev.x
                lastY = ev.y
                if (dragging) {
                    reportMove(ev)
                } else if (hypot(ev.x - downX, ev.y - downY) > touchSlop) {
                    removeCallbacks(longPress)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) {
                    finishDrag()
                    return true
                }
            }
        }
        return dragging || super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (dragging) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> reportMove(ev)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> finishDrag()
            }
            return true
        }
        return super.onTouchEvent(ev)
    }

    private fun reportMove(ev: MotionEvent) {
        getLocationInWindow(location)
        onDragMove?.invoke(location[0] + ev.x, location[1] + ev.y)
    }

    private fun finishDrag() {
        dragging = false
        onDragEnd?.invoke()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }
}
