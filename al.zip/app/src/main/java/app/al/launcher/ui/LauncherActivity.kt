package app.al.launcher.ui

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import app.al.launcher.R
import app.al.launcher.container
import app.al.launcher.ui.theme.AlTheme

class LauncherActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    private val widgetHost get() = applicationContext.container.widgetHost
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }

    // Widget que se está agregando: id reservado y proveedor elegido.
    private var pendingWidgetId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    private val bindLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) configureOrFinish() else abortWidget()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AlTheme {
                LauncherRoot(vm = viewModel, onPickWidget = ::startAddWidget)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
    }

    override fun onStop() {
        widgetHost.stopListening()
        super.onStop()
    }

    /** Botón Inicio estando ya en el launcher: vuelve a la primera página y cierra todo. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            viewModel.homeEvents.tryEmit(Unit)
        }
    }

    // ------------------------------------------------------------ widgets

    private fun startAddWidget(info: AppWidgetProviderInfo) {
        abortWidget()
        pendingWidgetId = widgetHost.allocateAppWidgetId()
        pendingInfo = info

        if (widgetManager.bindAppWidgetIdIfAllowed(pendingWidgetId, info.provider)) {
            configureOrFinish()
        } else {
            // El sistema pide permiso al usuario para enlazar el widget.
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            }
            try {
                bindLauncher.launch(intent)
            } catch (_: Exception) {
                abortWidget()
            }
        }
    }

    private fun configureOrFinish() {
        val info = pendingInfo
        if (info == null || pendingWidgetId == -1) return
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, pendingWidgetId, 0, REQUEST_CONFIGURE, null)
            } catch (_: Exception) {
                // Configuración inaccesible: se agrega igual con valores por defecto.
                finishWidget()
            }
        } else {
            finishWidget()
        }
    }

    private fun finishWidget() {
        val info = pendingInfo
        val id = pendingWidgetId
        pendingInfo = null
        pendingWidgetId = -1
        if (info != null && id != -1) viewModel.addWidget(id, info)
    }

    private fun abortWidget() {
        viewModel.cancelWidget(pendingWidgetId)
        pendingInfo = null
        pendingWidgetId = -1
    }

    @Deprecated("Necesario para recibir el resultado de la configuración del widget")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CONFIGURE) {
            if (resultCode == Activity.RESULT_OK) finishWidget() else abortWidget()
        }
    }

    private companion object {
        const val REQUEST_CONFIGURE = 1001
    }
}
