package app.al.launcher.ui.widgets

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import app.al.launcher.R
import app.al.launcher.domain.GridSpec
import app.al.launcher.domain.HomeItem
import app.al.launcher.ui.common.StepperRow

/** Diálogo para cambiar el ancho y alto (en celdas) de un widget ya colocado. */
@Composable
fun ResizeDialog(
    item: HomeItem,
    grid: GridSpec,
    onApply: (spanX: Int, spanY: Int) -> Unit,
    onDismiss: () -> Unit,
) {
    var spanX by remember(item.id) { mutableIntStateOf(item.spanX) }
    var spanY by remember(item.id) { mutableIntStateOf(item.spanY) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.resize_title)) },
        text = {
            Column {
                StepperRow(stringResource(R.string.resize_width), spanX, 1..grid.columns) { spanX = it }
                StepperRow(stringResource(R.string.resize_height), spanY, 1..grid.rows) { spanY = it }
            }
        },
        confirmButton = {
            TextButton(onClick = { onApply(spanX, spanY) }) { Text(stringResource(R.string.done)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}
