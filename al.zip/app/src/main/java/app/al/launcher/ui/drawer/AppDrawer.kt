package app.al.launcher.ui.drawer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.al.launcher.R
import app.al.launcher.data.AppEntry
import app.al.launcher.ui.home.AppCell
import app.al.launcher.ui.home.DragController
import app.al.launcher.ui.home.DragPayload
import app.al.launcher.ui.home.DragRelease
import app.al.launcher.ui.home.dragSource
import app.al.launcher.util.normalizedForSearch
import kotlinx.coroutines.launch

/**
 * Cajón de apps: panel que sube desde abajo con buscador, índice alfabético y arrastre hacia
 * el escritorio. [progress] va de 0 (cerrado) a 1 (abierto) y lo maneja quien lo muestra.
 */
@Composable
fun AppDrawer(
    apps: List<AppEntry>,
    columns: Int,
    iconScale: Float,
    showLabels: Boolean,
    progress: () -> Float,
    drag: DragController,
    onLaunch: (AppEntry) -> Unit,
    onRelease: DragRelease,
    onDrawerDrag: (Float) -> Unit,
    onDrawerSettle: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    val shown = remember(apps, query) {
        val q = query.normalizedForSearch().trim()
        if (q.isEmpty()) apps else apps.filter { it.searchKey.contains(q) }
    }

    LaunchedEffect(gridState.isScrollInProgress) {
        if (gridState.isScrollInProgress) keyboard?.hide()
    }

    // Al estirar la lista más allá del tope, el cajón baja; al subirlo de nuevo, la lista espera.
    val currentProgress by rememberUpdatedState(progress)
    val currentDrag by rememberUpdatedState(onDrawerDrag)
    val currentSettle by rememberUpdatedState(onDrawerSettle)
    val nested = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f && currentProgress() < 0.999f) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.UserInput) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val p = currentProgress()
                if (p > 0.001f && p < 0.999f) {
                    currentSettle()
                    return available
                }
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                currentSettle()
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = (1f - progress()) * size.height
                alpha = if (drag.payload is DragPayload.Drawer) 0f else (progress() * 1.5f).coerceIn(0f, 1f)
            }
            .background(Color(0xE60E1217))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding(),
        ) {
            // Cabecera: asa + buscador. Arrastrarla hacia abajo cierra el cajón.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { currentSettle() },
                            onDragCancel = { currentSettle() },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                currentDrag(dy)
                            },
                        )
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .padding(top = 10.dp, bottom = 10.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.35f)),
                )
                SearchField(
                    query = query,
                    onQueryChange = { query = it },
                    onSearch = { shown.firstOrNull()?.let(onLaunch) },
                )
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (shown.isEmpty()) {
                    Text(
                        text = stringResource(R.string.no_results),
                        color = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    state = gridState,
                    modifier = Modifier.fillMaxSize().nestedScroll(nested),
                    contentPadding = PaddingValues(start = 8.dp, end = 28.dp, top = 8.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(shown, key = { it.key }) { entry ->
                        AppCell(
                            entry = entry,
                            iconSize = 56.dp * iconScale,
                            showLabel = showLabels,
                            modifier = Modifier.dragSource(
                                drag = drag,
                                payload = { DragPayload.Drawer(entry) },
                                onTap = { onLaunch(entry) },
                                onRelease = onRelease,
                            ),
                        )
                    }
                }
                if (query.isBlank()) {
                    AlphabetIndex(
                        apps = shown,
                        onJump = { index -> scope.launch { gridState.scrollToItem(index) } },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit) {
    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(Color.White),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_apps),
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 16.sp,
                    )
                }
                inner()
            }
        },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

private fun letterOf(entry: AppEntry): Char {
    val c = entry.searchKey.firstOrNull()?.uppercaseChar()
    return if (c != null && c in 'A'..'Z') c else '#'
}

/** Tira de letras al costado: tocar o deslizar salta a la primera app de esa letra. */
@Composable
private fun AlphabetIndex(apps: List<AppEntry>, onJump: (Int) -> Unit, modifier: Modifier = Modifier) {
    val firstIndex = remember(apps) {
        val map = LinkedHashMap<Char, Int>()
        apps.forEachIndexed { index, entry ->
            val letter = letterOf(entry)
            if (!map.containsKey(letter)) map[letter] = index
        }
        map
    }
    val letters = remember(firstIndex) { firstIndex.keys.toList() }
    var barHeight by remember { mutableIntStateOf(1) }

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val position = ((y / barHeight) * letters.size).toInt().coerceIn(0, letters.lastIndex)
        firstIndex[letters[position]]?.let(onJump)
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .padding(vertical = 12.dp)
            .width(24.dp)
            .onSizeChanged { barHeight = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        pick(change.position.y)
                    },
                )
            }
            .pointerInput(letters) {
                detectTapGestures(onPress = { pick(it.y) })
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { letter ->
            Text(
                text = letter.toString(),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 10.sp,
            )
        }
    }
}
