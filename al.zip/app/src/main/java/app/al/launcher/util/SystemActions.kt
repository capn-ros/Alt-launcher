package app.al.launcher.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Acciones del sistema que el launcher dispara (todas toleran que no haya app que las atienda). */
object SystemActions {

    fun expandNotifications(context: Context) {
        try {
            val service = context.getSystemService("statusbar") ?: return
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel")
                .invoke(service)
        } catch (_: Throwable) {
            // Algunos fabricantes bloquean esta llamada: simplemente no pasa nada.
        }
    }

    fun openWallpaperPicker(context: Context) {
        start(context, Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), null))
    }

    fun uninstall(context: Context, packageName: String) {
        start(context, Intent(Intent.ACTION_DELETE, Uri.fromParts("package", packageName, null)))
    }

    fun openDefaultLauncherSettings(context: Context) {
        start(context, Intent(Settings.ACTION_HOME_SETTINGS))
    }

    private fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            // Sin app disponible para esta acción.
        }
    }
}
