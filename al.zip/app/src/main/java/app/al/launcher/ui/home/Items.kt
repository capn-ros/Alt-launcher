package app.al.launcher.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.al.launcher.R
import app.al.launcher.container
import app.al.launcher.data.AppEntry

val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 11.sp,
    shadow = Shadow(color = Color(0xAA000000), offset = Offset(0f, 1.5f), blurRadius = 4f),
)

/** Ícono de una app; se pide al caché en segundo plano y aparece cuando está listo. */
@Composable
fun AppIcon(entry: AppEntry, size: Dp, modifier: Modifier = Modifier) {
    val cache = LocalContext.current.container.icons
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<ImageBitmap?>(cache.peek(entry, px), entry.key, px) {
        value = cache.load(entry, px) ?: value
    }
    Box(modifier.size(size)) {
        bitmap?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(size)) }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text = text,
        style = LabelStyle,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 3.dp),
    )
}

/** App con su nombre debajo, centrada en la celda que le da [modifier]. */
@Composable
fun AppCell(entry: AppEntry, iconSize: Dp, showLabel: Boolean, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        AppIcon(entry, iconSize)
        if (showLabel) Label(entry.label)
    }
}

/** Carpeta: cuadro translúcido con hasta 4 íconos en miniatura. */
@Composable
fun FolderCell(
    title: String,
    entries: List<AppEntry>,
    iconSize: Dp,
    showLabel: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(iconSize * 0.3f))
                .background(Color.White.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center,
        ) {
            val mini = iconSize * 0.36f
            val gap = iconSize * 0.05f
            Column(
                verticalArrangement = Arrangement.spacedBy(gap),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                entries.take(4).chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        row.forEach { AppIcon(it, mini) }
                    }
                }
            }
        }
        if (showLabel) Label(title.ifBlank { stringResource(R.string.folder_default) })
    }
}
