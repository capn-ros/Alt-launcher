package app.al.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.os.UserManager
import androidx.core.graphics.drawable.toBitmap
import app.al.launcher.util.normalizedForSearch
import java.text.Collator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Lista de apps instaladas (todos los perfiles) y operaciones del sistema sobre ellas. */
class AppsRepository(
    private val context: Context,
    private val scope: CoroutineScope,
) {
    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val userManager = context.getSystemService(UserManager::class.java)

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _packageRemoved = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val packageRemoved: SharedFlow<String> = _packageRemoved.asSharedFlow()

    /** Se llama después de cada recarga (la usa el caché de íconos para vaciarse). */
    var onRefreshed: (() -> Unit)? = null

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            if (packageName != null) _packageRemoved.tryEmit(packageName)
            refresh()
        }

        override fun onPackageAdded(packageName: String?, user: UserHandle?) = refresh()

        override fun onPackageChanged(packageName: String?, user: UserHandle?) = refresh()

        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) =
            refresh()

        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) =
            refresh()
    }

    init {
        launcherApps.registerCallback(callback, Handler(Looper.getMainLooper()))
        refresh()
    }

    fun refresh() {
        scope.launch(Dispatchers.Default) {
            val collator = Collator.getInstance().apply { strength = Collator.PRIMARY }
            val list = userManager.userProfiles
                .flatMap { user ->
                    launcherApps.getActivityList(null, user).map { info ->
                        val component = info.componentName
                        val label = info.label?.toString().orEmpty().ifBlank { component.packageName }
                        val serial = userManager.getSerialNumberForUser(user)
                        AppEntry(
                            key = "${component.flattenToString()}@$serial",
                            component = component,
                            user = user,
                            label = label,
                            searchKey = label.normalizedForSearch(),
                        )
                    }
                }
                .filter { it.component.packageName != context.packageName }
                .sortedWith { a, b -> collator.compare(a.label, b.label) }
            _apps.value = list
            _loaded.value = true
            onRefreshed?.invoke()
        }
    }

    fun launch(entry: AppEntry) {
        try {
            launcherApps.startMainActivity(entry.component, entry.user, null, null)
        } catch (_: Exception) {
            refresh()
        }
    }

    fun showAppInfo(entry: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(entry.component, entry.user, null, null)
        } catch (_: Exception) {
            // La app pudo haberse desinstalado justo ahora.
        }
    }

    /** Ícono ya enmascarado con la forma del sistema (y con la insignia de perfil de trabajo). */
    fun loadIcon(entry: AppEntry, sizePx: Int): Bitmap? = try {
        launcherApps.getActivityList(entry.component.packageName, entry.user)
            .firstOrNull { it.componentName == entry.component }
            ?.getBadgedIcon(0)
            ?.toBitmap(sizePx, sizePx)
    } catch (_: Exception) {
        null
    }

    /** Atajos de la app (mantener apretado). Vacío si no somos el launcher predeterminado. */
    fun shortcutsFor(entry: AppEntry): List<ShortcutInfo> = try {
        val query = LauncherApps.ShortcutQuery()
            .setPackage(entry.component.packageName)
            .setActivity(entry.component)
            .setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST,
            )
        launcherApps.getShortcuts(query, entry.user)?.filter { it.isEnabled }?.take(4).orEmpty()
    } catch (_: Exception) {
        emptyList()
    }

    fun startShortcut(info: ShortcutInfo) {
        try {
            launcherApps.startShortcut(info, null, null)
        } catch (_: Exception) {
            // Atajo ya no disponible.
        }
    }

    fun isLaunchable(component: ComponentName): Boolean = _apps.value.any { it.component == component }
}
