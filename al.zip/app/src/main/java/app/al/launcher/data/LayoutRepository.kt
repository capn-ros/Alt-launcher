package app.al.launcher.data

import android.content.Context
import app.al.launcher.domain.Container
import app.al.launcher.domain.HomeItem
import app.al.launcher.domain.ItemKind
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Guarda el escritorio y el dock en un JSON dentro del almacenamiento privado de la app. */
class LayoutRepository(
    context: Context,
    private val scope: CoroutineScope,
) {
    private val file = File(context.filesDir, "layout.json")
    private val writeMutex = Mutex()

    /** Verdadero hasta que se arma el dock inicial la primera vez que corre el launcher. */
    var needsSeed: Boolean = !file.exists()
        private set

    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<HomeItem>> = _items.asStateFlow()

    /**
     * Aplica [transform] a la lista actual. Si devuelve null o la misma lista no cambia nada.
     * Devuelve false solo cuando la operación no se pudo hacer (null).
     */
    @Synchronized
    fun update(transform: (List<HomeItem>) -> List<HomeItem>?): Boolean {
        val current = _items.value
        val next = transform(current) ?: return false
        if (next != current) {
            _items.value = next
            persist()
        }
        return true
    }

    fun markSeeded() {
        needsSeed = false
        persist()
    }

    private fun persist() {
        scope.launch(Dispatchers.IO) {
            writeMutex.withLock {
                try {
                    val tmp = File(file.parentFile, "layout.json.tmp")
                    tmp.writeText(encode(_items.value))
                    if (!tmp.renameTo(file)) {
                        file.writeText(tmp.readText())
                        tmp.delete()
                    }
                } catch (_: Exception) {
                    // Se reintenta en el próximo cambio.
                }
            }
        }
    }

    private fun load(): List<HomeItem> {
        if (!file.exists()) return emptyList()
        return try {
            decode(file.readText())
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun encode(items: List<HomeItem>): String {
        val array = JSONArray()
        for (item in items) {
            val o = JSONObject()
            o.put("id", item.id)
            o.put("kind", item.kind.name)
            o.put("container", item.container.name)
            o.put("page", item.page)
            o.put("x", item.x)
            o.put("y", item.y)
            o.put("sx", item.spanX)
            o.put("sy", item.spanY)
            item.appKey?.let { o.put("key", it) }
            o.put("title", item.title)
            o.put("widget", item.widgetId)
            o.put("children", JSONArray(item.children))
            array.put(o)
        }
        return array.toString()
    }

    private fun decode(text: String): List<HomeItem> {
        val array = JSONArray(text)
        val out = ArrayList<HomeItem>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val children = o.optJSONArray("children")
            out += HomeItem(
                id = o.getLong("id"),
                kind = ItemKind.valueOf(o.getString("kind")),
                container = Container.valueOf(o.getString("container")),
                page = o.optInt("page", 0),
                x = o.optInt("x", 0),
                y = o.optInt("y", 0),
                spanX = o.optInt("sx", 1),
                spanY = o.optInt("sy", 1),
                appKey = if (o.has("key")) o.getString("key") else null,
                title = o.optString("title", ""),
                widgetId = o.optInt("widget", -1),
                children = if (children == null) emptyList() else List(children.length()) { children.getString(it) },
            )
        }
        return out
    }
}
