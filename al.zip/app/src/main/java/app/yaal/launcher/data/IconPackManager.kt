package app.yaal.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Un pack de íconos ya leído: componente de la app → nombre del drawable dentro del pack. */
class IconPack(
    private val packageName: String,
    private val resources: Resources,
    private val mapping: Map<String, String>,
) {
    fun iconFor(component: ComponentName, px: Int): Bitmap? {
        // ComponentName.toString() es "ComponentInfo{paquete/Clase}", igual que en appfilter.xml.
        val name = mapping[component.toString()] ?: return null
        val id = resources.getIdentifier(name, "drawable", packageName)
        if (id == 0) return null
        return try {
            ResourcesCompat.getDrawable(resources, id, null)?.toBitmap(px, px)
        } catch (_: Exception) {
            null
        }
    }
}

/** Busca los packs de íconos instalados (estándar ADW / Nova / Apex) y lee su appfilter.xml. */
class IconPackManager(private val context: Context) {
    private val packageManager = context.packageManager
    private val loaded = HashMap<String, IconPack?>()

    /** Pares (paquete, nombre visible) de los packs instalados. */
    fun available(): List<Pair<String, String>> = ACTIONS
        .flatMap { action -> packageManager.queryIntentActivities(Intent(action), 0) }
        .map { it.activityInfo.packageName }
        .distinct()
        .mapNotNull { pkg ->
            try {
                pkg to packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                null
            }
        }
        .sortedBy { it.second.lowercase() }

    @Synchronized
    fun load(packageName: String): IconPack? {
        if (loaded.containsKey(packageName)) return loaded[packageName]
        val pack = parse(packageName)
        loaded[packageName] = pack
        return pack
    }

    private fun parse(packageName: String): IconPack? = try {
        val res = packageManager.getResourcesForApplication(packageName)
        val xmlId = res.getIdentifier("appfilter", "xml", packageName)
        val parser: XmlPullParser = if (xmlId != 0) {
            res.getXml(xmlId)
        } else {
            XmlPullParserFactory.newInstance().newPullParser().apply {
                setInput(res.assets.open("appfilter.xml"), null)
            }
        }
        val mapping = HashMap<String, String>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "item") {
                val component = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (component != null && drawable != null) mapping[component] = drawable
            }
            event = parser.next()
        }
        IconPack(packageName, res, mapping)
    } catch (_: Exception) {
        null
    }

    private companion object {
        val ACTIONS = listOf(
            "org.adw.launcher.THEME",
            "com.novalauncher.THEME",
            "com.anddoes.launcher.THEME",
        )
    }
}
