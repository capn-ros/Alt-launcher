package app.yaal.launcher.ui

import android.app.Application
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.yaal.launcher.R
import app.yaal.launcher.container
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.data.DrawerSort
import app.yaal.launcher.data.LauncherSettings
import app.yaal.launcher.domain.Container
import app.yaal.launcher.domain.HomeItem
import app.yaal.launcher.domain.ItemKind
import app.yaal.launcher.domain.LayoutOps
import app.yaal.launcher.services.NotificationBadges
import app.yaal.launcher.ui.home.DragPayload
import app.yaal.launcher.ui.home.DropTarget
import app.yaal.launcher.util.SystemActions
import app.yaal.launcher.util.normalizedForSearch
import java.text.Collator
import kotlin.math.ceil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Une los repositorios con la pantalla: expone estado y traduce acciones del usuario en cambios. */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appContainer = application.container

    val settings: StateFlow<LauncherSettings> = appContainer.settings.settings
    val items: StateFlow<List<HomeItem>> = appContainer.layout.items

    /** Notificaciones activas por paquete (insignias). */
    val badges: StateFlow<Map<String, Int>> = NotificationBadges.counts

    /** Todas las apps, con el nombre personalizado ya aplicado. */
    val apps: StateFlow<List<AppEntry>> = combine(appContainer.apps.apps, settings) { list, s ->
        if (s.labels.isEmpty()) {
            list
        } else {
            list.map { entry ->
                s.labels[entry.key]?.let { entry.copy(label = it, searchKey = it.normalizedForSearch()) } ?: entry
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val appsByKey: StateFlow<Map<String, AppEntry>> = apps
        .map { list -> list.associateBy { it.key } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** Apps del cajón: sin las ocultas y en el orden elegido. */
    val visibleApps: StateFlow<List<AppEntry>> =
        combine(apps, settings, appContainer.usage.counts) { list, s, usage ->
            sortApps(list.filter { it.key !in s.hidden }, s.drawerSort, usage)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val hiddenApps: StateFlow<List<AppEntry>> = combine(apps, settings) { list, s ->
        list.filter { it.key in s.hidden }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Se emite cuando el usuario toca el botón Inicio estando ya en el launcher. */
    val homeEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /** Mensajes cortos para mostrar al usuario (ids de strings). */
    val messages = MutableSharedFlow<Int>(extraBufferCapacity = 4)

    /** Datos que la pantalla informa para ubicar widgets nuevos. */
    var currentPage: Int = 0
    var cellWidthPx: Float = 0f
    var cellHeightPx: Float = 0f

    init {
        viewModelScope.launch {
            appContainer.apps.loaded.first { it }
            if (appContainer.layout.needsSeed) {
                seedDefaults()
                appContainer.layout.markSeeded()
            }
        }
        viewModelScope.launch {
            appContainer.apps.packageRemoved.collect { packageName ->
                delay(600)
                // Si sigue instalada (una actualización), no se toca nada.
                if (apps.value.none { it.component.packageName == packageName }) {
                    appContainer.layout.update { LayoutOps.removePackage(it, packageName) }
                }
            }
        }
        viewModelScope.launch {
            settings.map { it.grid() }.distinctUntilChanged().collect { grid ->
                appContainer.layout.update { LayoutOps.fit(it, grid) }
            }
        }
    }

    // ------------------------------------------------------------ apps

    /** [from] es el ícono tocado (en ventana); con él el sistema anima la apertura desde ese lugar. */
    fun launch(entry: AppEntry, from: androidx.compose.ui.geometry.Rect? = null) {
        appContainer.usage.record(entry.key)
        val source = from?.takeIf { settings.value.launchAnimation && it.width > 0f }?.let {
            android.graphics.Rect(it.left.toInt(), it.top.toInt(), it.right.toInt(), it.bottom.toInt())
        }
        appContainer.apps.launch(entry, source)
    }

    fun launchByKey(key: String) {
        appsByKey.value[key]?.let(::launch)
    }

    fun showAppInfo(entry: AppEntry) = appContainer.apps.showAppInfo(entry)

    fun uninstall(entry: AppEntry) =
        SystemActions.uninstall(getApplication(), entry.component.packageName)

    fun shortcutsFor(entry: AppEntry): List<ShortcutInfo> = appContainer.apps.shortcutsFor(entry)

    fun startShortcut(info: ShortcutInfo) = appContainer.apps.startShortcut(info)

    fun hideApp(entry: AppEntry) = appContainer.settings.update { it.copy(hidden = it.hidden + entry.key) }

    fun showApp(entry: AppEntry) = appContainer.settings.update { it.copy(hidden = it.hidden - entry.key) }

    /** Cambia el nombre que se muestra de una app; un texto vacío vuelve al nombre original. */
    fun renameApp(entry: AppEntry, name: String) {
        val clean = name.trim()
        appContainer.settings.update { s ->
            s.copy(labels = if (clean.isEmpty()) s.labels - entry.key else s.labels + (entry.key to clean))
        }
    }

    fun updateSettings(transform: (LauncherSettings) -> LauncherSettings) =
        appContainer.settings.update(transform)

    fun availableIconPacks(): List<Pair<String, String>> = appContainer.iconPacks.available()

    // ------------------------------------------------------------ copia de seguridad

    fun exportBackup(): String = appContainer.backup.export()

    fun importBackup(text: String): Boolean = appContainer.backup.import(text)

    // ------------------------------------------------------------ escritorio

    /** Aplica un arrastre soltado sobre el escritorio o el dock. Devuelve false si no hubo lugar. */
    fun drop(payload: DragPayload, target: DropTarget): Boolean {
        val grid = settings.value.grid()
        val ok = appContainer.layout.update { current ->
            var base = current
            val moving: HomeItem = when (payload) {
                is DragPayload.Home ->
                    current.firstOrNull { it.id == payload.item.id } ?: return@update null
                is DragPayload.Drawer -> newAppItem(current, payload.entry.key)
                is DragPayload.FolderChild -> {
                    base = LayoutOps.removeChild(current, payload.folderId, payload.entry.key)
                    newAppItem(base, payload.entry.key)
                }
            }
            when (target) {
                is DropTarget.Desktop ->
                    LayoutOps.placeOnDesktop(base, moving, target.page, target.x, target.y, grid)
                is DropTarget.Dock -> LayoutOps.placeInDock(base, moving, target.slot, grid)
                else -> null
            }
        }
        if (!ok) messages.tryEmit(R.string.no_room)
        return ok
    }

    fun addToDesktop(entry: AppEntry): Boolean {
        val grid = settings.value.grid()
        val ok = appContainer.layout.update { current ->
            LayoutOps.addAtFree(current, newAppItem(current, entry.key), currentPage, grid)
        }
        if (!ok) messages.tryEmit(R.string.no_room)
        return ok
    }

    fun removeItem(item: HomeItem) {
        if (item.kind == ItemKind.WIDGET) appContainer.widgetHost.deleteAppWidgetId(item.widgetId)
        appContainer.layout.update { LayoutOps.remove(it, item.id) }
    }

    fun renameFolder(id: Long, title: String) {
        appContainer.layout.update { LayoutOps.rename(it, id, title.trim()) }
    }

    fun resize(item: HomeItem, spanX: Int, spanY: Int): Boolean {
        val grid = settings.value.grid()
        val ok = appContainer.layout.update { LayoutOps.resize(it, item.id, spanX, spanY, grid) }
        if (!ok) messages.tryEmit(R.string.resize_failed)
        return ok
    }

    fun addWidget(widgetId: Int, info: AppWidgetProviderInfo): Boolean {
        val grid = settings.value.grid()
        val metrics = getApplication<Application>().resources.displayMetrics
        val cellW = if (cellWidthPx > 0f) cellWidthPx else metrics.widthPixels / grid.columns.toFloat()
        val cellH = if (cellHeightPx > 0f) cellHeightPx else metrics.heightPixels * 0.6f / grid.rows
        val spanX = ceil(info.minWidth / cellW).toInt().coerceIn(1, grid.columns)
        val spanY = ceil(info.minHeight / cellH).toInt().coerceIn(1, grid.rows)
        val ok = appContainer.layout.update { current ->
            val widget = HomeItem(
                id = LayoutOps.nextId(current),
                kind = ItemKind.WIDGET,
                container = Container.DESKTOP,
                widgetId = widgetId,
                spanX = spanX,
                spanY = spanY,
            )
            LayoutOps.addAtFree(current, widget, currentPage, grid)
        }
        if (!ok) {
            appContainer.widgetHost.deleteAppWidgetId(widgetId)
            messages.tryEmit(R.string.widget_add_failed)
        }
        return ok
    }

    fun cancelWidget(widgetId: Int) {
        if (widgetId != -1) appContainer.widgetHost.deleteAppWidgetId(widgetId)
    }

    fun resetLayout() {
        items.value.filter { it.kind == ItemKind.WIDGET }
            .forEach { appContainer.widgetHost.deleteAppWidgetId(it.widgetId) }
        appContainer.layout.update { emptyList() }
        seedDefaults()
    }

    // ------------------------------------------------------------ internos

    private fun sortApps(list: List<AppEntry>, sort: DrawerSort, usage: Map<String, Int>): List<AppEntry> {
        val collator = Collator.getInstance().apply { strength = Collator.PRIMARY }
        val byName = Comparator<AppEntry> { a, b -> collator.compare(a.label, b.label) }
        return when (sort) {
            DrawerSort.NAME -> list.sortedWith(byName)
            DrawerSort.NAME_DESC -> list.sortedWith(byName.reversed())
            DrawerSort.MOST_USED -> list.sortedWith(compareByDescending<AppEntry> { usage[it.key] ?: 0 }.then(byName))
            DrawerSort.RECENT -> list.sortedWith(compareByDescending<AppEntry> { it.installTime }.then(byName))
        }
    }

    private fun newAppItem(current: List<HomeItem>, key: String) = HomeItem(
        id = LayoutOps.nextId(current),
        kind = ItemKind.APP,
        container = Container.DESKTOP,
        appKey = key,
    )

    /** Dock inicial con las apps por defecto del sistema: teléfono, mensajes, navegador y cámara. */
    private fun seedDefaults() {
        val packageManager = getApplication<Application>().packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        val keys = probes
            .mapNotNull { packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .distinct()
            .mapNotNull { pkg -> apps.value.firstOrNull { it.component.packageName == pkg }?.key }
            .take(settings.value.dockSlots)

        appContainer.layout.update { current ->
            keys.foldIndexed(current) { index, acc, key ->
                acc + HomeItem(
                    id = LayoutOps.nextId(acc),
                    kind = ItemKind.APP,
                    container = Container.DOCK,
                    x = index,
                    appKey = key,
                )
            }
        }
    }
}
