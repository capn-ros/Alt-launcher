package app.yaal.launcher.ui.drawer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.data.AppGroup
import app.yaal.launcher.data.DrawerSort
import app.yaal.launcher.data.DrawerStyle
import app.yaal.launcher.data.LauncherSettings
import app.yaal.launcher.data.SearchPosition
import app.yaal.launcher.ui.home.AppCell
import app.yaal.launcher.ui.home.AppRow
import app.yaal.launcher.ui.home.DragController
import app.yaal.launcher.ui.home.DragPayload
import app.yaal.launcher.ui.home.DragRelease
import app.yaal.launcher.ui.home.dragSource
import app.yaal.launcher.util.normalizedForSearch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

/**
 * Cajón de apps: panel que sube desde abajo, con buscador, grupos por categoría, índice alfabético,
 * vista en grilla o lista y arrastre hacia el escritorio. [progress] va de 0 (cerrado) a 1 (abierto)
 * y lo maneja quien lo muestra.
 */
@Composable
fun AppDrawer(
    apps: List<AppEntry>,
    settings: LauncherSettings,
    progress: () -> Float,
    drag: DragController,
    focusSearch: Boolean,
    onFocusHandled: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onRelease: DragRelease,
    onWebSearch: (String) -> Unit,
    onDrawerDrag: (Float) -> Unit,
    onDrawerSettle: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<AppGroup?>(null) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    val isArc = settings.drawerStyle == DrawerStyle.ARC
    val isList = settings.drawerStyle != DrawerStyle.GRID

    val groups = remember(apps) { apps.map { AppGroup.of(it.category) }.distinct().sorted() }
    val showGroups = settings.drawerCategories && groups.size > 1
    val activeGroup = group?.takeIf { it in groups }

    val shown = remember(apps, query, activeGroup) {
        val q = query.normalizedForSearch().trim()
        apps.filter { entry ->
            (q.isEmpty() || entry.searchKey.contains(q)) &&
                (activeGroup == null || AppGroup.of(entry.category) == activeGroup)
        }
    }

    fun focusField() {
        runCatching { focusRequester.requestFocus() }
        keyboard?.show()
    }

    // Pedido externo (por ejemplo, tocar la barra de búsqueda del escritorio).
    LaunchedEffect(focusSearch) {
        if (focusSearch) {
            // Se espera a que el campo esté dibujado antes de pedirle el foco.
            withFrameNanos { }
            withFrameNanos { }
            focusField()
            onFocusHandled()
        }
    }
    // Teclado automático: se abre cuando el cajón termina de subir.
    LaunchedEffect(settings.drawerAutoKeyboard) {
        if (settings.drawerAutoKeyboard) {
            snapshotFlow { progress() > 0.98f }.distinctUntilChanged().filter { it }.collect { focusField() }
        }
    }
    LaunchedEffect(gridState.isScrollInProgress, listState.isScrollInProgress) {
        if (gridState.isScrollInProgress || listState.isScrollInProgress) keyboard?.hide()
    }

    // Al estirar la lista más allá del tope, el cajón baja; al subirlo de nuevo, la lista espera.
    val currentProgress by rememberUpdatedState(progress)
    val currentDrag by rememberUpdatedState(onDrawerDrag)
    val currentSettle by rememberUpdatedState(onDrawerSettle)
    val nested = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f && currentProgress() < 0.999f) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.UserInput) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val p = currentProgress()
                if (p > 0.001f && p < 0.999f) {
                    currentSettle()
                    return available
                }
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                currentSettle()
                return Velocity.Zero
            }
        }
    }

    val searchOnTop = settings.drawerSearch == SearchPosition.TOP
    val searchField: @Composable () -> Unit = {
        SearchField(
            query = query,
            onQueryChange = { query = it },
            focusRequester = focusRequester,
            onSearch = {
                val first = shown.firstOrNull()
                if (first != null) onLaunch(first) else if (query.isNotBlank()) onWebSearch(query.trim())
            },
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = (1f - progress()) * size.height
                alpha = if (drag.payload is DragPayload.Drawer) 0f else (progress() * 1.5f).coerceIn(0f, 1f)
            }
            .background(Color(0xFF0E1217).copy(alpha = settings.drawerOpacity))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding(),
        ) {
            // Cabecera: asa (y buscador si va arriba). Arrastrarla hacia abajo cierra el cajón.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { currentSettle() },
                            onDragCancel = { currentSettle() },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                currentDrag(dy)
                            },
                        )
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .padding(top = 10.dp, bottom = 10.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.35f)),
                )
                if (searchOnTop) searchField()
            }

            if (showGroups) {
                GroupChips(groups = groups, selected = activeGroup, onSelect = { group = it })
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (shown.isEmpty()) {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(text = stringResource(R.string.no_results), color = Color.White.copy(alpha = 0.6f))
                        if (query.isNotBlank()) {
                            TextButton(onClick = { onWebSearch(query.trim()) }) {
                                Text(stringResource(R.string.search_web))
                            }
                        }
                    }
                }

                if (isList) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().nestedScroll(nested),
                        contentPadding = PaddingValues(end = 24.dp, top = 4.dp, bottom = 16.dp),
                    ) {
                        items(shown, key = { it.key }) { entry ->
                            AppRow(
                                entry = entry,
                                iconSize = 44.dp * settings.drawerIconScale,
                                modifier = Modifier.fillMaxWidth().then(
                                    if (isArc) Modifier.arcLayout(listState, entry.key) else Modifier,
                                ).dragSource(
                                    drag = drag,
                                    payload = { DragPayload.Drawer(entry) },
                                    onTap = { onLaunch(entry) },
                                    onRelease = onRelease,
                                ),
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(settings.drawerColumns),
                        state = gridState,
                        modifier = Modifier.fillMaxSize().nestedScroll(nested),
                        contentPadding = PaddingValues(start = 8.dp, end = 28.dp, top = 8.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(shown.size, key = { shown[it].key }) { index ->
                            val entry = shown[index]
                            AppCell(
                                entry = entry,
                                iconSize = 56.dp * settings.drawerIconScale,
                                showLabel = settings.showLabels,
                                modifier = Modifier.dragSource(
                                    drag = drag,
                                    payload = { DragPayload.Drawer(entry) },
                                    onTap = { onLaunch(entry) },
                                    onRelease = onRelease,
                                ),
                            )
                        }
                    }
                }

                val indexVisible = settings.drawerIndex &&
                    settings.drawerSort == DrawerSort.NAME &&
                    query.isBlank() &&
                    activeGroup == null
                if (indexVisible) {
                    AlphabetIndex(
                        apps = shown,
                        onJump = { index ->
                            scope.launch {
                                if (isList) listState.scrollToItem(index) else gridState.scrollToItem(index)
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }
            }

            if (!searchOnTop) searchField()
        }
    }
}

/**
 * Disposición en arco: la fila cercana a la zona del pulgar (abajo, a la derecha) queda al ras y
 * las demás se corren, se achican y se aclaran, como si la lista girara sobre una rueda.
 */
private fun Modifier.arcLayout(state: LazyListState, key: Any): Modifier = graphicsLayer {
    val info = state.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
    val viewport = (info.viewportEndOffset - info.viewportStartOffset).toFloat().coerceAtLeast(1f)
    val focus = viewport * 0.65f
    val t = ((item.offset + item.size / 2f - focus) / focus).coerceIn(-1.3f, 1.3f)
    val bulge = (1f - t * t).coerceIn(0f, 1f)
    translationX = (1f - bulge) * size.width * 0.32f
    val scale = 0.82f + 0.18f * bulge
    scaleX = scale
    scaleY = scale
    alpha = 0.4f + 0.6f * bulge
    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
}

@Composable
private fun GroupChips(groups: List<AppGroup>, selected: AppGroup?, onSelect: (AppGroup?) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            FilterChip(
                selected = selected == null,
                onClick = { onSelect(null) },
                label = { Text(stringResource(R.string.group_all)) },
            )
        }
        items(groups) { g ->
            FilterChip(
                selected = selected == g,
                onClick = { onSelect(if (selected == g) null else g) },
                label = { Text(stringResource(groupLabel(g))) },
            )
        }
    }
}

private fun groupLabel(group: AppGroup): Int = when (group) {
    AppGroup.GAMES -> R.string.group_games
    AppGroup.SOCIAL -> R.string.group_social
    AppGroup.MEDIA -> R.string.group_media
    AppGroup.PRODUCTIVITY -> R.string.group_productivity
    AppGroup.NEWS -> R.string.group_news
    AppGroup.MAPS -> R.string.group_maps
    AppGroup.OTHER -> R.string.group_other
}

@Composable
private fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onSearch: () -> Unit,
) {
    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(Color.White),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_apps),
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 16.sp,
                    )
                }
                inner()
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .focusRequester(focusRequester),
    )
}

private fun letterOf(entry: AppEntry): Char {
    val c = entry.searchKey.firstOrNull()?.uppercaseChar()
    return if (c != null && c in 'A'..'Z') c else '#'
}

/** Tira de letras al costado: tocar o deslizar salta a la primera app de esa letra. */
@Composable
private fun AlphabetIndex(apps: List<AppEntry>, onJump: (Int) -> Unit, modifier: Modifier = Modifier) {
    val firstIndex = remember(apps) {
        val map = LinkedHashMap<Char, Int>()
        apps.forEachIndexed { index, entry ->
            val letter = letterOf(entry)
            if (!map.containsKey(letter)) map[letter] = index
        }
        map
    }
    val letters = remember(firstIndex) { firstIndex.keys.toList() }
    var barHeight by remember { mutableIntStateOf(1) }

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val position = ((y / barHeight) * letters.size).toInt().coerceIn(0, letters.lastIndex)
        firstIndex[letters[position]]?.let(onJump)
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .padding(vertical = 12.dp)
            .width(24.dp)
            .onSizeChanged { barHeight = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        pick(change.position.y)
                    },
                )
            }
            .pointerInput(letters) {
                detectTapGestures(onPress = { pick(it.y) })
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { letter ->
            Text(
                text = letter.toString(),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 10.sp,
            )
        }
    }
}
