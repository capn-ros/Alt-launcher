package app.yaal.launcher.domain

enum class ItemKind { APP, FOLDER, WIDGET }

enum class Container { DESKTOP, DOCK }

/**
 * Elemento colocado en el escritorio o en el dock.
 *
 * - En el escritorio se ubica con [page], [x], [y] y se extiende [spanX] x [spanY] celdas.
 * - En el dock solo se usa [x] como número de ranura.
 * - [appKey] identifica a la app (ver AppEntry.key); las carpetas guardan las claves en [children].
 */
data class HomeItem(
    val id: Long,
    val kind: ItemKind,
    val container: Container,
    val page: Int = 0,
    val x: Int = 0,
    val y: Int = 0,
    val spanX: Int = 1,
    val spanY: Int = 1,
    val appKey: String? = null,
    val title: String = "",
    val widgetId: Int = -1,
    val children: List<String> = emptyList(),
)

data class GridSpec(val columns: Int, val rows: Int, val dockSlots: Int)

data class Slot(val page: Int, val x: Int, val y: Int)
