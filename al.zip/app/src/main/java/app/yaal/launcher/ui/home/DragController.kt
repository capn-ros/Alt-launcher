package app.yaal.launcher.ui.home

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.domain.HomeItem

/** Qué se está arrastrando y de dónde viene. */
sealed interface DragPayload {
    data class Home(val item: HomeItem) : DragPayload
    data class Drawer(val entry: AppEntry) : DragPayload
    data class FolderChild(val folderId: Long, val entry: AppEntry) : DragPayload
}

/** Dónde se soltó. */
sealed interface DropTarget {
    data class Desktop(val page: Int, val x: Int, val y: Int) : DropTarget
    data class Dock(val slot: Int) : DropTarget
    data object Remove : DropTarget
    data object Info : DropTarget
    data object Uninstall : DropTarget
    data object None : DropTarget
}

/** Callback de fin de arrastre: qué se soltó, dónde (en coordenadas de ventana) y si se movió. */
typealias DragRelease = (payload: DragPayload, position: Offset, moved: Boolean) -> Unit

/**
 * Estado único del arrastre en curso. Lo comparten el escritorio, el dock, el cajón y las
 * carpetas, así se puede arrastrar de cualquiera a cualquiera. Las posiciones están en
 * coordenadas de ventana.
 */
@Stable
class DragController {
    var payload by mutableStateOf<DragPayload?>(null)
        private set
    var position by mutableStateOf(Offset.Zero)
        private set
    var travel by mutableFloatStateOf(0f)
        private set

    /** Ya se movió lo bastante como para considerarlo un arrastre (y no un "mantener apretado"). */
    val moved: Boolean get() = travel > MOVE_THRESHOLD_PX

    val active: Boolean get() = payload != null

    /** Rectángulo (en ventana) del último ícono tocado: la app puede abrirse creciendo desde ahí. */
    var tapBounds: Rect? = null

    fun begin(newPayload: DragPayload, at: Offset) {
        payload = newPayload
        position = at
        travel = 0f
    }

    fun moveBy(delta: Offset) {
        position += delta
        travel += delta.getDistance()
    }

    fun moveTo(point: Offset) {
        travel += (point - position).getDistance()
        position = point
    }

    fun clear() {
        payload = null
    }

    /** Termina el arrastre y avisa el resultado. Un "long press" sin movimiento cuenta como no movido. */
    fun finish(onRelease: DragRelease) {
        val finished = payload
        val where = position
        val moved = this.moved
        clear()
        if (finished != null) onRelease(finished, where, moved)
    }

    private companion object {
        const val MOVE_THRESHOLD_PX = 80f
    }
}

/**
 * Hace que un elemento se pueda tocar (onTap) y mantener apretado para arrastrar.
 * Al soltar llama a [onRelease]; si no hubo movimiento, el llamador muestra el menú contextual.
 */
fun Modifier.dragSource(
    drag: DragController,
    payload: () -> DragPayload,
    onTap: () -> Unit,
    onRelease: DragRelease,
    enabled: Boolean = true,
): Modifier = composed {
    var origin by remember { mutableStateOf(Offset.Zero) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    // Si hubo "mantener apretado", el toque final no debe contar como tap (abriría la app).
    var longPressed by remember { mutableStateOf(false) }
    val currentPayload by rememberUpdatedState(payload)
    val currentTap by rememberUpdatedState(onTap)
    val currentRelease by rememberUpdatedState(onRelease)

    this
        .onGloballyPositioned {
            origin = it.positionInWindow()
            bounds = Rect(origin, androidx.compose.ui.geometry.Size(it.size.width.toFloat(), it.size.height.toFloat()))
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = { longPressed = false },
                onTap = {
                    if (!longPressed) {
                        drag.tapBounds = bounds
                        currentTap()
                    }
                },
            )
        }
        .pointerInput(enabled) {
            if (enabled) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { offset ->
                        longPressed = true
                        drag.begin(currentPayload(), origin + offset)
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        drag.moveBy(amount)
                    },
                    onDragEnd = { drag.finish(currentRelease) },
                    onDragCancel = { drag.clear() },
                )
            }
        }
}
