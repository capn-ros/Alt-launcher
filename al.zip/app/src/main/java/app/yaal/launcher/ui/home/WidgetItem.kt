package app.yaal.launcher.ui.home

import android.appwidget.AppWidgetManager
import android.os.Bundle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.viewinterop.AndroidView
import app.yaal.launcher.container
import app.yaal.launcher.domain.HomeItem
import app.yaal.launcher.widgets.LauncherWidgetView

/** Widget real del sistema dentro de Compose, con arrastre por "mantener apretado". */
@Composable
fun WidgetItem(
    item: HomeItem,
    drag: DragController,
    dragEnabled: Boolean,
    width: Dp,
    height: Dp,
    onRelease: DragRelease,
    onMissing: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val host = remember { context.container.widgetHost }
    val info = remember(item.widgetId) {
        AppWidgetManager.getInstance(context).getAppWidgetInfo(item.widgetId)
    }
    if (info == null) {
        // El proveedor del widget se desinstaló: se saca del escritorio.
        LaunchedEffect(item.id) { onMissing() }
        return
    }

    val currentItem by rememberUpdatedState(item)
    val currentRelease by rememberUpdatedState(onRelease)
    val widthDp = width.value.toInt()
    val heightDp = height.value.toInt()

    AndroidView(
        modifier = modifier,
        factory = { ctx -> host.createView(ctx, item.widgetId, info) },
        update = { view ->
            (view as? LauncherWidgetView)?.let { widget ->
                widget.dragEnabled = dragEnabled
                widget.onDragStart = { x, y -> drag.begin(DragPayload.Home(currentItem), Offset(x, y)) }
                widget.onDragMove = { x, y -> drag.moveTo(Offset(x, y)) }
                widget.onDragEnd = { drag.finish(currentRelease) }
            }
            view.updateAppWidgetSize(Bundle(), widthDp, heightDp, widthDp, heightDp)
        },
    )
}
