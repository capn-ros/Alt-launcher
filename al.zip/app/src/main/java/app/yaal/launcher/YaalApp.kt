package app.yaal.launcher

import android.app.Application
import android.content.Context
import app.yaal.launcher.data.AppsRepository
import app.yaal.launcher.data.BackupManager
import app.yaal.launcher.data.IconCache
import app.yaal.launcher.data.IconPackManager
import app.yaal.launcher.data.IconRenderer
import app.yaal.launcher.data.LayoutRepository
import app.yaal.launcher.data.SettingsRepository
import app.yaal.launcher.data.UsageRepository
import app.yaal.launcher.widgets.YaalWidgetHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class YaalApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** Contenedor de dependencias manual: un solo juego de repositorios para toda la app. */
class AppContainer(app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings = SettingsRepository(app)
    val usage = UsageRepository(app)
    val apps = AppsRepository(app, scope)
    val layout = LayoutRepository(app, scope)
    val iconPacks = IconPackManager(app)
    val icons = IconCache(IconRenderer(app, apps, iconPacks))
    val backup = BackupManager(settings, layout)
    val widgetHost = YaalWidgetHost(app)

    init {
        apps.onRefreshed = { icons.clear() }
    }
}

val Context.container: AppContainer
    get() = (applicationContext as YaalApp).container
