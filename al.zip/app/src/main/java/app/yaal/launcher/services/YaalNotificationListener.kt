package app.yaal.launcher.services

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Cantidad de notificaciones activas por paquete, para las insignias de los íconos. */
object NotificationBadges {
    private val _counts = MutableStateFlow<Map<String, Int>>(emptyMap())
    val counts: StateFlow<Map<String, Int>> = _counts.asStateFlow()

    internal fun publish(map: Map<String, Int>) {
        _counts.value = map
    }
}

class YaalNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() = refresh()

    override fun onListenerDisconnected() = NotificationBadges.publish(emptyMap())

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    /** Cuenta las notificaciones visibles; ignora resúmenes de grupo y las persistentes (reproductor, etc.). */
    private fun refresh() {
        val counts = HashMap<String, Int>()
        try {
            activeNotifications?.forEach { sbn ->
                val isSummary = sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0
                if (!isSummary && !sbn.isOngoing) {
                    counts[sbn.packageName] = (counts[sbn.packageName] ?: 0) + 1
                }
            }
        } catch (_: Exception) {
            // El servicio puede estar desconectándose.
        }
        NotificationBadges.publish(counts)
    }
}
