package app.yaal.launcher.util

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.app.SearchManager
import androidx.core.app.NotificationManagerCompat
import app.yaal.launcher.services.YaalAccessibilityService

/** Acciones del sistema que el launcher dispara (todas toleran que no haya app que las atienda). */
object SystemActions {

    fun isAccessibilityEnabled(): Boolean = YaalAccessibilityService.instance != null

    fun isNotificationAccessEnabled(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** Acción global vía servicio de accesibilidad; false si el servicio no está activado. */
    private fun global(action: Int): Boolean = YaalAccessibilityService.instance?.performGlobalAction(action) ?: false

    fun expandNotifications(context: Context) {
        if (!global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)) expandPanel(context, "expandNotificationsPanel")
    }

    fun expandQuickSettings(context: Context) {
        if (!global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)) expandPanel(context, "expandSettingsPanel")
    }

    /** Devuelve false si falta activar el servicio de accesibilidad de Yaal. */
    fun lockScreen(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)

    /** Devuelve false si falta activar el servicio de accesibilidad de Yaal. */
    fun openRecents(): Boolean = global(AccessibilityService.GLOBAL_ACTION_RECENTS)

    private fun expandPanel(context: Context, method: String) {
        try {
            val service = context.getSystemService("statusbar") ?: return
            Class.forName("android.app.StatusBarManager").getMethod(method).invoke(service)
        } catch (_: Throwable) {
            // Algunos fabricantes bloquean esta llamada: simplemente no pasa nada.
        }
    }

    fun openWallpaperPicker(context: Context) {
        start(context, Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), null))
    }

    fun uninstall(context: Context, packageName: String) {
        start(context, Intent(Intent.ACTION_DELETE, Uri.fromParts("package", packageName, null)))
    }

    fun webSearch(context: Context, query: String) {
        val search = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query)
        try {
            context.startActivity(search.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            start(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
        }
    }

    fun openDefaultLauncherSettings(context: Context) = start(context, Intent(Settings.ACTION_HOME_SETTINGS))

    fun openAccessibilitySettings(context: Context) = start(context, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openNotificationAccessSettings(context: Context) =
        start(context, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            // Sin app disponible para esta acción.
        }
    }
}
