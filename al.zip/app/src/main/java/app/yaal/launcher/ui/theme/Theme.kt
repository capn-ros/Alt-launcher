package app.yaal.launcher.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext

/** Esquema oscuro (los menús flotan sobre el fondo de pantalla); colores dinámicos en Android 12+. */
@Composable
fun YaalTheme(accent: Color? = null, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        darkColorScheme()
    }
    val tuned = if (accent == null) {
        scheme
    } else {
        scheme.copy(
            primary = accent,
            onPrimary = if (accent.luminance() > 0.5f) Color(0xFF101418) else Color.White,
            primaryContainer = accent.copy(alpha = 0.3f),
        )
    }
    MaterialTheme(colorScheme = tuned) {
        // Todo flota sobre el fondo de pantalla, sin Surface: el texto por defecto sería negro.
        CompositionLocalProvider(LocalContentColor provides Color.White, content = content)
    }
}
