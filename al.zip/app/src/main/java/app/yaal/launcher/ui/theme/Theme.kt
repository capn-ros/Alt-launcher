package app.yaal.launcher.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Esquema oscuro (los menús flotan sobre el fondo de pantalla); colores dinámicos en Android 12+. */
@Composable
fun YaalTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        darkColorScheme()
    }
    MaterialTheme(colorScheme = scheme) {
        // Todo flota sobre el fondo de pantalla, sin Surface: el texto por defecto sería negro.
        CompositionLocalProvider(LocalContentColor provides Color.White, content = content)
    }
}
