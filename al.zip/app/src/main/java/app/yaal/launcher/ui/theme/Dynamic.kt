package app.yaal.launcher.ui.theme

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import java.util.Calendar
import kotlinx.coroutines.delay
import androidx.compose.runtime.LaunchedEffect

/** Ámbar suave con el que se tiñe la interfaz de noche. */
val NightAmber = Color(0xFFFFB35C)

/**
 * Color de acento sacado del fondo de pantalla (Android 8.1+). Se actualiza solo si el fondo cambia.
 * Devuelve null si el sistema no lo puede dar.
 */
@Composable
fun rememberWallpaperAccent(enabled: Boolean): Color? {
    if (!enabled || Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) return null
    val context = LocalContext.current
    var accent by remember { mutableStateOf<Color?>(null) }

    DisposableEffect(context) {
        val manager = WallpaperManager.getInstance(context)
        fun read(colors: WallpaperColors?) {
            val primary = colors?.primaryColor ?: return
            accent = Color(primary.toArgb()).brightened()
        }
        read(runCatching { manager.getWallpaperColors(WallpaperManager.FLAG_SYSTEM) }.getOrNull())
        val listener = WallpaperManager.OnColorsChangedListener { colors, _ -> read(colors) }
        runCatching { manager.addOnColorsChangedListener(listener, Handler(Looper.getMainLooper())) }
        onDispose { runCatching { manager.removeOnColorsChangedListener(listener) } }
    }
    return accent
}

/** El acento tiene que verse sobre fondo oscuro: si sale muy apagado se aclara. */
private fun Color.brightened(): Color {
    var color = this
    var guard = 0
    while (color.luminance() < 0.35f && guard < 6) {
        color = lerp(color, Color.White, 0.18f)
        guard++
    }
    return color
}

/** True de 20:00 a 06:00; se revisa cada minuto. */
@Composable
fun rememberIsNight(enabled: Boolean): Boolean {
    var night by remember { mutableStateOf(false) }
    LaunchedEffect(enabled) {
        if (!enabled) {
            night = false
            return@LaunchedEffect
        }
        while (true) {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            night = hour >= 20 || hour < 6
            delay(60_000)
        }
    }
    return night
}
