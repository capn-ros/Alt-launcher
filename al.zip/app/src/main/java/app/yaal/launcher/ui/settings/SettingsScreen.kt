package app.yaal.launcher.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.data.BadgeStyle
import app.yaal.launcher.data.DrawerSort
import app.yaal.launcher.data.DrawerStyle
import app.yaal.launcher.data.GestureAction
import app.yaal.launcher.data.GestureBinding
import app.yaal.launcher.data.IconShape
import app.yaal.launcher.data.LauncherSettings
import app.yaal.launcher.data.PageEffect
import app.yaal.launcher.data.PageIndicator
import app.yaal.launcher.data.SearchPosition
import app.yaal.launcher.ui.common.ActionRow
import app.yaal.launcher.ui.common.ChoiceRow
import app.yaal.launcher.ui.common.SectionTitle
import app.yaal.launcher.ui.common.SliderRow
import app.yaal.launcher.ui.common.StepperRow
import app.yaal.launcher.ui.common.SwitchRow

/** Todo lo que la pantalla de ajustes puede pedirle a quien la muestra. */
data class SettingsActions(
    val onUpdate: ((LauncherSettings) -> LauncherSettings) -> Unit,
    val onShowApp: (AppEntry) -> Unit,
    val onDefaultLauncher: () -> Unit,
    val onReset: () -> Unit,
    val onExport: () -> Unit,
    val onImport: () -> Unit,
    val onAccessibility: () -> Unit,
    val onNotificationAccess: () -> Unit,
    val onClose: () -> Unit,
)

@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    apps: List<AppEntry>,
    hiddenApps: List<AppEntry>,
    iconPacks: List<Pair<String, String>>,
    accessibilityEnabled: Boolean,
    notificationAccess: Boolean,
    actions: SettingsActions,
) {
    BackHandler(onBack = actions.onClose)
    var confirmReset by remember { mutableStateOf(false) }
    val update = actions.onUpdate

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF20E1217))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = actions.onClose) { Text(stringResource(R.string.done)) }
        }
        HorizontalDivider()

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 4.dp),
        ) {
            // ------------------------------------------------------------ Escritorio
            SectionTitle(stringResource(R.string.sec_desktop))
            StepperRow(stringResource(R.string.set_columns), settings.columns, 3..6) { v -> update { it.copy(columns = v) } }
            StepperRow(stringResource(R.string.set_rows), settings.rows, 4..8) { v -> update { it.copy(rows = v) } }
            SliderRow(stringResource(R.string.set_margin), settings.margin.toFloat(), 0f..32f, percent = false,
                onChange = { v -> update { it.copy(margin = v.toInt()) } })
            SliderRow(stringResource(R.string.set_dim), settings.dim, 0f..0.6f,
                onChange = { v -> update { it.copy(dim = v) } })
            ChoiceRow(stringResource(R.string.set_effect), settings.pageEffect, effectOptions()) { v ->
                update { it.copy(pageEffect = v) }
            }
            ChoiceRow(stringResource(R.string.set_indicator), settings.pageIndicator, indicatorOptions()) { v ->
                update { it.copy(pageIndicator = v) }
            }
            SwitchRow(stringResource(R.string.set_wallpaper_scroll), settings.wallpaperScroll) { v ->
                update { it.copy(wallpaperScroll = v) }
            }
            SwitchRow(stringResource(R.string.set_desktop_search), settings.desktopSearchBar) { v ->
                update { it.copy(desktopSearchBar = v) }
            }
            SwitchRow(stringResource(R.string.set_lock), settings.lockLayout) { v -> update { it.copy(lockLayout = v) } }

            // ------------------------------------------------------------ Íconos
            SectionTitle(stringResource(R.string.sec_icons))
            SliderRow(stringResource(R.string.set_icon_size), settings.iconScale, 0.7f..1.4f,
                onChange = { v -> update { it.copy(iconScale = v) } })
            ChoiceRow(stringResource(R.string.set_shape), settings.iconShape, shapeOptions()) { v ->
                update { it.copy(iconShape = v) }
            }
            ChoiceRow(
                label = stringResource(R.string.set_icon_pack),
                value = settings.iconPack,
                options = listOf<Pair<String?, String>>(null to stringResource(R.string.pack_none)) + iconPacks,
            ) { v -> update { it.copy(iconPack = v) } }
            SwitchRow(stringResource(R.string.set_labels), settings.showLabels) { v -> update { it.copy(showLabels = v) } }
            SliderRow(stringResource(R.string.set_label_size), settings.labelScale, 0.7f..1.4f,
                onChange = { v -> update { it.copy(labelScale = v) } })
            StepperRow(stringResource(R.string.set_label_lines), settings.labelLines, 1..2) { v ->
                update { it.copy(labelLines = v) }
            }

            // ------------------------------------------------------------ Dock
            SectionTitle(stringResource(R.string.sec_dock))
            SwitchRow(stringResource(R.string.set_show_dock), settings.showDock) { v -> update { it.copy(showDock = v) } }
            StepperRow(stringResource(R.string.set_dock), settings.dockSlots, 3..6) { v -> update { it.copy(dockSlots = v) } }
            SliderRow(stringResource(R.string.set_dock_icon_size), settings.dockIconScale, 0.7f..1.4f,
                onChange = { v -> update { it.copy(dockIconScale = v) } })
            SliderRow(stringResource(R.string.set_dock_opacity), settings.dockOpacity, 0f..0.8f,
                onChange = { v -> update { it.copy(dockOpacity = v) } })

            // ------------------------------------------------------------ Cajón
            SectionTitle(stringResource(R.string.sec_drawer))
            ChoiceRow(stringResource(R.string.set_drawer_style), settings.drawerStyle, drawerStyleOptions()) { v ->
                update { it.copy(drawerStyle = v) }
            }
            StepperRow(stringResource(R.string.set_drawer_cols), settings.drawerColumns, 3..6) { v ->
                update { it.copy(drawerColumns = v) }
            }
            ChoiceRow(stringResource(R.string.set_drawer_sort), settings.drawerSort, sortOptions()) { v ->
                update { it.copy(drawerSort = v) }
            }
            SliderRow(stringResource(R.string.set_drawer_icon_size), settings.drawerIconScale, 0.7f..1.4f,
                onChange = { v -> update { it.copy(drawerIconScale = v) } })
            SliderRow(stringResource(R.string.set_drawer_opacity), settings.drawerOpacity, 0.3f..1f,
                onChange = { v -> update { it.copy(drawerOpacity = v) } })
            ChoiceRow(stringResource(R.string.set_drawer_search), settings.drawerSearch, searchPositionOptions()) { v ->
                update { it.copy(drawerSearch = v) }
            }
            SwitchRow(stringResource(R.string.set_drawer_index), settings.drawerIndex) { v ->
                update { it.copy(drawerIndex = v) }
            }
            SwitchRow(stringResource(R.string.set_drawer_groups), settings.drawerCategories) { v ->
                update { it.copy(drawerCategories = v) }
            }
            SwitchRow(stringResource(R.string.set_drawer_keyboard), settings.drawerAutoKeyboard) { v ->
                update { it.copy(drawerAutoKeyboard = v) }
            }

            // ------------------------------------------------------------ Carpetas
            SectionTitle(stringResource(R.string.sec_folders))
            StepperRow(stringResource(R.string.set_folder_cols), settings.folderColumns, 2..4) { v ->
                update { it.copy(folderColumns = v) }
            }

            // ------------------------------------------------------------ Insignias
            SectionTitle(stringResource(R.string.sec_badges))
            ChoiceRow(stringResource(R.string.set_badge_style), settings.badgeStyle, badgeOptions()) { v ->
                update { it.copy(badgeStyle = v) }
            }
            ActionRow(
                label = stringResource(R.string.set_badge_access),
                value = stringResource(if (notificationAccess) R.string.state_on else R.string.state_off),
                onClick = actions.onNotificationAccess,
            )

            // ------------------------------------------------------------ Gestos
            SectionTitle(stringResource(R.string.sec_gestures))
            GestureRow(stringResource(R.string.gesture_swipe_up), settings.swipeUp, apps) { v ->
                update { it.copy(swipeUp = v) }
            }
            GestureRow(stringResource(R.string.gesture_swipe_down), settings.swipeDown, apps) { v ->
                update { it.copy(swipeDown = v) }
            }
            GestureRow(stringResource(R.string.gesture_double_tap), settings.doubleTap, apps) { v ->
                update { it.copy(doubleTap = v) }
            }
            GestureRow(stringResource(R.string.gesture_home), settings.homeButton, apps) { v ->
                update { it.copy(homeButton = v) }
            }
            ActionRow(
                label = stringResource(R.string.set_accessibility),
                value = stringResource(if (accessibilityEnabled) R.string.state_on else R.string.state_off),
                onClick = actions.onAccessibility,
            )
            Text(
                text = stringResource(R.string.set_accessibility_hint),
                color = Color.White.copy(alpha = 0.55f),
                style = MaterialTheme.typography.bodySmall,
            )

            // ------------------------------------------------------------ Sistema
            SectionTitle(stringResource(R.string.sec_system))
            SwitchRow(stringResource(R.string.set_hide_status), settings.hideStatusBar) { v ->
                update { it.copy(hideStatusBar = v) }
            }
            SwitchRow(stringResource(R.string.set_rotation), settings.allowRotation) { v ->
                update { it.copy(allowRotation = v) }
            }

            // ------------------------------------------------------------ Apps ocultas
            SectionTitle(stringResource(R.string.set_hidden))
            if (hiddenApps.isEmpty()) {
                Text(text = stringResource(R.string.set_hidden_none), color = Color.White.copy(alpha = 0.6f))
            } else {
                hiddenApps.forEach { app ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = app.label, modifier = Modifier.weight(1f))
                        TextButton(onClick = { actions.onShowApp(app) }) { Text(stringResource(R.string.set_show)) }
                    }
                }
            }

            // ------------------------------------------------------------ Copia de seguridad
            SectionTitle(stringResource(R.string.sec_backup))
            OutlinedButton(onClick = actions.onExport, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.backup_export))
            }
            OutlinedButton(onClick = actions.onImport, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(stringResource(R.string.backup_import))
            }
            Text(
                text = stringResource(R.string.backup_hint),
                color = Color.White.copy(alpha = 0.55f),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp),
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
            OutlinedButton(onClick = actions.onDefaultLauncher, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.set_default))
            }
            Button(
                onClick = {
                    if (confirmReset) {
                        confirmReset = false
                        actions.onReset()
                    } else {
                        confirmReset = true
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 24.dp),
            ) {
                Text(stringResource(if (confirmReset) R.string.set_reset_confirm else R.string.set_reset))
            }
        }
    }
}

/** Acción de un gesto y, si es "abrir app", cuál. */
@Composable
private fun GestureRow(
    label: String,
    binding: GestureBinding,
    apps: List<AppEntry>,
    onChange: (GestureBinding) -> Unit,
) {
    ChoiceRow(label, binding.action, gestureOptions()) { onChange(binding.copy(action = it)) }
    if (binding.action == GestureAction.OPEN_APP) {
        ChoiceRow(
            label = stringResource(R.string.gesture_app),
            value = binding.appKey,
            options = listOf<Pair<String?, String>>(null to stringResource(R.string.gesture_app_none)) +
                apps.map { it.key to it.label },
        ) { onChange(binding.copy(appKey = it)) }
    }
}

// ---------------------------------------------------------------------- opciones de cada selector

@Composable
private fun effectOptions() = listOf(
    PageEffect.SIMPLE to stringResource(R.string.effect_simple),
    PageEffect.CUBE to stringResource(R.string.effect_cube),
    PageEffect.CARDS to stringResource(R.string.effect_cards),
    PageEffect.ZOOM to stringResource(R.string.effect_zoom),
    PageEffect.ROTATE to stringResource(R.string.effect_rotate),
    PageEffect.FLIP to stringResource(R.string.effect_flip),
)

@Composable
private fun indicatorOptions() = listOf(
    PageIndicator.DOTS to stringResource(R.string.indicator_dots),
    PageIndicator.LINE to stringResource(R.string.indicator_line),
    PageIndicator.NONE to stringResource(R.string.indicator_none),
)

@Composable
private fun shapeOptions() = listOf(
    IconShape.SYSTEM to stringResource(R.string.shape_system),
    IconShape.CIRCLE to stringResource(R.string.shape_circle),
    IconShape.SQUIRCLE to stringResource(R.string.shape_squircle),
    IconShape.ROUNDED to stringResource(R.string.shape_rounded),
    IconShape.TEARDROP to stringResource(R.string.shape_teardrop),
)

@Composable
private fun drawerStyleOptions() = listOf(
    DrawerStyle.GRID to stringResource(R.string.style_grid),
    DrawerStyle.LIST to stringResource(R.string.style_list),
)

@Composable
private fun sortOptions() = listOf(
    DrawerSort.NAME to stringResource(R.string.sort_name),
    DrawerSort.NAME_DESC to stringResource(R.string.sort_name_desc),
    DrawerSort.MOST_USED to stringResource(R.string.sort_most_used),
    DrawerSort.RECENT to stringResource(R.string.sort_recent),
)

@Composable
private fun searchPositionOptions() = listOf(
    SearchPosition.TOP to stringResource(R.string.position_top),
    SearchPosition.BOTTOM to stringResource(R.string.position_bottom),
)

@Composable
private fun badgeOptions() = listOf(
    BadgeStyle.NONE to stringResource(R.string.badge_none),
    BadgeStyle.DOT to stringResource(R.string.badge_dot),
    BadgeStyle.COUNT to stringResource(R.string.badge_count),
)

@Composable
private fun gestureOptions() = listOf(
    GestureAction.NONE to stringResource(R.string.action_none),
    GestureAction.DRAWER to stringResource(R.string.action_drawer),
    GestureAction.SEARCH to stringResource(R.string.action_search),
    GestureAction.NOTIFICATIONS to stringResource(R.string.action_notifications),
    GestureAction.QUICK_SETTINGS to stringResource(R.string.action_quick_settings),
    GestureAction.LOCK to stringResource(R.string.action_lock),
    GestureAction.RECENTS to stringResource(R.string.action_recents),
    GestureAction.DESKTOP_MENU to stringResource(R.string.action_desktop_menu),
    GestureAction.SETTINGS to stringResource(R.string.action_settings),
    GestureAction.OPEN_APP to stringResource(R.string.action_open_app),
)
