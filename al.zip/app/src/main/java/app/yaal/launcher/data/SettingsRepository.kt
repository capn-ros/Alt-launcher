package app.yaal.launcher.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Ajustes persistidos como un único JSON en SharedPreferences y expuestos como StateFlow. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("yaal_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    fun update(transform: (LauncherSettings) -> LauncherSettings) {
        val next = transform(_settings.value).sanitized()
        if (next == _settings.value) return
        _settings.value = next
        write(next)
    }

    fun exportJson(): JSONObject = _settings.value.toJson()

    fun import(json: JSONObject) {
        val next = LauncherSettings.fromJson(json)
        _settings.value = next
        write(next)
    }

    private fun read(): LauncherSettings {
        val text = prefs.getString(KEY, null) ?: return LauncherSettings()
        return try {
            LauncherSettings.fromJson(JSONObject(text))
        } catch (_: Exception) {
            LauncherSettings()
        }
    }

    private fun write(settings: LauncherSettings) {
        prefs.edit().putString(KEY, settings.toJson().toString()).apply()
    }

    private companion object {
        const val KEY = "json"
    }
}
