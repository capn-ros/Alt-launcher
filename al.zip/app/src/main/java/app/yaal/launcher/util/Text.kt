package app.yaal.launcher.util

import java.text.Normalizer

private val diacritics = Regex("\\p{InCombiningDiacriticalMarks}+")

/** Minúsculas y sin tildes, para buscar "camara" y encontrar "Cámara". */
fun String.normalizedForSearch(): String =
    diacritics.replace(Normalizer.normalize(this, Normalizer.Form.NFD), "").lowercase()
