package app.yaal.launcher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Process
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin

/** Cómo se dibujan los íconos: forma del recorte y pack de íconos (null = el de cada app). */
data class IconStyle(val shape: IconShape = IconShape.SYSTEM, val pack: String? = null)

/** Convierte una app en un bitmap según el [IconStyle] elegido. */
class IconRenderer(
    private val context: Context,
    private val apps: AppsRepository,
    private val packs: IconPackManager,
) {
    private val packageManager = context.packageManager

    fun render(entry: AppEntry, px: Int, style: IconStyle): Bitmap? {
        style.pack?.let { pack ->
            val themed = packs.load(pack)?.iconFor(entry.component, px)
            if (themed != null) return userBadge(themed, entry)
        }
        return if (style.shape == IconShape.SYSTEM) {
            apps.rawIcon(entry, badged = true)?.toBitmap(px, px)
        } else {
            apps.rawIcon(entry, badged = false)?.let { userBadge(shaped(it, px, style.shape), entry) }
        }
    }

    /** Agrega la insignia de "perfil de trabajo" a los íconos que ya no la traen. */
    private fun userBadge(bitmap: Bitmap, entry: AppEntry): Bitmap {
        if (entry.user == Process.myUserHandle()) return bitmap
        return try {
            packageManager.getUserBadgedIcon(BitmapDrawable(context.resources, bitmap), entry.user)
                .toBitmap(bitmap.width, bitmap.height)
        } catch (_: Exception) {
            bitmap
        }
    }

    private fun shaped(drawable: Drawable, px: Int, shape: IconShape): Bitmap {
        val content = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(content)
        if (drawable is AdaptiveIconDrawable) {
            // Las capas miden 108 dp y solo 72 dp son visibles: se dibujan 1,5 veces más grandes, centradas.
            val inset = (px * 0.25f).roundToInt()
            drawable.background?.let {
                it.setBounds(-inset, -inset, px + inset, px + inset)
                it.draw(canvas)
            }
            drawable.foreground?.let {
                it.setBounds(-inset, -inset, px + inset, px + inset)
                it.draw(canvas)
            }
        } else {
            // Ícono antiguo sin capas: se apoya sobre un fondo claro, con margen.
            canvas.drawColor(LEGACY_BACKGROUND)
            val pad = (px * 0.17f).roundToInt()
            drawable.setBounds(pad, pad, px - pad, px - pad)
            drawable.draw(canvas)
        }

        // Se recorta con la forma usando un shader, así el borde queda suavizado.
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        Canvas(out).drawPath(shapePath(shape, px.toFloat()), paint)
        return out
    }

    private fun shapePath(shape: IconShape, size: Float): Path = Path().apply {
        when (shape) {
            IconShape.CIRCLE -> addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
            IconShape.ROUNDED -> addRoundRect(RectF(0f, 0f, size, size), size * 0.24f, size * 0.24f, Path.Direction.CW)
            IconShape.TEARDROP -> {
                val big = size / 2f
                val small = size * 0.08f
                // Orden de las esquinas: arriba-izq, arriba-der, abajo-der, abajo-izq.
                addRoundRect(
                    RectF(0f, 0f, size, size),
                    floatArrayOf(big, big, big, big, big, big, small, small),
                    Path.Direction.CW,
                )
            }
            IconShape.SQUIRCLE -> {
                // Superelipse |x|^n + |y|^n = 1 con n = 5.
                val n = 5.0
                val steps = 120
                for (i in 0..steps) {
                    val t = 2.0 * PI * i / steps
                    val c = cos(t)
                    val s = sin(t)
                    val x = size / 2f + (sign(c) * abs(c).pow(2.0 / n)).toFloat() * size / 2f
                    val y = size / 2f + (sign(s) * abs(s).pow(2.0 / n)).toFloat() * size / 2f
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }
            IconShape.SYSTEM -> addRect(0f, 0f, size, size, Path.Direction.CW)
        }
    }

    private companion object {
        const val LEGACY_BACKGROUND = 0xFFF1F3F4.toInt()
    }
}
