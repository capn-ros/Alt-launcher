package app.yaal.launcher.data

import app.yaal.launcher.domain.ItemKind
import org.json.JSONArray
import org.json.JSONObject

/** Copia de seguridad: ajustes + escritorio en un único archivo JSON. */
class BackupManager(
    private val settings: SettingsRepository,
    private val layout: LayoutRepository,
) {
    fun export(): String = JSONObject()
        .put("app", APP_ID)
        .put("version", VERSION)
        .put("settings", settings.exportJson())
        .put("layout", JSONArray(layout.exportJson()))
        .toString(2)

    /**
     * Restaura un respaldo. Los widgets no se restauran: su identificador solo vale en el
     * dispositivo donde se crearon. Devuelve false si el archivo no es un respaldo de Yaal.
     */
    fun import(text: String): Boolean = try {
        val root = JSONObject(text)
        require(root.optString("app") == APP_ID)
        val items = layout.decode(root.getJSONArray("layout").toString())
            .filter { it.kind != ItemKind.WIDGET }
        settings.import(root.getJSONObject("settings"))
        layout.update { items }
        true
    } catch (_: Exception) {
        false
    }

    private companion object {
        const val APP_ID = "yaal"
        const val VERSION = 1
    }
}
