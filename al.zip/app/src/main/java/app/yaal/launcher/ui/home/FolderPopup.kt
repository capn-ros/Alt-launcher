package app.yaal.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.domain.HomeItem

/**
 * Contenido de una carpeta abierta. Se puede renombrar, abrir una app o arrastrar una app afuera.
 * Mientras se arrastra un hijo, el popup se vuelve invisible (pero sigue ahí para no cortar el gesto).
 */
@Composable
fun FolderPopup(
    folder: HomeItem,
    entries: List<AppEntry>,
    drag: DragController,
    iconSize: Dp,
    columns: Int,
    onLaunch: (AppEntry) -> Unit,
    onRelease: DragRelease,
    onRename: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember(folder.id) { mutableStateOf(folder.title) }
    val close = {
        onRename(title)
        onDismiss()
    }
    BackHandler(onBack = close)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = if (drag.payload is DragPayload.FolderChild) 0f else 1f }
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = close,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xE61C232B),
            modifier = Modifier
                .padding(24.dp)
                .widthIn(max = 380.dp)
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center),
                    cursorBrush = SolidColor(Color.White),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
                            if (title.isEmpty()) {
                                Text(
                                    text = stringResource(R.string.folder_default),
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 18.sp,
                                )
                            }
                            inner()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                )
                entries.chunked(columns).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth()) {
                        row.forEach { entry ->
                            AppCell(
                                entry = entry,
                                iconSize = iconSize,
                                showLabel = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .dragSource(
                                        drag = drag,
                                        payload = { DragPayload.FolderChild(folder.id, entry) },
                                        onTap = { onLaunch(entry) },
                                        onRelease = onRelease,
                                    ),
                            )
                        }
                        repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}
