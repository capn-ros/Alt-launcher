package app.yaal.launcher.data

import app.yaal.launcher.domain.GridSpec
import org.json.JSONArray
import org.json.JSONObject

enum class IconShape { SYSTEM, CIRCLE, SQUIRCLE, ROUNDED, TEARDROP }

enum class DrawerStyle { GRID, LIST, ARC }

enum class DrawerSort { NAME, NAME_DESC, MOST_USED, RECENT }

enum class SearchPosition { TOP, BOTTOM }

enum class PageIndicator { DOTS, LINE, CURVE, NONE }

enum class ClockStyle { NONE, BLADE, SIMPLE }

enum class PageEffect { SIMPLE, CUBE, CARDS, ZOOM, ROTATE, FLIP }

enum class BadgeStyle { NONE, DOT, COUNT }

enum class GestureAction {
    NONE, DRAWER, NOTIFICATIONS, QUICK_SETTINGS, SEARCH, LOCK, RECENTS, DESKTOP_MENU, SETTINGS, OPEN_APP,
}

/** Acción asignada a un gesto; [appKey] solo se usa con [GestureAction.OPEN_APP]. */
data class GestureBinding(val action: GestureAction = GestureAction.NONE, val appKey: String? = null)

data class LauncherSettings(
    // Escritorio
    val columns: Int = 4,
    val rows: Int = 5,
    val margin: Int = 4,
    val lockLayout: Boolean = false,
    val pageEffect: PageEffect = PageEffect.SIMPLE,
    val pageIndicator: PageIndicator = PageIndicator.DOTS,
    val wallpaperScroll: Boolean = true,
    val dim: Float = 0.10f,
    val desktopSearchBar: Boolean = false,
    // Íconos
    val iconScale: Float = 1f,
    val iconShape: IconShape = IconShape.SYSTEM,
    val iconPack: String? = null,
    val showLabels: Boolean = true,
    val labelScale: Float = 1f,
    val labelLines: Int = 1,
    // Dock
    val showDock: Boolean = true,
    val dockSlots: Int = 5,
    val dockIconScale: Float = 1f,
    val dockOpacity: Float = 0.22f,
    // Cajón de apps
    val drawerStyle: DrawerStyle = DrawerStyle.GRID,
    val drawerColumns: Int = 4,
    val drawerSort: DrawerSort = DrawerSort.NAME,
    val drawerIconScale: Float = 1f,
    val drawerOpacity: Float = 0.90f,
    val drawerSearch: SearchPosition = SearchPosition.TOP,
    val drawerIndex: Boolean = true,
    val drawerCategories: Boolean = true,
    val drawerAutoKeyboard: Boolean = false,
    // Carpetas
    val folderColumns: Int = 3,
    // Insignias
    val badgeStyle: BadgeStyle = BadgeStyle.DOT,
    // Gestos
    val swipeUp: GestureBinding = GestureBinding(GestureAction.DRAWER),
    val swipeDown: GestureBinding = GestureBinding(GestureAction.NOTIFICATIONS),
    val doubleTap: GestureBinding = GestureBinding(GestureAction.NONE),
    val homeButton: GestureBinding = GestureBinding(GestureAction.NONE),
    // Estilo Yaal
    val windEffect: Boolean = true,
    val folderFan: Boolean = true,
    val wallpaperAccent: Boolean = true,
    val radialMenu: Boolean = true,
    val haptics: Boolean = true,
    val launchAnimation: Boolean = true,
    val clockStyle: ClockStyle = ClockStyle.NONE,
    val nightWarm: Boolean = true,
    val depthEffect: Boolean = true,
    // Sistema
    val hideStatusBar: Boolean = false,
    val allowRotation: Boolean = false,
    // Datos del usuario
    val hidden: Set<String> = emptySet(),
    val labels: Map<String, String> = emptyMap(),
) {
    fun grid() = GridSpec(columns, rows, dockSlots)

    /** Fuerza cada valor a su rango válido (por si el JSON viene de un respaldo viejo o editado). */
    fun sanitized() = copy(
        columns = columns.coerceIn(3, 6),
        rows = rows.coerceIn(4, 8),
        margin = margin.coerceIn(0, 32),
        dim = dim.coerceIn(0f, 0.6f),
        iconScale = iconScale.coerceIn(0.7f, 1.4f),
        labelScale = labelScale.coerceIn(0.7f, 1.4f),
        labelLines = labelLines.coerceIn(1, 2),
        dockSlots = dockSlots.coerceIn(3, 6),
        dockIconScale = dockIconScale.coerceIn(0.7f, 1.4f),
        dockOpacity = dockOpacity.coerceIn(0f, 0.8f),
        drawerColumns = drawerColumns.coerceIn(3, 6),
        drawerIconScale = drawerIconScale.coerceIn(0.7f, 1.4f),
        drawerOpacity = drawerOpacity.coerceIn(0.3f, 1f),
        folderColumns = folderColumns.coerceIn(2, 4),
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("columns", columns)
        put("rows", rows)
        put("margin", margin)
        put("lockLayout", lockLayout)
        put("pageEffect", pageEffect.name)
        put("pageIndicator", pageIndicator.name)
        put("wallpaperScroll", wallpaperScroll)
        put("dim", dim.toDouble())
        put("desktopSearchBar", desktopSearchBar)
        put("iconScale", iconScale.toDouble())
        put("iconShape", iconShape.name)
        iconPack?.let { put("iconPack", it) }
        put("showLabels", showLabels)
        put("labelScale", labelScale.toDouble())
        put("labelLines", labelLines)
        put("showDock", showDock)
        put("dockSlots", dockSlots)
        put("dockIconScale", dockIconScale.toDouble())
        put("dockOpacity", dockOpacity.toDouble())
        put("drawerStyle", drawerStyle.name)
        put("drawerColumns", drawerColumns)
        put("drawerSort", drawerSort.name)
        put("drawerIconScale", drawerIconScale.toDouble())
        put("drawerOpacity", drawerOpacity.toDouble())
        put("drawerSearch", drawerSearch.name)
        put("drawerIndex", drawerIndex)
        put("drawerCategories", drawerCategories)
        put("drawerAutoKeyboard", drawerAutoKeyboard)
        put("folderColumns", folderColumns)
        put("badgeStyle", badgeStyle.name)
        put("swipeUp", swipeUp.toJson())
        put("swipeDown", swipeDown.toJson())
        put("doubleTap", doubleTap.toJson())
        put("homeButton", homeButton.toJson())
        put("windEffect", windEffect)
        put("folderFan", folderFan)
        put("wallpaperAccent", wallpaperAccent)
        put("radialMenu", radialMenu)
        put("haptics", haptics)
        put("launchAnimation", launchAnimation)
        put("clockStyle", clockStyle.name)
        put("nightWarm", nightWarm)
        put("depthEffect", depthEffect)
        put("hideStatusBar", hideStatusBar)
        put("allowRotation", allowRotation)
        put("hidden", JSONArray(hidden.toList()))
        put("labels", JSONObject(labels))
    }

    companion object {
        /** Lee un JSON (de la app o de un respaldo); lo que falte o sea inválido toma el valor por defecto. */
        fun fromJson(o: JSONObject): LauncherSettings {
            val d = LauncherSettings()
            return LauncherSettings(
                columns = o.optInt("columns", d.columns),
                rows = o.optInt("rows", d.rows),
                margin = o.optInt("margin", d.margin),
                lockLayout = o.optBoolean("lockLayout", d.lockLayout),
                pageEffect = o.optEnum("pageEffect", d.pageEffect),
                pageIndicator = o.optEnum("pageIndicator", d.pageIndicator),
                wallpaperScroll = o.optBoolean("wallpaperScroll", d.wallpaperScroll),
                dim = o.optFloat("dim", d.dim),
                desktopSearchBar = o.optBoolean("desktopSearchBar", d.desktopSearchBar),
                iconScale = o.optFloat("iconScale", d.iconScale),
                iconShape = o.optEnum("iconShape", d.iconShape),
                iconPack = if (o.has("iconPack")) o.getString("iconPack") else null,
                showLabels = o.optBoolean("showLabels", d.showLabels),
                labelScale = o.optFloat("labelScale", d.labelScale),
                labelLines = o.optInt("labelLines", d.labelLines),
                showDock = o.optBoolean("showDock", d.showDock),
                dockSlots = o.optInt("dockSlots", d.dockSlots),
                dockIconScale = o.optFloat("dockIconScale", d.dockIconScale),
                dockOpacity = o.optFloat("dockOpacity", d.dockOpacity),
                drawerStyle = o.optEnum("drawerStyle", d.drawerStyle),
                drawerColumns = o.optInt("drawerColumns", d.drawerColumns),
                drawerSort = o.optEnum("drawerSort", d.drawerSort),
                drawerIconScale = o.optFloat("drawerIconScale", d.drawerIconScale),
                drawerOpacity = o.optFloat("drawerOpacity", d.drawerOpacity),
                drawerSearch = o.optEnum("drawerSearch", d.drawerSearch),
                drawerIndex = o.optBoolean("drawerIndex", d.drawerIndex),
                drawerCategories = o.optBoolean("drawerCategories", d.drawerCategories),
                drawerAutoKeyboard = o.optBoolean("drawerAutoKeyboard", d.drawerAutoKeyboard),
                folderColumns = o.optInt("folderColumns", d.folderColumns),
                badgeStyle = o.optEnum("badgeStyle", d.badgeStyle),
                swipeUp = o.optGesture("swipeUp", d.swipeUp),
                swipeDown = o.optGesture("swipeDown", d.swipeDown),
                doubleTap = o.optGesture("doubleTap", d.doubleTap),
                homeButton = o.optGesture("homeButton", d.homeButton),
                windEffect = o.optBoolean("windEffect", d.windEffect),
                folderFan = o.optBoolean("folderFan", d.folderFan),
                wallpaperAccent = o.optBoolean("wallpaperAccent", d.wallpaperAccent),
                radialMenu = o.optBoolean("radialMenu", d.radialMenu),
                haptics = o.optBoolean("haptics", d.haptics),
                launchAnimation = o.optBoolean("launchAnimation", d.launchAnimation),
                clockStyle = o.optEnum("clockStyle", d.clockStyle),
                nightWarm = o.optBoolean("nightWarm", d.nightWarm),
                depthEffect = o.optBoolean("depthEffect", d.depthEffect),
                hideStatusBar = o.optBoolean("hideStatusBar", d.hideStatusBar),
                allowRotation = o.optBoolean("allowRotation", d.allowRotation),
                hidden = o.optJSONArray("hidden")?.let { a -> List(a.length()) { a.getString(it) }.toSet() }
                    ?: emptySet(),
                labels = o.optJSONObject("labels")?.let { l -> l.keys().asSequence().associateWith { l.getString(it) } }
                    ?: emptyMap(),
            ).sanitized()
        }
    }
}

private fun GestureBinding.toJson(): JSONObject = JSONObject().apply {
    put("action", action.name)
    appKey?.let { put("app", it) }
}

private fun JSONObject.optFloat(key: String, default: Float): Float = optDouble(key, default.toDouble()).toFloat()

private inline fun <reified E : Enum<E>> JSONObject.optEnum(key: String, default: E): E =
    try {
        enumValueOf<E>(optString(key, default.name))
    } catch (_: IllegalArgumentException) {
        default
    }

private fun JSONObject.optGesture(key: String, default: GestureBinding): GestureBinding {
    val g = optJSONObject(key) ?: return default
    return GestureBinding(
        action = g.optEnum("action", default.action),
        appKey = if (g.has("app")) g.getString("app") else null,
    )
}
