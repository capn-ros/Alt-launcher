package app.yaal.launcher.data

import android.content.ComponentName
import android.os.UserHandle

/**
 * Una app lanzable. [key] es estable y se guarda en el escritorio:
 * "paquete/Clase@númeroDeUsuario".
 */
data class AppEntry(
    val key: String,
    val component: ComponentName,
    val user: UserHandle,
    val label: String,
    val searchKey: String,
    val category: Int,
    val installTime: Long,
) {
    val packageName: String get() = component.packageName
}
