package app.yaal.launcher.data

/**
 * Temas de un toque. Aplicar un tema cambia solo el aspecto y el comportamiento visual: la grilla,
 * las columnas, las carpetas, las apps ocultas y los nombres que puso el usuario no se tocan.
 */
object ThemePresets {

    fun apply(theme: ThemeId, s: LauncherSettings): LauncherSettings {
        // Punto de partida común: todo lo "de estilo" vuelve a lo neutro y cada tema pisa lo suyo.
        val base = s.copy(
            theme = theme,
            iconScale = 1f,
            iconShape = IconShape.SYSTEM,
            labelStyle = LabelStyle.PLAIN,
            labelScale = 1f,
            showLabels = true,
            dockStyle = DockStyle.FLOATING,
            dockIconScale = 1f,
            dockOpacity = 0.22f,
            showDock = true,
            clockStyle = ClockStyle.NONE,
            quickBar = false,
            desktopSearchBar = false,
            searchLight = false,
            accentColor = null,
            pageEffect = PageEffect.SIMPLE,
            pageIndicator = PageIndicator.DOTS,
            drawerStyle = DrawerStyle.GRID,
            drawerOpacity = 0.90f,
            drawerSearch = SearchPosition.TOP,
            drawerIndex = true,
            drawerCategories = true,
            dim = 0.10f,
            windEffect = true,
            depthEffect = true,
            folderFan = true,
            radialMenu = true,
            nightWarm = true,
            wallpaperAccent = true,
            swipeDown = GestureBinding(GestureAction.NOTIFICATIONS),
        )
        return when (theme) {
            ThemeId.YAAL -> base

            // Android 2.x con la capa de HTC: reloj de tarjetas, dock de tres botones, etiquetas en pastilla.
            ThemeId.SENSE -> base.copy(
                labelStyle = LabelStyle.PILL,
                dockStyle = DockStyle.SENSE,
                clockStyle = ClockStyle.FLIP,
                quickBar = true,
                pageEffect = PageEffect.CARDS,
                pageIndicator = PageIndicator.LINE,
                drawerOpacity = 0.97f,
                drawerIndex = false,
                dim = 0f,
                windEffect = false,
                depthEffect = false,
                folderFan = false,
                radialMenu = false,
                nightWarm = false,
                wallpaperAccent = false,
                accentColor = 0xFF8CC63F.toInt(),
            )

            // Gingerbread / Holo: negro, azul eléctrico, cajón por páginas, barra de dock plana.
            ThemeId.HOLO -> base.copy(
                dockStyle = DockStyle.BAR,
                dockOpacity = 0.88f,
                clockStyle = ClockStyle.SIMPLE,
                desktopSearchBar = true,
                searchLight = false,
                pageIndicator = PageIndicator.DOTS,
                drawerStyle = DrawerStyle.PAGED,
                drawerOpacity = 0.96f,
                drawerIndex = false,
                drawerCategories = false,
                dim = 0.15f,
                windEffect = false,
                depthEffect = false,
                folderFan = false,
                radialMenu = false,
                nightWarm = false,
                wallpaperAccent = false,
                accentColor = 0xFF33B5E5.toInt(),
            )

            // MIUI / iOS clásico: íconos cuadrados redondeados, dock de vidrio, buscador al deslizar hacia abajo.
            ThemeId.MIUI -> base.copy(
                iconShape = IconShape.SQUIRCLE,
                dockOpacity = 0.35f,
                pageEffect = PageEffect.ZOOM,
                drawerOpacity = 0.82f,
                drawerIndex = false,
                windEffect = false,
                folderFan = false,
                radialMenu = false,
                nightWarm = false,
                wallpaperAccent = false,
                accentColor = 0xFFFF6A00.toInt(),
                swipeDown = GestureBinding(GestureAction.SEARCH),
            )
        }
    }
}
