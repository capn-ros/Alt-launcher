package app.yaal.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.domain.Container
import app.yaal.launcher.domain.HomeItem
import app.yaal.launcher.domain.ItemKind

/**
 * Vista de páginas ("Leap" en Sense): miniaturas de todas las páginas del escritorio.
 * Tocar una lleva a esa página.
 */
@Composable
fun LeapView(
    items: List<HomeItem>,
    appsByKey: Map<String, AppEntry>,
    pages: Int,
    currentPage: Int,
    columns: Int,
    rows: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val accent = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.78f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            (0 until pages).chunked(3).forEach { group ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    group.forEach { page ->
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            BoxWithConstraints(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(150.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.12f))
                                    .border(
                                        width = if (page == currentPage) 3.dp else 1.dp,
                                        color = if (page == currentPage) accent else Color.White.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(8.dp),
                                    )
                                    .clickable { onPick(page) },
                            ) {
                                val cellW = maxWidth / columns
                                val cellH = maxHeight / rows
                                items.filter { it.container == Container.DESKTOP && it.page == page }.forEach { item ->
                                    val frame = Modifier
                                        .offset(cellW * item.x, cellH * item.y)
                                        .size(cellW * item.spanX, cellH * item.spanY)
                                        .padding(2.dp)
                                    when (item.kind) {
                                        ItemKind.APP -> item.appKey?.let { appsByKey[it] }?.let {
                                            Box(frame, contentAlignment = Alignment.Center) { AppIcon(it, cellW * 0.6f) }
                                        }
                                        ItemKind.FOLDER -> Box(
                                            frame.padding(3.dp).clip(RoundedCornerShape(4.dp))
                                                .background(Color.White.copy(alpha = 0.35f)),
                                        )
                                        ItemKind.WIDGET -> Box(
                                            frame.clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.2f)),
                                        )
                                    }
                                }
                            }
                            Text(
                                text = if (page == 0) stringResource(R.string.leap_home) else (page + 1).toString(),
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                    }
                    // Completa la fila para que las miniaturas tengan todas el mismo ancho.
                    repeat(3 - group.size) { Box(Modifier.weight(1f)) }
                }
            }
        }
    }
}

/** Pantalla "Personalizar" (el botón de la derecha del dock de Sense). */
@Composable
fun PersonalizeScreen(
    onClose: () -> Unit,
    onThemes: () -> Unit,
    onWallpaper: () -> Unit,
    onWidgets: () -> Unit,
    onNewFolder: () -> Unit,
    onNewPage: () -> Unit,
    onLeap: () -> Unit,
    onSettings: () -> Unit,
) {
    BackHandler(onBack = onClose)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1B1B), Color(0xFF050505))))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Text(
            text = stringResource(R.string.personalize_title),
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
        )
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            PersonalizeGroup(R.string.personalize_display) {
                PersonalizeRow(R.string.personalize_themes) { onClose(); onThemes() }
                PersonalizeRow(R.string.menu_wallpaper) { onClose(); onWallpaper() }
            }
            PersonalizeGroup(R.string.personalize_home) {
                PersonalizeRow(R.string.menu_widgets) { onClose(); onWidgets() }
                PersonalizeRow(R.string.menu_new_folder) { onClose(); onNewFolder() }
                PersonalizeRow(R.string.menu_new_page) { onClose(); onNewPage() }
                PersonalizeRow(R.string.leap_title) { onClose(); onLeap() }
            }
            PersonalizeGroup(R.string.personalize_launcher) {
                PersonalizeRow(R.string.menu_settings) { onClose(); onSettings() }
            }
        }
    }
}

@Composable
private fun PersonalizeGroup(title: Int, content: @Composable () -> Unit) {
    Text(
        text = stringResource(title),
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 6.dp),
    )
    Box(Modifier.fillMaxWidth().height(2.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)))
    content()
}

@Composable
private fun PersonalizeRow(label: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = stringResource(label), color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
        Text("›", color = Color.White.copy(alpha = 0.5f), fontSize = 22.sp)
    }
}
