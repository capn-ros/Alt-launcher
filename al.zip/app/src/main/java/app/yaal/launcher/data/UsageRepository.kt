package app.yaal.launcher.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Cuántas veces se abrió cada app desde Yaal (para ordenar por "más usadas"). */
class UsageRepository(context: Context) {
    private val prefs = context.getSharedPreferences("yaal_usage", Context.MODE_PRIVATE)

    private val _counts = MutableStateFlow(load())
    val counts: StateFlow<Map<String, Int>> = _counts.asStateFlow()

    fun record(key: String) {
        val current = _counts.value
        val next = current + (key to ((current[key] ?: 0) + 1))
        _counts.value = next
        prefs.edit().putString(KEY, JSONObject(next).toString()).apply()
    }

    private fun load(): Map<String, Int> {
        val text = prefs.getString(KEY, null) ?: return emptyMap()
        return try {
            val o = JSONObject(text)
            o.keys().asSequence().associateWith { o.getInt(it) }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private companion object {
        const val KEY = "json"
    }
}
