package app.yaal.launcher.domain

import kotlin.math.max
import kotlin.math.min

/**
 * Operaciones puras sobre la lista de elementos del escritorio.
 * Cada operación devuelve la lista nueva, o null si no se pudo realizar (sin lugar).
 * No toca Android: se puede probar con tests unitarios comunes.
 */
object LayoutOps {

    fun nextId(items: List<HomeItem>): Long = (items.maxOfOrNull { it.id } ?: 0L) + 1L

    /** Cantidad de páginas del escritorio (siempre al menos 1). */
    fun pageCount(items: List<HomeItem>): Int =
        (items.filter { it.container == Container.DESKTOP }.maxOfOrNull { it.page } ?: 0) + 1

    fun itemAt(
        items: List<HomeItem>,
        container: Container,
        page: Int,
        x: Int,
        y: Int,
        ignoreId: Long = -1L,
    ): HomeItem? = items.firstOrNull { item ->
        item.id != ignoreId && item.container == container && when (container) {
            Container.DOCK -> item.x == x
            Container.DESKTOP -> item.page == page &&
                x in item.x until item.x + item.spanX &&
                y in item.y until item.y + item.spanY
        }
    }

    fun isFree(
        items: List<HomeItem>,
        page: Int,
        x: Int,
        y: Int,
        spanX: Int,
        spanY: Int,
        grid: GridSpec,
        ignoreId: Long = -1L,
    ): Boolean {
        if (x < 0 || y < 0 || x + spanX > grid.columns || y + spanY > grid.rows) return false
        for (dx in 0 until spanX) {
            for (dy in 0 until spanY) {
                if (itemAt(items, Container.DESKTOP, page, x + dx, y + dy, ignoreId) != null) return false
            }
        }
        return true
    }

    /** Primer hueco libre empezando por [preferredPage]; considera también una página nueva al final. */
    fun findFree(
        items: List<HomeItem>,
        preferredPage: Int,
        spanX: Int,
        spanY: Int,
        grid: GridSpec,
        ignoreId: Long = -1L,
    ): Slot? {
        val lastPage = max(pageCount(items) - 1, preferredPage) + 1
        val pages = listOf(preferredPage) + (0..lastPage).filter { it != preferredPage }
        for (page in pages) {
            for (y in 0 until grid.rows) {
                for (x in 0 until grid.columns) {
                    if (isFree(items, page, x, y, spanX, spanY, grid, ignoreId)) return Slot(page, x, y)
                }
            }
        }
        return null
    }

    fun freeDockSlot(items: List<HomeItem>, grid: GridSpec, ignoreId: Long = -1L): Int? =
        (0 until grid.dockSlots).firstOrNull { itemAt(items, Container.DOCK, 0, it, 0, ignoreId) == null }

    // ---------------------------------------------------------------- colocar

    fun placeOnDesktop(
        items: List<HomeItem>,
        moving: HomeItem,
        page: Int,
        x: Int,
        y: Int,
        grid: GridSpec,
    ): List<HomeItem>? {
        val base = items.filterNot { it.id == moving.id }
        val sx = moving.spanX.coerceIn(1, grid.columns)
        val sy = moving.spanY.coerceIn(1, grid.rows)
        val cx = x.coerceIn(0, grid.columns - sx)
        val cy = y.coerceIn(0, grid.rows - sy)

        if (sx == 1 && sy == 1) {
            val target = itemAt(base, Container.DESKTOP, page, cx, cy)
            if (target != null) {
                val merged = mergeOrNull(base, target, moving)
                if (merged != null) return normalize(merged)
            }
        }

        val placed = moving.copy(container = Container.DESKTOP, page = page, x = cx, y = cy, spanX = sx, spanY = sy)
        if (isFree(base, page, cx, cy, sx, sy, grid)) return normalize(base + placed)

        val slot = findFree(base, page, sx, sy, grid) ?: return null
        return normalize(base + placed.copy(page = slot.page, x = slot.x, y = slot.y))
    }

    fun placeInDock(
        items: List<HomeItem>,
        moving: HomeItem,
        slot: Int,
        grid: GridSpec,
    ): List<HomeItem>? {
        if (moving.kind == ItemKind.WIDGET) return null
        val base = items.filterNot { it.id == moving.id }
        val wanted = slot.coerceIn(0, grid.dockSlots - 1)

        val target = itemAt(base, Container.DOCK, 0, wanted, 0)
        if (target != null) {
            val merged = mergeOrNull(base, target, moving)
            if (merged != null) return normalize(merged)
        }

        val finalSlot = if (target == null) wanted else (freeDockSlot(base, grid) ?: return null)
        return normalize(
            base + moving.copy(
                container = Container.DOCK,
                page = 0,
                x = finalSlot,
                y = 0,
                spanX = 1,
                spanY = 1,
            ),
        )
    }

    /** Agrega un elemento en el primer hueco libre (preferentemente de [page]). */
    fun addAtFree(items: List<HomeItem>, item: HomeItem, page: Int, grid: GridSpec): List<HomeItem>? {
        val slot = findFree(items, page, item.spanX, item.spanY, grid) ?: return null
        return items + item.copy(container = Container.DESKTOP, page = slot.page, x = slot.x, y = slot.y)
    }

    /** Suelta una app sobre otra (crea carpeta) o sobre una carpeta (la agrega). */
    private fun mergeOrNull(base: List<HomeItem>, target: HomeItem, moving: HomeItem): List<HomeItem>? {
        val movingKey = moving.appKey
        if (moving.kind != ItemKind.APP || movingKey == null) return null
        val targetKey = target.appKey
        return when {
            target.kind == ItemKind.FOLDER -> base.map {
                if (it.id == target.id) it.copy(children = (it.children + movingKey).distinct()) else it
            }
            target.kind == ItemKind.APP && targetKey != null && targetKey != movingKey -> {
                val folder = HomeItem(
                    id = max(nextId(base), moving.id + 1L),
                    kind = ItemKind.FOLDER,
                    container = target.container,
                    page = target.page,
                    x = target.x,
                    y = target.y,
                    children = listOf(targetKey, movingKey),
                )
                base.filterNot { it.id == target.id } + folder
            }
            else -> null
        }
    }

    // ---------------------------------------------------------------- editar

    fun remove(items: List<HomeItem>, id: Long): List<HomeItem> =
        normalize(items.filterNot { it.id == id })

    fun removeChild(items: List<HomeItem>, folderId: Long, key: String): List<HomeItem> =
        normalize(
            items.map {
                if (it.id == folderId) it.copy(children = it.children.filterNot { child -> child == key }) else it
            },
        )

    fun rename(items: List<HomeItem>, id: Long, title: String): List<HomeItem> =
        items.map { if (it.id == id) it.copy(title = title) else it }

    fun resize(items: List<HomeItem>, id: Long, spanX: Int, spanY: Int, grid: GridSpec): List<HomeItem>? {
        val item = items.firstOrNull { it.id == id } ?: return null
        val sx = spanX.coerceIn(1, grid.columns)
        val sy = spanY.coerceIn(1, grid.rows)
        val nx = min(item.x, grid.columns - sx)
        val ny = min(item.y, grid.rows - sy)
        if (!isFree(items, item.page, nx, ny, sx, sy, grid, ignoreId = id)) return null
        return items.map { if (it.id == id) it.copy(x = nx, y = ny, spanX = sx, spanY = sy) else it }
    }

    /** Quita del escritorio todo lo que pertenezca a un paquete desinstalado. */
    fun removePackage(items: List<HomeItem>, packageName: String): List<HomeItem> {
        val prefix = "$packageName/"
        return normalize(
            items.mapNotNull { item ->
                when (item.kind) {
                    ItemKind.APP -> if (item.appKey?.startsWith(prefix) == true) null else item
                    ItemKind.FOLDER -> item.copy(children = item.children.filterNot { it.startsWith(prefix) })
                    ItemKind.WIDGET -> item
                }
            },
        )
    }

    /** Carpetas vacías desaparecen; las de un solo elemento vuelven a ser una app suelta. */
    fun normalize(items: List<HomeItem>): List<HomeItem> = items.mapNotNull { item ->
        if (item.kind != ItemKind.FOLDER) {
            item
        } else {
            when (item.children.size) {
                0 -> null
                1 -> item.copy(kind = ItemKind.APP, appKey = item.children[0], children = emptyList(), title = "")
                else -> item
            }
        }
    }

    /** Reacomoda todo cuando cambia el tamaño de la grilla; lo que no entra queda solo en el cajón. */
    fun fit(items: List<HomeItem>, grid: GridSpec): List<HomeItem> {
        val out = mutableListOf<HomeItem>()
        for (item in items) {
            when (item.container) {
                Container.DOCK -> {
                    if (item.x < grid.dockSlots) {
                        out += item
                    } else {
                        val free = freeDockSlot(out, grid)
                        if (free != null) out += item.copy(x = free)
                    }
                }
                Container.DESKTOP -> {
                    val sx = item.spanX.coerceAtMost(grid.columns)
                    val sy = item.spanY.coerceAtMost(grid.rows)
                    val candidate = item.copy(spanX = sx, spanY = sy)
                    if (isFree(out, item.page, item.x, item.y, sx, sy, grid)) {
                        out += candidate
                    } else {
                        val slot = findFree(out, item.page, sx, sy, grid)
                        if (slot != null) out += candidate.copy(page = slot.page, x = slot.x, y = slot.y)
                    }
                }
            }
        }
        return out
    }
}
