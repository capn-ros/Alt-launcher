package app.yaal.launcher.ui.home

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import app.yaal.launcher.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.data.ClockStyle
import app.yaal.launcher.ui.menu.SheetAction
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

// ------------------------------------------------------------------ menú radial

/**
 * Menú que se abre alrededor del dedo: las opciones salen en arco desde el ícono, del lado donde
 * hay más lugar. Tocar fuera lo cierra.
 */
@Composable
fun RadialMenu(
    anchor: Offset,
    rootSize: IntSize,
    actions: List<SheetAction>,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val density = LocalDensity.current
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMedium)) }

    val stepPx = with(density) { 54.dp.toPx() }
    val gapPx = with(density) { 44.dp.toPx() }
    val bulgePx = with(density) { 44.dp.toPx() }
    val marginPx = with(density) { 12.dp.toPx() }
    val total = stepPx * actions.size
    val top = (anchor.y - total / 2f).coerceIn(marginPx, max(marginPx, rootSize.height - total - marginPx))
    val toLeft = anchor.x > rootSize.width / 2f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f * appear.value))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
    ) {
        // Marca del ícono tocado.
        Box(
            modifier = Modifier
                .offset {
                    val half = 32.dp.toPx()
                    IntOffset((anchor.x - half).roundToInt(), (anchor.y - half).roundToInt())
                }
                .size(64.dp)
                .graphicsLayer { alpha = appear.value }
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.16f)),
        )

        actions.forEachIndexed { index, action ->
            val centerY = top + index * stepPx + stepPx / 2f
            val dy = ((centerY - anchor.y) / (total / 2f + 1f)).coerceIn(-1f, 1f)
            val reach = gapPx + bulgePx * (1f - dy * dy)
            val sidePadding = with(density) {
                if (toLeft) (rootSize.width - (anchor.x - reach)).coerceAtLeast(0f).toDp() else (anchor.x + reach).toDp()
            }

            Box(
                modifier = Modifier
                    .offset { IntOffset(0, (centerY - 22.dp.toPx()).roundToInt()) }
                    .fillMaxWidth()
                    .height(44.dp)
                    .padding(start = if (toLeft) 0.dp else sidePadding, end = if (toLeft) sidePadding else 0.dp),
                contentAlignment = if (toLeft) Alignment.CenterEnd else Alignment.CenterStart,
            ) {
                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            alpha = appear.value.coerceIn(0f, 1f)
                            val s = 0.7f + 0.3f * appear.value
                            scaleX = s
                            scaleY = s
                            transformOrigin = TransformOrigin(if (toLeft) 1f else 0f, 0.5f)
                        }
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF1A2029))
                        .clickable {
                            action.onClick()
                            onDismiss()
                        }
                        .height(44.dp)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = action.label,
                        maxLines = 1,
                        color = if (action.destructive) MaterialTheme.colorScheme.error else Color.White,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ reloj

/** Reloj del escritorio: hora grande (en hojas afiladas o simple) y fecha debajo. */
@Composable
fun YaalClock(style: ClockStyle, modifier: Modifier = Modifier) {
    if (style == ClockStyle.NONE) return
    val context = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 30L)
        }
    }
    val calendar = remember(now) { Calendar.getInstance().apply { timeInMillis = now } }
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val minute = calendar.get(Calendar.MINUTE)
    val weekday = remember(now) { SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(now)).replaceFirstChar { it.uppercase() } }
    val shortDate = remember(now) { SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE d 'de' MMMM", Locale.getDefault()).format(Date(now)) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { openClock(context) }
            .padding(top = 12.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (style == ClockStyle.BLADE) {
            BladeTime(hour = hour, minute = minute)
        } else if (style == ClockStyle.FLIP) {
            FlipPanel(hour = hour, minute = minute, weekday = weekday, shortDate = shortDate)
        } else {
            val thin = style == ClockStyle.THIN
            Text(
                text = "%02d:%02d".format(hour, minute),
                fontSize = if (thin) 84.sp else 68.sp,
                fontWeight = if (thin) FontWeight.ExtraLight else FontWeight.Light,
                color = Color.White,
            )
        }
        if (style != ClockStyle.FLIP) {
            Text(
                text = date.replaceFirstChar { it.uppercase() },
                color = Color.White.copy(alpha = 0.75f),
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

private fun openClock(context: Context) {
    try {
        context.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // Sin app de reloj: no pasa nada.
    }
}

/** Segmentos encendidos (a, b, c, d, e, f, g) de cada dígito. */
private val Segments = arrayOf(
    booleanArrayOf(true, true, true, true, true, true, false),
    booleanArrayOf(false, true, true, false, false, false, false),
    booleanArrayOf(true, true, false, true, true, false, true),
    booleanArrayOf(true, true, true, true, false, false, true),
    booleanArrayOf(false, true, true, false, false, true, true),
    booleanArrayOf(true, false, true, true, false, true, true),
    booleanArrayOf(true, false, true, true, true, true, true),
    booleanArrayOf(true, true, true, false, false, false, false),
    booleanArrayOf(true, true, true, true, true, true, true),
    booleanArrayOf(true, true, true, true, false, true, true),
)

@Composable
private fun BladeTime(hour: Int, minute: Int) {
    val primary = MaterialTheme.colorScheme.primary
    val digits = intArrayOf(hour / 10, hour % 10, minute / 10, minute % 10)
    val cell = 44.dp
    val cellHeight = 84.dp
    val gap = 8.dp
    val colon = 18.dp
    val totalWidth = cell * 4 + gap * 4 + colon + 12.dp

    Canvas(modifier = Modifier.width(totalWidth).height(cellHeight)) {
        val w = cell.toPx()
        val h = size.height
        val g = gap.toPx()
        val brush = Brush.verticalGradient(listOf(Color.White, primary), startY = 0f, endY = h)
        var x = 6.dp.toPx()
        for (i in 0 until 4) {
            drawDigit(digits[i], x, w, h, brush)
            x += w + g
            if (i == 1) {
                drawColon(x + colon.toPx() / 2f, h, brush)
                x += colon.toPx() + g
            }
        }
    }
}

/** Inclinación hacia la derecha: la parte de arriba se corre, como un mechón peinado. */
private fun lean(x: Float, y: Float, h: Float) = x + (h - y) * 0.14f

private fun DrawScope.blade(points: List<Offset>, h: Float, brush: Brush) {
    val path = Path()
    points.forEachIndexed { index, p ->
        val x = lean(p.x, p.y, h)
        if (index == 0) path.moveTo(x, p.y) else path.lineTo(x, p.y)
    }
    path.close()
    drawPath(path, brush)
}

private fun DrawScope.drawDigit(digit: Int, left: Float, w: Float, h: Float, brush: Brush) {
    val on = Segments[digit.coerceIn(0, 9)]
    val t = w * 0.24f
    val gap = t * 0.14f
    val right = left + w
    val mid = h / 2f
    val half = t / 2f

    fun horizontal(yc: Float): List<Offset> = listOf(
        Offset(left + gap, yc),
        Offset(left + gap + half, yc - half),
        Offset(right - gap - half, yc - half),
        Offset(right - gap, yc),
        Offset(right - gap - half, yc + half),
        Offset(left + gap + half, yc + half),
    )

    fun vertical(xc: Float, y0: Float, y1: Float): List<Offset> = listOf(
        Offset(xc, y0 + gap),
        Offset(xc + half, y0 + gap + half),
        Offset(xc + half, y1 - gap - half),
        Offset(xc, y1 - gap),
        Offset(xc - half, y1 - gap - half),
        Offset(xc - half, y0 + gap + half),
    )

    val top = half
    val bottom = h - half
    if (on[0]) blade(horizontal(top), h, brush)
    if (on[1]) blade(vertical(right - half, top, mid), h, brush)
    if (on[2]) blade(vertical(right - half, mid, bottom), h, brush)
    if (on[3]) blade(horizontal(bottom), h, brush)
    if (on[4]) blade(vertical(left + half, mid, bottom), h, brush)
    if (on[5]) blade(vertical(left + half, top, mid), h, brush)
    if (on[6]) blade(horizontal(mid), h, brush)
}

private fun DrawScope.drawColon(cx: Float, h: Float, brush: Brush) {
    val r = min(size.width, h) * 0.035f + 3f
    for (y in listOf(h * 0.34f, h * 0.66f)) {
        blade(
            listOf(Offset(cx, y - r * 1.4f), Offset(cx + r, y), Offset(cx, y + r * 1.4f), Offset(cx - r, y)),
            h,
            brush,
        )
    }
}

// ------------------------------------------------------------------ reloj de tarjetas (estilo HTC)

/** Panel oscuro con las dos tarjetas de la hora y, debajo, el día a la izquierda y la fecha a la derecha. */
@Composable
private fun FlipPanel(hour: Int, minute: Int, weekday: String, shortDate: String) {
    Column(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xB3000000), Color(0x80000000))))
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            FlipCard("%02d".format(hour), Modifier.weight(1f))
            FlipCard("%02d".format(minute), Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = weekday, color = Color.White, fontSize = 18.sp)
            Text(text = shortDate, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Tarjeta blanca partida al medio, como las de los relojes de solapas. */
@Composable
private fun FlipCard(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(112.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE4E4E4)))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            fontSize = 96.sp,
            color = Color(0xFF202020),
            fontWeight = FontWeight.Light,
        )
        // Línea del pliegue con una sombra suave debajo.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.verticalGradient(listOf(Color(0x66000000), Color(0x00000000)))),
        )
    }
}

// ------------------------------------------------------------------ barra rápida

/** Atajos a los ajustes del sistema (Android ya no deja que una app prenda o apague estas cosas). */
@Composable
fun QuickBar(accent: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var states by remember { mutableStateOf(List(5) { false }) }
    LaunchedEffect(Unit) {
        while (true) {
            states = readQuickStates(context)
            delay(2_000)
        }
    }
    val items = listOf(
        stringResource(R.string.quick_wifi) to android.provider.Settings.ACTION_WIFI_SETTINGS,
        stringResource(R.string.quick_bluetooth) to android.provider.Settings.ACTION_BLUETOOTH_SETTINGS,
        stringResource(R.string.quick_location) to android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        stringResource(R.string.quick_display) to android.provider.Settings.ACTION_DISPLAY_SETTINGS,
        stringResource(R.string.quick_airplane) to android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS,
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xCC121212)),
    ) {
        items.forEachIndexed { index, (label, action) ->
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { startSettings(context, action) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    maxLines = 1,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(vertical = 14.dp),
                )
                Box(Modifier.fillMaxWidth().height(3.dp).background(if (states[index]) accent else Color(0xFF444444)))
            }
        }
    }
}

/** Wi‑Fi, Bluetooth, ubicación, brillo automático y modo avión; lo que no se pueda leer cuenta como apagado. */
private fun readQuickStates(context: Context): List<Boolean> {
    val wifi = runCatching {
        (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled
    }.getOrDefault(false)
    val bluetooth = runCatching {
        @Suppress("DEPRECATION")
        android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    }.getOrDefault(false)
    val location = runCatching {
        (context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).isLocationEnabled
    }.getOrDefault(false)
    val autoBrightness = runCatching {
        android.provider.Settings.System.getInt(
            context.contentResolver,
            android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE,
        ) == android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
    }.getOrDefault(false)
    val airplane = runCatching {
        android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON) == 1
    }.getOrDefault(false)
    return listOf(wifi, bluetooth, location, autoBrightness, airplane)
}

private fun startSettings(context: Context, action: String) {
    try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // Ese ajuste no existe en este teléfono.
    }
}

// ------------------------------------------------------------------ dock de tres botones (estilo HTC)

/** Barra inferior: botón del cajón a la izquierda, teléfono grande al centro y personalizar a la derecha. */
@Composable
fun SenseDock(
    onDrawer: () -> Unit,
    onCustomize: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF4A4A4A), Color(0xFF151515)))),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Asa: tocarla también abre el cajón.
        Box(
            modifier = Modifier
                .padding(top = 6.dp, bottom = 6.dp)
                .width(40.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.45f))
                .clickable(onClick = onDrawer),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SenseButton(modifier = Modifier.weight(1f), onClick = onDrawer) { DrawerGlyph() }
            SenseButton(modifier = Modifier.weight(3f), onClick = { dial(context) }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HandsetGlyph()
                    Text(
                        text = stringResource(R.string.sense_phone),
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 20.sp,
                    )
                }
            }
            SenseButton(modifier = Modifier.weight(1f), onClick = onCustomize) {
                Text("+", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun SenseButton(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3B3B3B), Color(0xFF0C0C0C))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Auricular de teléfono: un arco grueso con extremos redondeados. */
@Composable
private fun HandsetGlyph() {
    Canvas(modifier = Modifier.size(22.dp)) {
        val stroke = size.width * 0.22f
        val inset = stroke / 2f
        drawArc(
            color = Color.White,
            startAngle = 90f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(inset, inset - size.height * 0.1f),
            size = androidx.compose.ui.geometry.Size(size.width * 1.2f, size.height * 1.2f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
        )
    }
}

/** Círculo con una flecha hacia arriba: el botón del cajón. */
@Composable
private fun DrawerGlyph() {
    Canvas(modifier = Modifier.size(30.dp)) {
        val r = size.minDimension / 2f
        drawCircle(Color.White, radius = r - 1.5f, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
        val c = center
        val arrow = Path().apply {
            moveTo(c.x, c.y - r * 0.42f)
            lineTo(c.x + r * 0.45f, c.y + r * 0.28f)
            lineTo(c.x - r * 0.45f, c.y + r * 0.28f)
            close()
        }
        drawPath(arrow, Color.White)
    }
}

private fun dial(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // Sin app de teléfono.
    }
}

// ------------------------------------------------------------------ botón de apps (estilo Xperia)

/** Cuadrícula de nueve puntos: el botón que abre el cajón, en el centro del dock. */
@Composable
fun AppsButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(52.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(26.dp)) {
            val step = size.width / 3f
            val radius = step * 0.2f
            for (row in 0 until 3) {
                for (col in 0 until 3) {
                    drawCircle(
                        Color.White,
                        radius = radius,
                        center = Offset(step * col + step / 2f, step * row + step / 2f),
                    )
                }
            }
        }
    }
}
