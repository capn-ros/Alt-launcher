package app.yaal.launcher.ui.home

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.data.ClockStyle
import app.yaal.launcher.ui.menu.SheetAction
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

// ------------------------------------------------------------------ menú radial

/**
 * Menú que se abre alrededor del dedo: las opciones salen en arco desde el ícono, del lado donde
 * hay más lugar. Tocar fuera lo cierra.
 */
@Composable
fun RadialMenu(
    anchor: Offset,
    rootSize: IntSize,
    actions: List<SheetAction>,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val density = LocalDensity.current
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMedium)) }

    val stepPx = with(density) { 54.dp.toPx() }
    val gapPx = with(density) { 44.dp.toPx() }
    val bulgePx = with(density) { 44.dp.toPx() }
    val marginPx = with(density) { 12.dp.toPx() }
    val total = stepPx * actions.size
    val top = (anchor.y - total / 2f).coerceIn(marginPx, max(marginPx, rootSize.height - total - marginPx))
    val toLeft = anchor.x > rootSize.width / 2f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f * appear.value))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
    ) {
        // Marca del ícono tocado.
        Box(
            modifier = Modifier
                .offset {
                    val half = 32.dp.toPx()
                    IntOffset((anchor.x - half).roundToInt(), (anchor.y - half).roundToInt())
                }
                .size(64.dp)
                .graphicsLayer { alpha = appear.value }
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.16f)),
        )

        actions.forEachIndexed { index, action ->
            val centerY = top + index * stepPx + stepPx / 2f
            val dy = ((centerY - anchor.y) / (total / 2f + 1f)).coerceIn(-1f, 1f)
            val reach = gapPx + bulgePx * (1f - dy * dy)
            val sidePadding = with(density) {
                if (toLeft) (rootSize.width - (anchor.x - reach)).coerceAtLeast(0f).toDp() else (anchor.x + reach).toDp()
            }

            Box(
                modifier = Modifier
                    .offset { IntOffset(0, (centerY - 22.dp.toPx()).roundToInt()) }
                    .fillMaxWidth()
                    .height(44.dp)
                    .padding(start = if (toLeft) 0.dp else sidePadding, end = if (toLeft) sidePadding else 0.dp),
                contentAlignment = if (toLeft) Alignment.CenterEnd else Alignment.CenterStart,
            ) {
                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            alpha = appear.value.coerceIn(0f, 1f)
                            val s = 0.7f + 0.3f * appear.value
                            scaleX = s
                            scaleY = s
                            transformOrigin = TransformOrigin(if (toLeft) 1f else 0f, 0.5f)
                        }
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF1A2029))
                        .clickable {
                            action.onClick()
                            onDismiss()
                        }
                        .height(44.dp)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = action.label,
                        maxLines = 1,
                        color = if (action.destructive) MaterialTheme.colorScheme.error else Color.White,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ reloj

/** Reloj del escritorio: hora grande (en hojas afiladas o simple) y fecha debajo. */
@Composable
fun YaalClock(style: ClockStyle, modifier: Modifier = Modifier) {
    if (style == ClockStyle.NONE) return
    val context = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 30L)
        }
    }
    val calendar = remember(now) { Calendar.getInstance().apply { timeInMillis = now } }
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val minute = calendar.get(Calendar.MINUTE)
    val date = remember(now) { SimpleDateFormat("EEEE d 'de' MMMM", Locale.getDefault()).format(Date(now)) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { openClock(context) }
            .padding(top = 12.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (style == ClockStyle.BLADE) {
            BladeTime(hour = hour, minute = minute)
        } else {
            Text(
                text = "%02d:%02d".format(hour, minute),
                fontSize = 68.sp,
                fontWeight = FontWeight.Light,
                color = Color.White,
            )
        }
        Text(
            text = date.replaceFirstChar { it.uppercase() },
            color = Color.White.copy(alpha = 0.75f),
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

private fun openClock(context: Context) {
    try {
        context.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // Sin app de reloj: no pasa nada.
    }
}

/** Segmentos encendidos (a, b, c, d, e, f, g) de cada dígito. */
private val Segments = arrayOf(
    booleanArrayOf(true, true, true, true, true, true, false),
    booleanArrayOf(false, true, true, false, false, false, false),
    booleanArrayOf(true, true, false, true, true, false, true),
    booleanArrayOf(true, true, true, true, false, false, true),
    booleanArrayOf(false, true, true, false, false, true, true),
    booleanArrayOf(true, false, true, true, false, true, true),
    booleanArrayOf(true, false, true, true, true, true, true),
    booleanArrayOf(true, true, true, false, false, false, false),
    booleanArrayOf(true, true, true, true, true, true, true),
    booleanArrayOf(true, true, true, true, false, true, true),
)

@Composable
private fun BladeTime(hour: Int, minute: Int) {
    val primary = MaterialTheme.colorScheme.primary
    val digits = intArrayOf(hour / 10, hour % 10, minute / 10, minute % 10)
    val cell = 44.dp
    val cellHeight = 84.dp
    val gap = 8.dp
    val colon = 18.dp
    val totalWidth = cell * 4 + gap * 4 + colon + 12.dp

    Canvas(modifier = Modifier.width(totalWidth).height(cellHeight)) {
        val w = cell.toPx()
        val h = size.height
        val g = gap.toPx()
        val brush = Brush.verticalGradient(listOf(Color.White, primary), startY = 0f, endY = h)
        var x = 6.dp.toPx()
        for (i in 0 until 4) {
            drawDigit(digits[i], x, w, h, brush)
            x += w + g
            if (i == 1) {
                drawColon(x + colon.toPx() / 2f, h, brush)
                x += colon.toPx() + g
            }
        }
    }
}

/** Inclinación hacia la derecha: la parte de arriba se corre, como un mechón peinado. */
private fun lean(x: Float, y: Float, h: Float) = x + (h - y) * 0.14f

private fun DrawScope.blade(points: List<Offset>, h: Float, brush: Brush) {
    val path = Path()
    points.forEachIndexed { index, p ->
        val x = lean(p.x, p.y, h)
        if (index == 0) path.moveTo(x, p.y) else path.lineTo(x, p.y)
    }
    path.close()
    drawPath(path, brush)
}

private fun DrawScope.drawDigit(digit: Int, left: Float, w: Float, h: Float, brush: Brush) {
    val on = Segments[digit.coerceIn(0, 9)]
    val t = w * 0.24f
    val gap = t * 0.14f
    val right = left + w
    val mid = h / 2f
    val half = t / 2f

    fun horizontal(yc: Float): List<Offset> = listOf(
        Offset(left + gap, yc),
        Offset(left + gap + half, yc - half),
        Offset(right - gap - half, yc - half),
        Offset(right - gap, yc),
        Offset(right - gap - half, yc + half),
        Offset(left + gap + half, yc + half),
    )

    fun vertical(xc: Float, y0: Float, y1: Float): List<Offset> = listOf(
        Offset(xc, y0 + gap),
        Offset(xc + half, y0 + gap + half),
        Offset(xc + half, y1 - gap - half),
        Offset(xc, y1 - gap),
        Offset(xc - half, y1 - gap - half),
        Offset(xc - half, y0 + gap + half),
    )

    val top = half
    val bottom = h - half
    if (on[0]) blade(horizontal(top), h, brush)
    if (on[1]) blade(vertical(right - half, top, mid), h, brush)
    if (on[2]) blade(vertical(right - half, mid, bottom), h, brush)
    if (on[3]) blade(horizontal(bottom), h, brush)
    if (on[4]) blade(vertical(left + half, mid, bottom), h, brush)
    if (on[5]) blade(vertical(left + half, top, mid), h, brush)
    if (on[6]) blade(horizontal(mid), h, brush)
}

private fun DrawScope.drawColon(cx: Float, h: Float, brush: Brush) {
    val r = min(size.width, h) * 0.035f + 3f
    for (y in listOf(h * 0.34f, h * 0.66f)) {
        blade(
            listOf(Offset(cx, y - r * 1.4f), Offset(cx + r, y), Offset(cx, y + r * 1.4f), Offset(cx - r, y)),
            h,
            brush,
        )
    }
}
