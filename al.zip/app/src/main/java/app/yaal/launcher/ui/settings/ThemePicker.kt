package app.yaal.launcher.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.yaal.launcher.R
import app.yaal.launcher.data.ThemeId

private data class ThemeInfo(val id: ThemeId, val name: Int, val description: Int)

private val Themes = listOf(
    ThemeInfo(ThemeId.YAAL, R.string.theme_yaal, R.string.theme_yaal_desc),
    ThemeInfo(ThemeId.SENSE, R.string.theme_sense, R.string.theme_sense_desc),
    ThemeInfo(ThemeId.HOLO, R.string.theme_holo, R.string.theme_holo_desc),
    ThemeInfo(ThemeId.XPERIA, R.string.theme_xperia, R.string.theme_xperia_desc),
    ThemeInfo(ThemeId.MIUI, R.string.theme_miui, R.string.theme_miui_desc),
)

/** Lista de temas: tocar uno lo aplica al instante. */
@Composable
fun ThemePicker(selected: ThemeId, onApply: (ThemeId) -> Unit) {
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        Themes.forEach { info ->
            val isSelected = info.id == selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = if (isSelected) 0.12f else 0.07f))
                    .border(
                        BorderStroke(2.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent),
                        RoundedCornerShape(22.dp),
                    )
                    .clickable { onApply(info.id) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ThemePreview(info.id)
                Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
                    Text(
                        text = stringResource(info.name),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = stringResource(info.description),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.65f),
                        modifier = Modifier.padding(top = 4.dp),
                    )
                    if (isSelected) {
                        Text(
                            text = stringResource(R.string.theme_active),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Maqueta chica de cada tema, dibujada con formas simples. */
@Composable
private fun ThemePreview(id: ThemeId) {
    Canvas(
        modifier = Modifier
            .size(width = 76.dp, height = 128.dp)
            .clip(RoundedCornerShape(10.dp)),
    ) {
        val w = size.width
        val h = size.height
        val background = when (id) {
            ThemeId.YAAL -> listOf(Color(0xFF0E1A2B), Color(0xFF1F3A4D))
            ThemeId.SENSE -> listOf(Color(0xFF3A2A8F), Color(0xFFE0752B))
            ThemeId.HOLO -> listOf(Color(0xFF05080C), Color(0xFF0B2233))
            ThemeId.MIUI -> listOf(Color(0xFFE56B9A), Color(0xFF5B7FE0))
            ThemeId.XPERIA -> listOf(Color(0xFF0B1F3A), Color(0xFF1B6C9C))
        }
        drawRect(Brush.verticalGradient(background))

        when (id) {
            ThemeId.SENSE -> {
                card(Offset(w * 0.08f, h * 0.08f), Size(w * 0.38f, h * 0.2f), Color.White)
                card(Offset(w * 0.54f, h * 0.08f), Size(w * 0.38f, h * 0.2f), Color.White)
                bar(Offset(w * 0.06f, h * 0.32f), Size(w * 0.88f, h * 0.07f), Color(0xFF111111), Color(0xFF8CC63F))
                icons(h * 0.52f, 4, round = 0.5f, pill = true)
                drawRect(Color(0xFF222222), Offset(0f, h * 0.82f), Size(w, h * 0.18f))
                card(Offset(w * 0.28f, h * 0.86f), Size(w * 0.44f, h * 0.1f), Color(0xFF444444))
            }
            ThemeId.HOLO -> {
                card(Offset(w * 0.08f, h * 0.06f), Size(w * 0.84f, h * 0.07f), Color(0xFF1C1C1C))
                icons(h * 0.38f, 3, round = 0.5f, pill = false)
                icons(h * 0.58f, 3, round = 0.5f, pill = false)
                drawRect(Color(0xFF000000), Offset(0f, h * 0.84f), Size(w, h * 0.16f))
                drawRect(Color(0xFF33B5E5), Offset(w * 0.4f, h * 0.8f), Size(w * 0.2f, h * 0.012f))
            }
            ThemeId.XPERIA -> {
                drawRoundRect(Color.White.copy(alpha = 0.9f), Offset(w * 0.18f, h * 0.1f), Size(w * 0.64f, h * 0.05f), CornerRadius(4f, 4f))
                icons(h * 0.34f, 3, round = 0.28f, pill = false)
                icons(h * 0.54f, 3, round = 0.28f, pill = false)
                drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, h * 0.84f), Size(w, h * 0.16f))
                for (i in 0 until 3) {
                    for (j in 0 until 3) {
                        drawCircle(Color.White, 1.6f, Offset(w * 0.45f + i * 5.5f, h * 0.88f + j * 5.5f))
                    }
                }
            }
            ThemeId.MIUI -> {
                icons(h * 0.28f, 3, round = 0.32f, pill = false)
                icons(h * 0.5f, 3, round = 0.32f, pill = false)
                card(Offset(w * 0.08f, h * 0.8f), Size(w * 0.84f, h * 0.14f), Color.White.copy(alpha = 0.3f), radius = 22f)
            }
            ThemeId.YAAL -> {
                icons(h * 0.3f, 3, round = 0.5f, pill = false)
                icons(h * 0.5f, 3, round = 0.5f, pill = false)
                card(Offset(w * 0.08f, h * 0.8f), Size(w * 0.84f, h * 0.14f), Color.White.copy(alpha = 0.2f), radius = 26f)
            }
        }
    }
}

private fun DrawScope.card(at: Offset, size: Size, color: Color, radius: Float = 8f) {
    drawRoundRect(color, at, size, CornerRadius(radius, radius))
}

private fun DrawScope.bar(at: Offset, size: Size, color: Color, accent: Color) {
    drawRoundRect(color, at, size, CornerRadius(6f, 6f))
    drawRect(accent, Offset(at.x, at.y + size.height - 3f), Size(size.width, 3f))
}

/** Una fila de ítems de colores; [round] es cuánto se redondean (0.5 = círculo). */
private fun DrawScope.icons(y: Float, count: Int, round: Float, pill: Boolean) {
    val colors = listOf(Color(0xFFFFC857), Color(0xFF6EC1E4), Color(0xFFEE6C6C), Color(0xFF8FD694))
    val cell = size.width / count
    val side = cell * 0.5f
    for (i in 0 until count) {
        val x = cell * i + (cell - side) / 2f
        drawRoundRect(colors[i % colors.size], Offset(x, y), Size(side, side), CornerRadius(side * round, side * round))
        if (pill) {
            drawRoundRect(Color.Black.copy(alpha = 0.55f), Offset(x - 2f, y + side + 3f), Size(side + 4f, 7f), CornerRadius(4f, 4f))
        }
    }
}
