package app.yaal.launcher.data

/** Carpeta del cajón de apps: agrupa apps sin tocar el escritorio. */
data class DrawerFolder(val id: Long, val name: String, val keys: List<String>)

/** Operaciones puras sobre las carpetas del cajón (una app está en una sola carpeta). */
object DrawerFolders {

    fun create(folders: List<DrawerFolder>, name: String, key: String): List<DrawerFolder> {
        val id = (folders.maxOfOrNull { it.id } ?: 0L) + 1L
        return clean(folders, key) + DrawerFolder(id, name.trim(), listOf(key))
    }

    fun add(folders: List<DrawerFolder>, folderId: Long, key: String): List<DrawerFolder> {
        if (folders.none { it.id == folderId }) return folders
        return clean(folders, key).map { if (it.id == folderId) it.copy(keys = it.keys + key) else it }
    }

    fun remove(folders: List<DrawerFolder>, key: String): List<DrawerFolder> = clean(folders, key)

    fun delete(folders: List<DrawerFolder>, folderId: Long): List<DrawerFolder> = folders.filterNot { it.id == folderId }

    fun rename(folders: List<DrawerFolder>, folderId: Long, name: String): List<DrawerFolder> =
        folders.map { if (it.id == folderId) it.copy(name = name.trim()) else it }

    fun folderOf(folders: List<DrawerFolder>, key: String): DrawerFolder? = folders.firstOrNull { key in it.keys }

    /** Saca [key] de donde esté y descarta las carpetas que queden vacías. */
    private fun clean(folders: List<DrawerFolder>, key: String): List<DrawerFolder> =
        folders.map { it.copy(keys = it.keys.filterNot { k -> k == key }) }.filter { it.keys.isNotEmpty() }
}
