package app.yaal.launcher.data

import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Caché en memoria de íconos ya dibujados, por app, tamaño y estilo. */
class IconCache(private val renderer: IconRenderer) {
    private val cache = LruCache<String, ImageBitmap>(500)

    private fun cacheKey(entry: AppEntry, px: Int, style: IconStyle) =
        "${entry.key}#$px#${style.shape}#${style.pack}"

    fun peek(entry: AppEntry, px: Int, style: IconStyle): ImageBitmap? = cache.get(cacheKey(entry, px, style))

    suspend fun load(entry: AppEntry, px: Int, style: IconStyle): ImageBitmap? {
        val key = cacheKey(entry, px, style)
        cache.get(key)?.let { return it }
        val bitmap = withContext(Dispatchers.Default) { renderer.render(entry, px, style)?.asImageBitmap() }
            ?: return null
        cache.put(key, bitmap)
        return bitmap
    }

    fun clear() = cache.evictAll()
}
