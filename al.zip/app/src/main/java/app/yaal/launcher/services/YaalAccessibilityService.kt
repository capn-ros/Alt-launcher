package app.yaal.launcher.services

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Servicio mínimo: no lee la pantalla ni recibe eventos. Solo existe para poder ejecutar
 * acciones globales del sistema (bloquear pantalla, apps recientes, ajustes rápidos).
 */
class YaalAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    companion object {
        @Volatile
        var instance: YaalAccessibilityService? = null
            private set
    }
}
