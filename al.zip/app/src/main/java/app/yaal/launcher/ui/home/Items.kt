package app.yaal.launcher.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.yaal.launcher.R
import app.yaal.launcher.container
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.data.BadgeStyle
import app.yaal.launcher.data.IconStyle

/**
 * Cómo se ven los íconos (forma, pack, tamaño del nombre, insignias). Se provee una vez arriba de
 * todo y lo leen los íconos del escritorio, el dock, el cajón y las carpetas.
 */
data class Appearance(
    val iconStyle: IconStyle = IconStyle(),
    val labelScale: Float = 1f,
    val labelLines: Int = 1,
    val badgeStyle: BadgeStyle = BadgeStyle.NONE,
    val badges: Map<String, Int> = emptyMap(),
    val folderFan: Boolean = false,
)

val LocalAppearance = compositionLocalOf { Appearance() }

private val BadgeColor = Color(0xFFFF5E62)

private val LabelStyle = TextStyle(
    color = Color.White,
    shadow = Shadow(color = Color(0xAA000000), offset = Offset(0f, 1.5f), blurRadius = 4f),
)

/** Ícono de una app; se pide al caché en segundo plano y aparece cuando está listo. */
@Composable
fun AppIcon(entry: AppEntry, size: Dp, modifier: Modifier = Modifier) {
    val cache = LocalContext.current.container.icons
    val style = LocalAppearance.current.iconStyle
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<ImageBitmap?>(cache.peek(entry, px, style), entry.key, px, style) {
        value = cache.load(entry, px, style) ?: value
    }
    Box(modifier.size(size)) {
        bitmap?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(size)) }
    }
}

/** Punto o número de notificaciones, según el estilo elegido. */
@Composable
fun BadgeMark(count: Int, style: BadgeStyle, modifier: Modifier = Modifier) {
    if (count <= 0 || style == BadgeStyle.NONE) return
    when (style) {
        BadgeStyle.DOT -> Box(
            modifier = modifier.size(12.dp).clip(CircleShape).background(BadgeColor),
        )
        BadgeStyle.COUNT -> Box(
            modifier = modifier
                .clip(RoundedCornerShape(50))
                .background(BadgeColor)
                .padding(horizontal = 5.dp, vertical = 1.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = if (count > 99) "99+" else count.toString(),
                color = Color.White,
                fontSize = 10.sp,
            )
        }
        BadgeStyle.NONE -> Unit
    }
}

@Composable
fun AppLabel(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    val look = LocalAppearance.current
    Text(
        text = text,
        style = LabelStyle.copy(fontSize = (11f * look.labelScale).sp),
        color = color,
        maxLines = look.labelLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        modifier = modifier.padding(top = 3.dp),
    )
}

/** App con su nombre debajo, centrada en la celda que le da [modifier]. */
@Composable
fun AppCell(entry: AppEntry, iconSize: Dp, showLabel: Boolean, modifier: Modifier = Modifier) {
    val look = LocalAppearance.current
    Column(
        modifier = modifier.padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box {
            AppIcon(entry, iconSize)
            BadgeMark(
                count = look.badges[entry.packageName] ?: 0,
                style = look.badgeStyle,
                modifier = Modifier.align(Alignment.TopEnd),
            )
        }
        if (showLabel) AppLabel(entry.label)
    }
}

/** Fila de la lista del cajón: ícono, nombre y insignia. */
@Composable
fun AppRow(entry: AppEntry, iconSize: Dp, modifier: Modifier = Modifier) {
    val look = LocalAppearance.current
    Row(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(entry, iconSize)
        Text(
            text = entry.label,
            color = Color.White,
            fontSize = (16f * look.labelScale).sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 16.dp).weight(1f),
        )
        BadgeMark(count = look.badges[entry.packageName] ?: 0, style = look.badgeStyle)
    }
}

/** Carpeta: cuadro translúcido con hasta 4 íconos en miniatura. */
@Composable
fun FolderCell(
    title: String,
    entries: List<AppEntry>,
    iconSize: Dp,
    showLabel: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(iconSize * 0.3f))
                .background(Color.White.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center,
        ) {
            val look = LocalAppearance.current
            if (look.folderFan && entries.isNotEmpty()) {
                // Abanico: los íconos salen como mechones desde un punto, el primero arriba de todos.
                val shown = entries.take(4)
                val icon = iconSize * 0.58f
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                    for (index in shown.indices.reversed()) {
                        val angle = (index - (shown.size - 1) / 2f) * 17f
                        AppIcon(
                            entry = shown[index],
                            size = icon,
                            modifier = Modifier
                                .padding(bottom = iconSize * 0.1f)
                                .graphicsLayer {
                                    rotationZ = angle
                                    transformOrigin = TransformOrigin(0.5f, 1.7f)
                                },
                        )
                    }
                }
            } else {
                val mini = iconSize * 0.36f
                val gap = iconSize * 0.05f
                Column(
                    verticalArrangement = Arrangement.spacedBy(gap),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    entries.take(4).chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            row.forEach { AppIcon(it, mini) }
                        }
                    }
                }
            }
        }
        if (showLabel) AppLabel(title.ifBlank { stringResource(R.string.folder_default) })
    }
}
