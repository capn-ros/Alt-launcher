package app.yaal.launcher.data

import android.content.pm.ApplicationInfo

/** Grupos del cajón, a partir de la categoría que cada app declara. */
enum class AppGroup {
    GAMES, SOCIAL, MEDIA, PRODUCTIVITY, NEWS, MAPS, OTHER;

    companion object {
        fun of(category: Int): AppGroup = when (category) {
            ApplicationInfo.CATEGORY_GAME -> GAMES
            ApplicationInfo.CATEGORY_SOCIAL -> SOCIAL
            ApplicationInfo.CATEGORY_AUDIO,
            ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_IMAGE,
            -> MEDIA
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> PRODUCTIVITY
            ApplicationInfo.CATEGORY_NEWS -> NEWS
            ApplicationInfo.CATEGORY_MAPS -> MAPS
            else -> OTHER
        }
    }
}
