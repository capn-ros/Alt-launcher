package app.yaal.launcher.ui.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.ui.home.AppIcon

/** Elegir dos o más apps para juntarlas en una carpeta nueva. */
@Composable
fun FolderPicker(apps: List<AppEntry>, onCreate: (List<String>) -> Unit, onDismiss: () -> Unit) {
    var selected by remember { mutableStateOf(setOf<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1A2029),
        shape = RoundedCornerShape(28.dp),
        title = { Text(stringResource(R.string.folder_pick_title)) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                items(apps, key = { it.key }) { entry ->
                    val checked = entry.key in selected
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent,
                            )
                            .clickable { selected = if (checked) selected - entry.key else selected + entry.key }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        AppIcon(entry, 36.dp)
                        Text(text = entry.label, modifier = Modifier.weight(1f), maxLines = 1)
                        Checkbox(checked = checked, onCheckedChange = null)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(selected.toList()) }, enabled = selected.size >= 2) {
                Text(stringResource(R.string.folder_create))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}
