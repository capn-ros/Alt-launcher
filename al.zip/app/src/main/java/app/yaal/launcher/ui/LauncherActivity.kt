package app.yaal.launcher.ui

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yaal.launcher.ui.theme.NightAmber
import app.yaal.launcher.ui.theme.rememberIsNight
import app.yaal.launcher.ui.theme.rememberWallpaperAccent
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.pm.ActivityInfo
import app.yaal.launcher.R
import app.yaal.launcher.container
import app.yaal.launcher.ui.theme.YaalTheme

class LauncherActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    private val widgetHost get() = applicationContext.container.widgetHost
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }

    // Widget que se está agregando: id reservado y proveedor elegido.
    private var pendingWidgetId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    private val bindLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) configureOrFinish() else abortWidget()
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { it.write(viewModel.exportBackup().toByteArray()) }
                        ?: error("sin salida")
                }.isSuccess
            }
            viewModel.messages.tryEmit(if (ok) R.string.backup_saved else R.string.backup_failed)
        }
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
                        ?: error("sin entrada")
                    viewModel.importBackup(text)
                }.getOrDefault(false)
            }
            viewModel.messages.tryEmit(if (ok) R.string.backup_restored else R.string.backup_failed)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val current by viewModel.settings.collectAsStateWithLifecycle()
            val wallpaper = rememberWallpaperAccent(current.wallpaperAccent)
            val night = rememberIsNight(current.nightWarm)
            // De noche el acento se entibia hacia el ámbar.
            val themed = current.accentColor?.let { Color(it) }
            val accent = when {
                themed != null -> themed
                night -> wallpaper?.let { lerp(it, NightAmber, 0.6f) } ?: NightAmber
                else -> wallpaper
            }
            YaalTheme(accent = accent) {
                LauncherRoot(
                    vm = viewModel,
                    onPickWidget = ::startAddWidget,
                    onExportBackup = { exportLauncher.launch("yaal-backup.json") },
                    onImportBackup = { importLauncher.launch(arrayOf("*/*")) },
                )
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.settings.collect { settings ->
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    if (settings.hideStatusBar) {
                        controller.hide(WindowInsetsCompat.Type.statusBars())
                    } else {
                        controller.show(WindowInsetsCompat.Type.statusBars())
                    }
                    requestedOrientation = if (settings.allowRotation) {
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
    }

    override fun onStop() {
        widgetHost.stopListening()
        super.onStop()
    }

    /** Botón Inicio estando ya en el launcher: vuelve a la primera página y cierra todo. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            viewModel.homeEvents.tryEmit(Unit)
        }
    }

    // ------------------------------------------------------------ widgets

    private fun startAddWidget(info: AppWidgetProviderInfo) {
        abortWidget()
        pendingWidgetId = widgetHost.allocateAppWidgetId()
        pendingInfo = info

        if (widgetManager.bindAppWidgetIdIfAllowed(pendingWidgetId, info.provider)) {
            configureOrFinish()
        } else {
            // El sistema pide permiso al usuario para enlazar el widget.
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            }
            try {
                bindLauncher.launch(intent)
            } catch (_: Exception) {
                abortWidget()
            }
        }
    }

    private fun configureOrFinish() {
        val info = pendingInfo
        if (info == null || pendingWidgetId == -1) return
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, pendingWidgetId, 0, REQUEST_CONFIGURE, null)
            } catch (_: Exception) {
                // Configuración inaccesible: se agrega igual con valores por defecto.
                finishWidget()
            }
        } else {
            finishWidget()
        }
    }

    private fun finishWidget() {
        val info = pendingInfo
        val id = pendingWidgetId
        pendingInfo = null
        pendingWidgetId = -1
        if (info != null && id != -1) viewModel.addWidget(id, info)
    }

    private fun abortWidget() {
        viewModel.cancelWidget(pendingWidgetId)
        pendingInfo = null
        pendingWidgetId = -1
    }

    @Deprecated("Necesario para recibir el resultado de la configuración del widget")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CONFIGURE) {
            if (resultCode == Activity.RESULT_OK) finishWidget() else abortWidget()
        }
    }

    private companion object {
        const val REQUEST_CONFIGURE = 1001
    }
}
