package app.yaal.launcher.ui

import android.app.WallpaperManager
import android.appwidget.AppWidgetProviderInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yaal.launcher.R
import app.yaal.launcher.data.AppEntry
import app.yaal.launcher.data.GestureAction
import app.yaal.launcher.data.GestureBinding
import app.yaal.launcher.data.DockStyle
import app.yaal.launcher.data.IconStyle
import app.yaal.launcher.data.LabelStyle
import app.yaal.launcher.data.LauncherSettings
import app.yaal.launcher.data.PageEffect
import app.yaal.launcher.data.PageIndicator
import app.yaal.launcher.domain.Container
import app.yaal.launcher.domain.HomeItem
import app.yaal.launcher.domain.ItemKind
import app.yaal.launcher.domain.LayoutOps
import app.yaal.launcher.ui.drawer.AppDrawer
import app.yaal.launcher.ui.home.AppCell
import app.yaal.launcher.ui.home.AppIcon
import app.yaal.launcher.ui.home.Appearance
import app.yaal.launcher.ui.home.DragController
import app.yaal.launcher.ui.home.DragPayload
import app.yaal.launcher.ui.home.DragRelease
import app.yaal.launcher.ui.home.DropTarget
import app.yaal.launcher.ui.home.FolderCell
import app.yaal.launcher.ui.home.FolderPopup
import app.yaal.launcher.ui.home.QuickBar
import app.yaal.launcher.ui.home.RadialMenu
import app.yaal.launcher.ui.home.SenseDock
import app.yaal.launcher.ui.home.YaalClock
import app.yaal.launcher.ui.theme.NightAmber
import app.yaal.launcher.ui.theme.rememberIsNight
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import kotlin.math.PI
import kotlin.math.sin
import app.yaal.launcher.ui.home.LocalAppearance
import app.yaal.launcher.ui.home.WidgetItem
import app.yaal.launcher.ui.home.dragSource
import app.yaal.launcher.ui.menu.ActionSheet
import app.yaal.launcher.data.DrawerFolder
import app.yaal.launcher.ui.menu.DrawerFolderDialog
import app.yaal.launcher.ui.menu.FolderPicker
import app.yaal.launcher.ui.menu.RenameDialog
import app.yaal.launcher.ui.menu.SheetAction
import app.yaal.launcher.ui.settings.SettingsActions
import app.yaal.launcher.ui.settings.SettingsScreen
import app.yaal.launcher.ui.widgets.ResizeDialog
import app.yaal.launcher.ui.widgets.WidgetPicker
import app.yaal.launcher.util.SystemActions
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Qué elemento tiene abierto el menú contextual. */
private sealed interface SheetTarget {
    data class OnHomeItem(val item: HomeItem) : SheetTarget
    data class OnDrawerApp(val entry: AppEntry) : SheetTarget
}

private val BaseIconSize = 56.dp
private val DockIconSize = 52.dp

/**
 * Pantalla del launcher: escritorio con páginas, dock, cajón de apps, carpetas, menús y ajustes.
 * Todo el arrastre (escritorio, dock, cajón, carpetas, widgets) pasa por un único [DragController].
 */
@Composable
fun LauncherRoot(
    vm: LauncherViewModel,
    onPickWidget: (AppWidgetProviderInfo) -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()

    val settings by vm.settings.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val appsByKey by vm.appsByKey.collectAsStateWithLifecycle()
    val allApps by vm.apps.collectAsStateWithLifecycle()
    val visibleApps by vm.visibleApps.collectAsStateWithLifecycle()
    val hiddenApps by vm.hiddenApps.collectAsStateWithLifecycle()
    val badges by vm.badges.collectAsStateWithLifecycle()
    val grid = settings.grid()

    val drag = remember { DragController() }
    val drawer = remember { Animatable(0f) }
    val drawerVisible by remember { derivedStateOf { drawer.value > 0.001f } }

    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    var gridBounds by remember { mutableStateOf(Rect.Zero) }
    var dockBounds by remember { mutableStateOf(Rect.Zero) }
    var openFolderId by remember { mutableStateOf<Long?>(null) }
    var sheet by remember { mutableStateOf<SheetTarget?>(null) }
    var showDesktopMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showWidgets by remember { mutableStateOf(false) }
    var resizeItemId by remember { mutableStateOf<Long?>(null) }
    var renameTarget by remember { mutableStateOf<AppEntry?>(null) }
    var showFolderPicker by remember { mutableStateOf(false) }
    var openDrawerFolderId by remember { mutableStateOf<Long?>(null) }
    var drawerFolderMenu by remember { mutableStateOf<DrawerFolder?>(null) }
    var moveToFolder by remember { mutableStateOf<AppEntry?>(null) }
    var scrollToPage by remember { mutableIntStateOf(-1) }
    var focusSearch by remember { mutableStateOf(false) }
    var lastDrawerDy by remember { mutableFloatStateOf(0f) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var menuAnchor by remember { mutableStateOf(Offset.Zero) }
    val wind = remember { Animatable(0f) }
    val night = rememberIsNight(settings.nightWarm)
    val haptics by rememberUpdatedState(Haptics(view, settings.haptics))

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { resumeTick++ }

    val realPages = maxOf(LayoutOps.pageCount(items), settings.minPages)
    val pageCount = realPages + if (drag.active) 1 else 0
    val pagerState = rememberPagerState(pageCount = { pageCount })

    val statusTopPx = WindowInsets.statusBars.getTop(density)
    val topZonePx = statusTopPx + with(density) { 72.dp.toPx() }

    // ---------------------------------------------------------------- cajón

    val drawerHeightPx = rootSize.height.toFloat().coerceAtLeast(1f)
    val dragDrawer: (Float) -> Unit = { dy ->
        lastDrawerDy = dy
        scope.launch { drawer.snapTo((drawer.value - dy / drawerHeightPx).coerceIn(0f, 1f)) }
    }
    val settleDrawer: () -> Unit = {
        scope.launch {
            val value = drawer.value
            val open = when {
                lastDrawerDy < -2f -> value > 0.08f
                lastDrawerDy > 2f -> value > 0.92f
                else -> value > 0.5f
            }
            drawer.animateTo(if (open) 1f else 0f, tween(220))
        }
    }
    val openDrawer: () -> Unit = { scope.launch { drawer.animateTo(1f, tween(220)) } }
    val currentDragDrawer by rememberUpdatedState(dragDrawer)
    val currentSettleDrawer by rememberUpdatedState(settleDrawer)

    // ---------------------------------------------------------------- gestos

    val needAccessibility: () -> Unit = {
        Toast.makeText(context, context.getString(R.string.need_accessibility), Toast.LENGTH_LONG).show()
        SystemActions.openAccessibilitySettings(context)
    }
    val perform: (GestureBinding) -> Unit = { binding ->
        when (binding.action) {
            GestureAction.NONE -> Unit
            GestureAction.DRAWER -> openDrawer()
            GestureAction.SEARCH -> {
                focusSearch = true
                openDrawer()
            }
            GestureAction.NOTIFICATIONS -> SystemActions.expandNotifications(context)
            GestureAction.QUICK_SETTINGS -> SystemActions.expandQuickSettings(context)
            GestureAction.LOCK -> if (!SystemActions.lockScreen()) needAccessibility()
            GestureAction.RECENTS -> if (!SystemActions.openRecents()) needAccessibility()
            GestureAction.DESKTOP_MENU -> showDesktopMenu = true
            GestureAction.SETTINGS -> showSettings = true
            GestureAction.OPEN_APP -> binding.appKey?.let { vm.launchByKey(it) }
        }
    }

    // ---------------------------------------------------------------- arrastre

    fun entryOf(payload: DragPayload): AppEntry? = when (payload) {
        is DragPayload.Home -> payload.item.appKey?.let { appsByKey[it] }
        is DragPayload.Drawer -> payload.entry
        is DragPayload.FolderChild -> payload.entry
    }

    // La zona de soltar en el dock es algo más generosa que el dock dibujado.
    val dockExtraPx = with(density) { 32.dp.toPx() }
    fun inDock(pos: Offset): Boolean =
        settings.showDock && dockBounds != Rect.Zero &&
            pos.x in dockBounds.left..dockBounds.right &&
            pos.y >= dockBounds.top - dockExtraPx

    fun resolveTarget(payload: DragPayload, pos: Offset): DropTarget {
        if (pos.y < topZonePx) {
            val third = (pos.x / rootSize.width.coerceAtLeast(1) * 3).toInt()
            return when (third) {
                0 -> DropTarget.Remove
                1 -> DropTarget.Info
                else -> DropTarget.Uninstall
            }
        }
        if (inDock(pos)) {
            val slot = ((pos.x - dockBounds.left) / dockBounds.width * grid.dockSlots).toInt()
            return DropTarget.Dock(slot.coerceIn(0, grid.dockSlots - 1))
        }
        if (gridBounds.contains(pos)) {
            val cellW = gridBounds.width / grid.columns
            val cellH = gridBounds.height / grid.rows
            var cx = ((pos.x - gridBounds.left) / cellW).toInt()
            var cy = ((pos.y - gridBounds.top) / cellH).toInt()
            if (payload is DragPayload.Home && payload.item.kind == ItemKind.WIDGET) {
                // El widget se centra bajo el dedo en vez de colgar de su esquina.
                cx -= payload.item.spanX / 2
                cy -= payload.item.spanY / 2
            }
            return DropTarget.Desktop(
                page = pagerState.currentPage,
                x = cx.coerceIn(0, grid.columns - 1),
                y = cy.coerceIn(0, grid.rows - 1),
            )
        }
        return DropTarget.None
    }

    val onRelease: DragRelease = { payload, pos, moved ->
        if (!moved) {
            menuAnchor = pos
            haptics.tick()
            // Mantener apretado y soltar sin mover: menú contextual.
            when (payload) {
                is DragPayload.Home -> sheet = SheetTarget.OnHomeItem(payload.item)
                is DragPayload.Drawer -> sheet = SheetTarget.OnDrawerApp(payload.entry)
                is DragPayload.FolderChild -> if (payload.folderId < 0L) sheet = SheetTarget.OnDrawerApp(payload.entry)
            }
        } else {
            val resolved = resolveTarget(payload, pos)
            if (resolved != DropTarget.None) haptics.drop()
            when (val target = resolved) {
                DropTarget.Remove -> if (payload is DragPayload.Home) vm.removeItem(payload.item)
                DropTarget.Info -> entryOf(payload)?.let { vm.showAppInfo(it) }
                DropTarget.Uninstall -> entryOf(payload)?.let { vm.uninstall(it) }
                is DropTarget.Desktop -> vm.drop(payload, target)
                is DropTarget.Dock -> vm.drop(payload, target)
                DropTarget.None -> Unit
            }
            if (payload is DragPayload.FolderChild) {
                openFolderId = null
                openDrawerFolderId = null
            }
        }
    }

    // ---------------------------------------------------------------- efectos

    LaunchedEffect(pagerState.currentPage) { vm.currentPage = pagerState.currentPage }

    // En el dock de tres botones no se puede soltar nada: se borra la zona vieja.
    LaunchedEffect(settings.dockStyle, settings.showDock) {
        if (settings.dockStyle == DockStyle.SENSE || !settings.showDock) dockBounds = Rect.Zero
    }

    // Después de crear una página, se va a ella cuando ya existe.
    LaunchedEffect(scrollToPage) {
        val target = scrollToPage
        if (target >= 0) {
            snapshotFlow { pagerState.pageCount }.first { it > target }
            pagerState.animateScrollToPage(target)
            scrollToPage = -1
        }
    }

    // Háptica: levantar algo y cambiar de página.
    LaunchedEffect(drag.active) { if (drag.active) haptics.pick() }
    LaunchedEffect(Unit) {
        var last = pagerState.currentPage
        snapshotFlow { pagerState.currentPage }.collect { page ->
            if (page != last) {
                last = page
                haptics.tick()
            }
        }
    }

    // Viento: al deslizar entre páginas los íconos se inclinan contra el movimiento y se asientan oscilando.
    LaunchedEffect(settings.windEffect) {
        if (!settings.windEffect) {
            wind.snapTo(0f)
            return@LaunchedEffect
        }
        var last = pagerState.currentPage + pagerState.currentPageOffsetFraction
        snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction }.collectLatest { position ->
            val delta = position - last
            last = position
            if (delta != 0f) wind.snapTo((wind.value - delta * 70f).coerceIn(-14f, 14f))
            delay(45)
            wind.animateTo(0f, spring(dampingRatio = 0.28f, stiffness = Spring.StiffnessVeryLow))
        }
    }

    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(context, context.getString(it), Toast.LENGTH_SHORT).show() }
    }

    LaunchedEffect(Unit) {
        vm.homeEvents.collect {
            val somethingOpen = openFolderId != null || sheet != null || showDesktopMenu || showSettings ||
                showWidgets || resizeItemId != null || renameTarget != null || drawerVisible
            openFolderId = null
            sheet = null
            showDesktopMenu = false
            showSettings = false
            showWidgets = false
            resizeItemId = null
            renameTarget = null
            drawer.animateTo(0f, tween(200))
            if (somethingOpen || pagerState.currentPage != 0) {
                pagerState.animateScrollToPage(0)
            } else {
                // Ya estaba todo cerrado en la primera página: se ejecuta el gesto del botón Inicio.
                perform(settings.homeButton)
            }
        }
    }

    // Arrastrar una app del cajón hacia el escritorio: el cajón se retira.
    // Solo cuando el dedo realmente se mueve: si lo suelta quieto, queda el menú de la app.
    LaunchedEffect(drag.payload) {
        if (drag.payload is DragPayload.Drawer) {
            snapshotFlow { drag.moved }.first { it }
            drawer.animateTo(0f, tween(180))
        }
    }

    // Mantener el dedo en un borde mientras se arrastra cambia de página.
    LaunchedEffect(drag.active) {
        if (!drag.active) return@LaunchedEffect
        val edge = with(density) { 40.dp.toPx() }
        snapshotFlow {
            val x = drag.position.x
            when {
                x < edge -> -1
                x > rootSize.width - edge -> 1
                else -> 0
            }
        }.collectLatest { direction ->
            if (direction != 0) {
                while (true) {
                    delay(650)
                    val y = drag.position.y
                    if (y > topZonePx && y < dockBounds.top) {
                        val target = pagerState.currentPage + direction
                        if (target in 0 until pagerState.pageCount) pagerState.animateScrollToPage(target)
                    }
                }
            }
        }
    }

    // El fondo de pantalla acompaña el desplazamiento entre páginas.
    LaunchedEffect(settings.wallpaperScroll, pageCount) {
        val wallpaper = WallpaperManager.getInstance(context)
        if (!settings.wallpaperScroll || pageCount <= 1) {
            runCatching { wallpaper.setWallpaperOffsets(view.windowToken, 0.5f, 0.5f) }
            return@LaunchedEffect
        }
        runCatching { wallpaper.setWallpaperOffsetSteps(1f / (pageCount - 1), 1f) }
        snapshotFlow { (pagerState.currentPage + pagerState.currentPageOffsetFraction) / (pageCount - 1) }
            .collect { x -> runCatching { wallpaper.setWallpaperOffsets(view.windowToken, x.coerceIn(0f, 1f), 0.5f) } }
    }

    BackHandler(enabled = drawerVisible) {
        scope.launch { drawer.animateTo(0f, tween(200)) }
    }
    BackHandler(enabled = !drawerVisible) {
        scope.launch { pagerState.animateScrollToPage(0) }
    }

    // ---------------------------------------------------------------- interfaz

    val iconSize = BaseIconSize * settings.iconScale
    val cellWidthDp = with(density) { (gridBounds.width / grid.columns).toDp() }
    val cellHeightDp = with(density) { (gridBounds.height / grid.rows).toDp() }
    val appearance = remember(settings.iconShape, settings.iconPack, settings.labelScale, settings.labelLines, settings.badgeStyle, badges, settings.folderFan, settings.labelStyle) {
        Appearance(
            iconStyle = IconStyle(settings.iconShape, settings.iconPack),
            labelScale = settings.labelScale,
            labelLines = settings.labelLines,
            badgeStyle = settings.badgeStyle,
            badges = badges,
            folderFan = settings.folderFan,
            labelPill = settings.labelStyle == LabelStyle.PILL,
        )
    }
    val accessibilityOn = remember(resumeTick, showSettings) { SystemActions.isAccessibilityEnabled() }
    val notificationAccessOn = remember(resumeTick, showSettings) { SystemActions.isNotificationAccessEnabled(context) }

    CompositionLocalProvider(LocalAppearance provides appearance) {
        Box(modifier = Modifier.fillMaxSize().onSizeChanged { rootSize = it }) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = settings.dim)))
            if (night) Box(modifier = Modifier.fillMaxSize().background(NightAmber.copy(alpha = 0.07f)))

            // Capa del escritorio; se desvanece al abrirse el cajón.
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = drawer.value
                        if (settings.depthEffect) {
                            // El escritorio se aleja y se desenfoca (el desenfoque solo existe en Android 12+).
                            val scale = 1f - 0.07f * p
                            scaleX = scale
                            scaleY = scale
                            alpha = 1f - 0.65f * p
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && p > 0.03f) {
                                renderEffect = BlurEffect(18f * p, 18f * p, TileMode.Decal)
                            }
                        } else {
                            alpha = 1f - p
                        }
                    }
                    .statusBarsPadding(),
            ) {
                if (settings.desktopSearchBar) {
                    SearchPill(
                        light = settings.searchLight,
                        onClick = {
                            focusSearch = true
                            openDrawer()
                        },
                    )
                }

                YaalClock(settings.clockStyle)
                if (settings.quickBar) QuickBar(accent = MaterialTheme.colorScheme.primary)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(settings.margin.dp)
                        .onGloballyPositioned { coordinates ->
                            val bounds = coordinates.boundsInWindow()
                            gridBounds = bounds
                            vm.cellWidthPx = bounds.width / grid.columns
                            vm.cellHeightPx = bounds.height / grid.rows
                        }
                        .pointerInput(settings.swipeUp, settings.swipeDown) {
                            // Deslizar hacia arriba abre el cajón (o hace otra acción); hacia abajo, la acción elegida.
                            var total = 0f
                            val threshold = 96.dp.toPx()
                            detectVerticalDragGestures(
                                onDragStart = {
                                    total = 0f
                                    lastDrawerDy = 0f
                                },
                                onDragEnd = {
                                    val up = settings.swipeUp
                                    val down = settings.swipeDown
                                    when {
                                        total > threshold && down.action != GestureAction.NONE && drawer.value < 0.01f ->
                                            perform(down)
                                        total < -threshold && up.action != GestureAction.DRAWER &&
                                            up.action != GestureAction.NONE -> perform(up)
                                        else -> currentSettleDrawer()
                                    }
                                },
                                onDragCancel = { currentSettleDrawer() },
                                onVerticalDrag = { change, dy ->
                                    change.consume()
                                    total += dy
                                    if (settings.swipeUp.action == GestureAction.DRAWER) currentDragDrawer(dy)
                                },
                            )
                        },
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        userScrollEnabled = !drag.active,
                    ) { page ->
                        DesktopPage(
                            page = page,
                            items = items.filter { it.container == Container.DESKTOP && it.page == page },
                            appsByKey = appsByKey,
                            settings = settings,
                            drag = drag,
                            iconSize = iconSize,
                            onLongPressEmpty = { showDesktopMenu = true },
                            onDoubleTap = { perform(settings.doubleTap) },
                            onLaunch = { vm.launch(it, drag.tapBounds) },
                            onOpenFolder = { openFolderId = it.id },
                            onRelease = onRelease,
                            onMissingWidget = { vm.removeItem(it) },
                            wind = { wind.value },
                            modifier = Modifier.pageEffect(pagerState, page, settings.pageEffect),
                        )
                    }
                }

                PageIndicatorBar(style = settings.pageIndicator, count = pageCount, state = pagerState)

                if (settings.showDock && settings.dockStyle == DockStyle.SENSE) {
                    // Dock de tres botones: las apps del dock quedan guardadas pero no se ven en este tema.
                    SenseDock(
                        onDrawer = openDrawer,
                        onCustomize = { showDesktopMenu = true },
                        modifier = Modifier.navigationBarsPadding(),
                    )
                } else if (settings.showDock) {
                    val flat = settings.dockStyle == DockStyle.BAR
                    Box(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(horizontal = if (flat) 0.dp else 12.dp, vertical = if (flat) 0.dp else 8.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(if (flat) 0.dp else 28.dp))
                                .background(
                                    Color.Black.copy(
                                        alpha = if (drag.active && inDock(drag.position)) {
                                            (settings.dockOpacity + 0.28f).coerceAtMost(0.8f)
                                        } else {
                                            settings.dockOpacity
                                        },
                                    ),
                                )
                                .onGloballyPositioned { dockBounds = it.boundsInWindow() }
                                .pointerInput(Unit) {
                                    // Deslizar hacia arriba desde el dock siempre abre el cajón.
                                    detectVerticalDragGestures(
                                        onDragStart = { lastDrawerDy = 0f },
                                        onDragEnd = { currentSettleDrawer() },
                                        onDragCancel = { currentSettleDrawer() },
                                        onVerticalDrag = { change, dy ->
                                            change.consume()
                                            currentDragDrawer(dy)
                                        },
                                    )
                                }
                                .padding(vertical = 6.dp),
                        ) {
                            for (slot in 0 until grid.dockSlots) {
                                Box(
                                    modifier = Modifier.weight(1f).height(72.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    val item = items.firstOrNull { it.container == Container.DOCK && it.x == slot }
                                    if (item != null) {
                                        PlacedItem(
                                            item = item,
                                            appsByKey = appsByKey,
                                            drag = drag,
                                            lock = settings.lockLayout,
                                            iconSize = DockIconSize * settings.dockIconScale,
                                            showLabel = false,
                                            onLaunch = { vm.launch(it, drag.tapBounds) },
                                            onOpenFolder = { openFolderId = it.id },
                                            onRelease = onRelease,
                                            wind = { wind.value * 0.6f },
                                            modifier = Modifier,
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Spacer(Modifier.navigationBarsPadding().height(8.dp))
                }
            }

            if (drawerVisible || drag.payload is DragPayload.Drawer) {
                AppDrawer(
                    apps = visibleApps,
                    settings = settings,
                    progress = { drawer.value },
                    drag = drag,
                    focusSearch = focusSearch,
                    onFocusHandled = { focusSearch = false },
                    onLaunch = { vm.launch(it, drag.tapBounds) },
                    onRelease = onRelease,
                    onWebSearch = { SystemActions.webSearch(context, it) },
                    onDrawerDrag = dragDrawer,
                    onDrawerSettle = settleDrawer,
                    folders = settings.drawerFolders,
                    onOpenFolder = { openDrawerFolderId = it.id },
                    onFolderMenu = { drawerFolderMenu = it },
                )
            }

            val openFolder = openFolderId?.let { id -> items.firstOrNull { it.id == id } }
            if (openFolderId != null && openFolder == null) {
                LaunchedEffect(openFolderId) { openFolderId = null }
            }
            if (openFolder != null) {
                FolderPopup(
                    folder = openFolder,
                    entries = openFolder.children.mapNotNull { appsByKey[it] },
                    drag = drag,
                    iconSize = iconSize,
                    columns = settings.folderColumns,
                    onLaunch = { entry ->
                        openFolderId = null
                        vm.launch(entry, drag.tapBounds)
                    },
                    onRelease = onRelease,
                    onRename = { title -> vm.renameFolder(openFolder.id, title) },
                    onDismiss = { openFolderId = null },
                )
            }

            val drawerFolder = openDrawerFolderId?.let { id -> settings.drawerFolders.firstOrNull { it.id == id } }
            if (openDrawerFolderId != null && drawerFolder == null) {
                LaunchedEffect(openDrawerFolderId) { openDrawerFolderId = null }
            }
            if (drawerFolder != null) {
                FolderPopup(
                    folder = HomeItem(
                        id = -drawerFolder.id,
                        kind = ItemKind.FOLDER,
                        container = Container.DESKTOP,
                        title = drawerFolder.name,
                        children = drawerFolder.keys,
                    ),
                    entries = drawerFolder.keys.mapNotNull { appsByKey[it] },
                    drag = drag,
                    iconSize = iconSize,
                    columns = settings.folderColumns,
                    onLaunch = { entry ->
                        openDrawerFolderId = null
                        vm.launch(entry, drag.tapBounds)
                    },
                    onRelease = onRelease,
                    onRename = { title -> vm.renameDrawerFolder(drawerFolder.id, title) },
                    onDismiss = { openDrawerFolderId = null },
                )
            }

            drawerFolderMenu?.let { folder ->
                val rename = stringResource(R.string.menu_rename)
                val delete = stringResource(R.string.menu_delete_folder)
                ActionSheet(
                    title = folder.name.ifBlank { stringResource(R.string.folder_default) },
                    actions = listOf(
                        SheetAction(rename) { openDrawerFolderId = folder.id },
                        SheetAction(delete, destructive = true) { vm.deleteDrawerFolder(folder.id) },
                    ),
                    onDismiss = { drawerFolderMenu = null },
                )
            }

            moveToFolder?.let { entry ->
                DrawerFolderDialog(
                    folders = settings.drawerFolders,
                    onPick = { id ->
                        vm.addToDrawerFolder(id, entry)
                        moveToFolder = null
                    },
                    onCreate = { name ->
                        vm.createDrawerFolder(name, entry)
                        moveToFolder = null
                    },
                    onDismiss = { moveToFolder = null },
                )
            }

            sheet?.let { target ->
                val dismiss = { sheet = null }
                when (target) {
                    is SheetTarget.OnDrawerApp -> AppSheet(
                        vm = vm,
                        entry = target.entry,
                        fromDrawer = true,
                        homeItem = null,
                        onAddedToDesktop = { scope.launch { drawer.animateTo(0f, tween(200)) } },
                        onMoveToFolder = { moveToFolder = it },
                        inDrawerFolder = settings.drawerFolders.any { target.entry.key in it.keys },
                        onRename = { renameTarget = it },
                        onDismiss = dismiss,
                        radial = settings.radialMenu,
                        anchor = menuAnchor,
                        rootSize = rootSize,
                    )
                    is SheetTarget.OnHomeItem -> {
                        val item = target.item
                        val entry = item.appKey?.let { appsByKey[it] }
                        when {
                            item.kind == ItemKind.APP && entry != null -> AppSheet(
                                vm = vm,
                                entry = entry,
                                fromDrawer = false,
                                homeItem = item,
                                onAddedToDesktop = {},
                                onRename = { renameTarget = it },
                                onDismiss = dismiss,
                                radial = settings.radialMenu,
                                anchor = menuAnchor,
                                rootSize = rootSize,
                            )
                            item.kind == ItemKind.FOLDER -> {
                                val rename = stringResource(R.string.menu_rename)
                                val remove = stringResource(R.string.menu_remove)
                                MenuHost(
                                    radial = settings.radialMenu,
                                    anchor = menuAnchor,
                                    rootSize = rootSize,
                                    title = item.title.ifBlank { stringResource(R.string.folder_default) },
                                    actions = listOf(
                                        SheetAction(rename) { openFolderId = item.id },
                                        SheetAction(remove, destructive = true) { vm.removeItem(item) },
                                    ),
                                    onDismiss = dismiss,
                                )
                            }
                            item.kind == ItemKind.WIDGET -> {
                                val resize = stringResource(R.string.menu_resize)
                                val remove = stringResource(R.string.menu_remove)
                                MenuHost(
                                    radial = settings.radialMenu,
                                    anchor = menuAnchor,
                                    rootSize = rootSize,
                                    title = "",
                                    actions = listOf(
                                        SheetAction(resize) { resizeItemId = item.id },
                                        SheetAction(remove, destructive = true) { vm.removeItem(item) },
                                    ),
                                    onDismiss = dismiss,
                                )
                            }
                            else -> LaunchedEffect(target) { sheet = null }
                        }
                    }
                }
            }

            if (showDesktopMenu) {
                val widgets = stringResource(R.string.menu_widgets)
                val wallpaper = stringResource(R.string.menu_wallpaper)
                val settingsLabel = stringResource(R.string.menu_settings)
                val newPage = stringResource(R.string.menu_new_page)
                val removePage = stringResource(R.string.menu_remove_page)
                val newFolder = stringResource(R.string.menu_new_folder)
                ActionSheet(
                    title = "",
                    actions = listOfNotNull(
                        SheetAction(newFolder) { showFolderPicker = true },
                        SheetAction(newPage) { scrollToPage = vm.addPage() },
                        if (realPages > 1) SheetAction(removePage) { vm.removePage(pagerState.currentPage) } else null,
                        SheetAction(widgets) { showWidgets = true },
                        SheetAction(wallpaper) { SystemActions.openWallpaperPicker(context) },
                        SheetAction(settingsLabel) { showSettings = true },
                    ),
                    onDismiss = { showDesktopMenu = false },
                )
            }

            if (showFolderPicker) {
                FolderPicker(
                    apps = visibleApps,
                    onCreate = { keys ->
                        showFolderPicker = false
                        vm.createFolder(keys)
                    },
                    onDismiss = { showFolderPicker = false },
                )
            }

            if (showWidgets) {
                WidgetPicker(
                    onPick = { info ->
                        showWidgets = false
                        onPickWidget(info)
                    },
                    onDismiss = { showWidgets = false },
                )
            }

            if (showSettings) {
                SettingsScreen(
                    settings = settings,
                    apps = allApps,
                    hiddenApps = hiddenApps,
                    iconPacks = remember { vm.availableIconPacks() },
                    accessibilityEnabled = accessibilityOn,
                    notificationAccess = notificationAccessOn,
                    actions = SettingsActions(
                        onUpdate = { transform -> vm.updateSettings(transform) },
                        onShowApp = { vm.showApp(it) },
                        onDefaultLauncher = { SystemActions.openDefaultLauncherSettings(context) },
                        onReset = {
                            vm.resetLayout()
                            showSettings = false
                        },
                        onExport = onExportBackup,
                        onImport = onImportBackup,
                        onAccessibility = { SystemActions.openAccessibilitySettings(context) },
                        onNotificationAccess = { SystemActions.openNotificationAccessSettings(context) },
                        onClose = { showSettings = false },
                    ),
                )
            }

            val resizeItem = resizeItemId?.let { id -> items.firstOrNull { it.id == id } }
            if (resizeItem != null) {
                ResizeDialog(
                    item = resizeItem,
                    grid = grid,
                    onApply = { spanX, spanY -> if (vm.resize(resizeItem, spanX, spanY)) resizeItemId = null },
                    onDismiss = { resizeItemId = null },
                )
            }

            renameTarget?.let { target ->
                RenameDialog(
                    entry = target,
                    onConfirm = { name ->
                        vm.renameApp(target, name)
                        renameTarget = null
                    },
                    onDismiss = { renameTarget = null },
                )
            }

            if (drag.active) {
                TopDropZones(drag = drag, zoneHeightPx = topZonePx, rootWidthPx = rootSize.width)
                DragGhost(
                    drag = drag,
                    appsByKey = appsByKey,
                    iconSize = iconSize,
                    cellWidth = cellWidthDp,
                    cellHeight = cellHeightDp,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------- piezas

/** Efecto visual al pasar de una página a otra (todo ocurre en la capa gráfica, sin recomponer). */
private fun Modifier.pageEffect(state: PagerState, page: Int, effect: PageEffect): Modifier {
    if (effect == PageEffect.SIMPLE) return this
    return graphicsLayer {
        // Positivo: la página está a la izquierda de la actual; negativo: a la derecha.
        val offset = ((state.currentPage - page) + state.currentPageOffsetFraction).coerceIn(-1f, 1f)
        val amount = abs(offset)
        when (effect) {
            PageEffect.CUBE -> {
                cameraDistance = 12f * density
                transformOrigin = TransformOrigin(if (offset > 0f) 1f else 0f, 0.5f)
                rotationY = -90f * offset
            }
            PageEffect.CARDS -> if (offset > 0f) {
                // La página que sale se queda quieta, se achica y se desvanece debajo de la que entra.
                translationX = size.width * offset
                scaleX = 1f - 0.12f * amount
                scaleY = 1f - 0.12f * amount
                alpha = 1f - amount
            }
            PageEffect.ZOOM -> {
                scaleX = 1f - 0.3f * amount
                scaleY = 1f - 0.3f * amount
                alpha = 1f - 0.6f * amount
            }
            PageEffect.ROTATE -> {
                transformOrigin = TransformOrigin(0.5f, 1f)
                rotationZ = -15f * offset
                alpha = 1f - 0.5f * amount
            }
            PageEffect.FLIP -> {
                cameraDistance = 12f * density
                translationX = size.width * offset
                rotationY = 180f * offset
                alpha = if (amount > 0.5f) 0f else 1f
            }
            PageEffect.SIMPLE -> Unit
        }
    }
}

@Composable
private fun DesktopPage(
    page: Int,
    items: List<HomeItem>,
    appsByKey: Map<String, AppEntry>,
    settings: LauncherSettings,
    drag: DragController,
    iconSize: Dp,
    onLongPressEmpty: () -> Unit,
    onDoubleTap: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onOpenFolder: (HomeItem) -> Unit,
    onRelease: DragRelease,
    onMissingWidget: (HomeItem) -> Unit,
    wind: () -> Float,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val cellW = maxWidth / settings.columns
        val cellH = maxHeight / settings.rows

        // Fondo: mantener apretado en un lugar vacío abre el menú; doble toque, la acción elegida.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(page) {
                    detectTapGestures(
                        onLongPress = { onLongPressEmpty() },
                        onDoubleTap = { onDoubleTap() },
                    )
                },
        )

        items.forEach { item ->
            key(item.id) {
                val frame = Modifier
                    .offset(cellW * item.x, cellH * item.y)
                    .size(cellW * item.spanX, cellH * item.spanY)
                if (item.kind == ItemKind.WIDGET) {
                    val hidden = (drag.payload as? DragPayload.Home)?.item?.id == item.id
                    WidgetItem(
                        item = item,
                        drag = drag,
                        dragEnabled = !settings.lockLayout,
                        width = cellW * item.spanX,
                        height = cellH * item.spanY,
                        onRelease = onRelease,
                        onMissing = { onMissingWidget(item) },
                        modifier = frame.graphicsLayer { alpha = if (hidden) 0f else 1f },
                    )
                } else {
                    PlacedItem(
                        item = item,
                        appsByKey = appsByKey,
                        drag = drag,
                        lock = settings.lockLayout,
                        iconSize = iconSize,
                        showLabel = settings.showLabels,
                        onLaunch = onLaunch,
                        onOpenFolder = onOpenFolder,
                        onRelease = onRelease,
                        wind = wind,
                        modifier = frame,
                    )
                }
            }
        }
    }
}

/** App o carpeta ya colocada (escritorio o dock); se oculta mientras se la arrastra. */
@Composable
private fun PlacedItem(
    item: HomeItem,
    appsByKey: Map<String, AppEntry>,
    drag: DragController,
    lock: Boolean,
    iconSize: Dp,
    showLabel: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onOpenFolder: (HomeItem) -> Unit,
    onRelease: DragRelease,
    wind: () -> Float,
    modifier: Modifier,
) {
    val hidden = (drag.payload as? DragPayload.Home)?.item?.id == item.id
    val variation = 1f + 0.22f * (item.id % 3).toInt()
    val base = modifier.graphicsLayer {
        alpha = if (hidden) 0f else 1f
        // Cuelgan de arriba: el viento los inclina, cada uno un poco distinto.
        transformOrigin = TransformOrigin(0.5f, 0f)
        rotationZ = wind() * variation
    }
    when (item.kind) {
        ItemKind.APP -> {
            val entry = item.appKey?.let { appsByKey[it] } ?: return
            AppCell(
                entry = entry,
                iconSize = iconSize,
                showLabel = showLabel,
                modifier = base.dragSource(
                    drag = drag,
                    payload = { DragPayload.Home(item) },
                    onTap = { onLaunch(entry) },
                    onRelease = onRelease,
                    enabled = !lock,
                ),
            )
        }
        ItemKind.FOLDER -> {
            val entries = item.children.mapNotNull { appsByKey[it] }
            FolderCell(
                title = item.title,
                entries = entries,
                iconSize = iconSize,
                showLabel = showLabel,
                modifier = base.dragSource(
                    drag = drag,
                    payload = { DragPayload.Home(item) },
                    onTap = { onOpenFolder(item) },
                    onRelease = onRelease,
                    enabled = !lock,
                ),
            )
        }
        ItemKind.WIDGET -> Unit
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit, light: Boolean = false) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(if (light) Color.White.copy(alpha = 0.95f) else Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Text(
            text = stringResource(R.string.search_apps),
            color = if (light) Color(0xFF666666) else Color.White.copy(alpha = 0.85f),
        )
    }
}

@Composable
private fun PageIndicatorBar(style: PageIndicator, count: Int, state: PagerState) {
    Box(
        modifier = Modifier.fillMaxWidth().height(18.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (count > 1) {
            when (style) {
                PageIndicator.DOTS -> Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    repeat(count) { index ->
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    Color.White.copy(alpha = if (index == state.currentPage) 0.95f else 0.4f),
                                ),
                        )
                    }
                }
                PageIndicator.LINE -> {
                    val track = 72.dp
                    val segment = track / count
                    Box(
                        modifier = Modifier
                            .width(track)
                            .height(3.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.White.copy(alpha = 0.3f)),
                    ) {
                        Box(
                            modifier = Modifier
                                .offset {
                                    val position = state.currentPage + state.currentPageOffsetFraction
                                    IntOffset((position * segment.roundToPx()).roundToInt(), 0)
                                }
                                .width(segment)
                                .height(3.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.95f)),
                        )
                    }
                }
                PageIndicator.CURVE -> CurveIndicator(count = count, state = state)
                PageIndicator.NONE -> Unit
            }
        }
    }
}

/** Una curva suave, como un mechón, con una gota que se desliza por ella al cambiar de página. */
@Composable
private fun CurveIndicator(count: Int, state: PagerState) {
    val density = LocalDensity.current
    Canvas(modifier = Modifier.width(96.dp).height(18.dp)) {
        val pad = with(density) { 8.dp.toPx() }
        val amp = with(density) { 3.5.dp.toPx() }
        val width = size.width - pad * 2f
        val mid = size.height / 2f
        fun curveY(t: Float) = mid - sin(t * 2f * PI.toFloat()) * amp
        fun curveX(t: Float) = pad + t * width

        val path = Path().apply {
            moveTo(curveX(0f), curveY(0f))
            for (i in 1..40) {
                val t = i / 40f
                lineTo(curveX(t), curveY(t))
            }
        }
        drawPath(path, Color.White.copy(alpha = 0.35f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        for (page in 0 until count) {
            val t = if (count == 1) 0f else page / (count - 1f)
            drawCircle(Color.White.copy(alpha = 0.45f), radius = 2.dp.toPx(), center = Offset(curveX(t), curveY(t)))
        }
        val position = state.currentPage + state.currentPageOffsetFraction
        val t = if (count == 1) 0f else (position / (count - 1f)).coerceIn(0f, 1f)
        drawCircle(Color.White, radius = 4.dp.toPx(), center = Offset(curveX(t), curveY(t)))
    }
}

/** Franja superior que aparece al arrastrar: Quitar / Info / Desinstalar. */
@Composable
private fun TopDropZones(drag: DragController, zoneHeightPx: Float, rootWidthPx: Int) {
    val payload = drag.payload ?: return
    val pos = drag.position
    val hovered = if (pos.y < zoneHeightPx && rootWidthPx > 0) {
        (pos.x / rootWidthPx * 3).toInt().coerceIn(0, 2)
    } else {
        -1
    }
    val labels = listOf(R.string.drop_remove, R.string.drop_info, R.string.drop_uninstall)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(72.dp)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val usable = index != 0 || payload is DragPayload.Home
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (hovered == index && usable) Color.White.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.4f),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(label),
                    color = Color.White.copy(alpha = if (usable) 1f else 0.35f),
                )
            }
        }
    }
}

/** Lo que "flota" bajo el dedo mientras se arrastra. */
@Composable
private fun DragGhost(
    drag: DragController,
    appsByKey: Map<String, AppEntry>,
    iconSize: Dp,
    cellWidth: Dp,
    cellHeight: Dp,
) {
    val payload = drag.payload ?: return
    val widget = (payload as? DragPayload.Home)?.item?.takeIf { it.kind == ItemKind.WIDGET }
    val width = if (widget != null) cellWidth * widget.spanX else iconSize + 16.dp
    val height = if (widget != null) cellHeight * widget.spanY else iconSize + 16.dp

    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    (drag.position.x - width.toPx() / 2f).roundToInt(),
                    (drag.position.y - height.toPx() / 2f).roundToInt(),
                )
            }
            .size(width, height)
            .graphicsLayer {
                scaleX = 1.1f
                scaleY = 1.1f
                alpha = 0.92f
            },
        contentAlignment = Alignment.Center,
    ) {
        when {
            widget != null -> Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.3f)),
            )
            payload is DragPayload.Drawer -> AppIcon(payload.entry, iconSize)
            payload is DragPayload.FolderChild -> AppIcon(payload.entry, iconSize)
            payload is DragPayload.Home -> {
                val item = payload.item
                if (item.kind == ItemKind.FOLDER) {
                    FolderCell(
                        title = item.title,
                        entries = item.children.mapNotNull { appsByKey[it] },
                        iconSize = iconSize,
                        showLabel = false,
                    )
                } else {
                    item.appKey?.let { appsByKey[it] }?.let { AppIcon(it, iconSize) }
                }
            }
        }
    }
}

/** Menú contextual de una app, desde el escritorio o desde el cajón. */
@Composable
private fun AppSheet(
    vm: LauncherViewModel,
    entry: AppEntry,
    fromDrawer: Boolean,
    homeItem: HomeItem?,
    onAddedToDesktop: () -> Unit,
    onRename: (AppEntry) -> Unit,
    onDismiss: () -> Unit,
    radial: Boolean,
    anchor: Offset,
    rootSize: IntSize,
    onMoveToFolder: ((AppEntry) -> Unit)? = null,
    inDrawerFolder: Boolean = false,
) {
    val shortcuts = remember(entry.key) { vm.shortcutsFor(entry) }
    val addLabel = stringResource(R.string.menu_add_desktop)
    val hideLabel = stringResource(R.string.menu_hide)
    val removeLabel = stringResource(R.string.menu_remove)
    val renameLabel = stringResource(R.string.menu_rename_app)
    val infoLabel = stringResource(R.string.menu_app_info)
    val uninstallLabel = stringResource(R.string.menu_uninstall)
    val dockLabel = stringResource(R.string.menu_add_dock)
    val folderLabel = stringResource(R.string.menu_to_folder)
    val outOfFolderLabel = stringResource(R.string.menu_out_of_folder)

    val actions = buildList {
        shortcuts.forEach { shortcut ->
            val label = shortcut.shortLabel?.toString().orEmpty().ifBlank { shortcut.id }
            add(SheetAction(label) { vm.startShortcut(shortcut) })
        }
        if (fromDrawer) {
            add(SheetAction(addLabel) { if (vm.addToDesktop(entry)) onAddedToDesktop() })
            add(SheetAction(dockLabel) { if (vm.addToDock(entry)) onAddedToDesktop() })
            if (onMoveToFolder != null) add(SheetAction(folderLabel) { onMoveToFolder(entry) })
            if (inDrawerFolder) add(SheetAction(outOfFolderLabel) { vm.removeFromDrawerFolder(entry) })
            add(SheetAction(hideLabel) { vm.hideApp(entry) })
        } else if (homeItem != null) {
            if (homeItem.container == Container.DESKTOP) add(SheetAction(dockLabel) { vm.moveToDock(homeItem) })
            add(SheetAction(removeLabel) { vm.removeItem(homeItem) })
        }
        add(SheetAction(renameLabel) { onRename(entry) })
        add(SheetAction(infoLabel) { vm.showAppInfo(entry) })
        add(SheetAction(uninstallLabel, destructive = true) { vm.uninstall(entry) })
    }
    MenuHost(radial, anchor, rootSize, entry.label, actions, onDismiss)
}

/** Menú radial alrededor del dedo, o la hoja desde abajo si el radial está apagado. */
@Composable
private fun MenuHost(
    radial: Boolean,
    anchor: Offset,
    rootSize: IntSize,
    title: String,
    actions: List<SheetAction>,
    onDismiss: () -> Unit,
) {
    if (radial && rootSize.width > 0) {
        RadialMenu(anchor = anchor, rootSize = rootSize, actions = actions, onDismiss = onDismiss)
    } else {
        ActionSheet(title = title, actions = actions, onDismiss = onDismiss)
    }
}

/** Vibraciones cortas y distintas para cada gesto; se apagan desde Ajustes. */
private class Haptics(private val view: View, private val enabled: Boolean) {
    fun pick() = go(HapticFeedbackConstants.LONG_PRESS)
    fun tick() = go(HapticFeedbackConstants.CLOCK_TICK)
    fun drop() = go(
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            HapticFeedbackConstants.CONFIRM
        } else {
            HapticFeedbackConstants.CONTEXT_CLICK
        },
    )

    private fun go(kind: Int) {
        if (enabled) view.performHapticFeedback(kind)
    }
}
