# Yaal

Launcher nativo para Android (Kotlin + Jetpack Compose), sin dependencias de terceros.

## Funciones

**Escritorio y dock**
- Varias páginas (se crean solas), grilla configurable (3–6 × filas), margen, oscurecer fondo, bloquear escritorio
- Efectos de página: simple, cubo, pila de tarjetas, zoom, abanico, giro; indicador de puntos, línea o ninguno
- Fondo de pantalla que acompaña el deslizamiento; barra de búsqueda opcional arriba
- Dock opcional (3–6 apps) con tamaño de íconos y opacidad propios
- Widgets del sistema (agregar, mover, cambiar tamaño) y carpetas con columnas configurables

**Íconos**
- Formas: sistema, círculo, cuadrado redondeado, esquinas redondeadas, gota
- Packs de íconos (formato appfilter.xml de Nova/ADW/Apex), tamaño, nombres, líneas y tamaño del nombre
- Renombrar cualquier app; insignias de notificaciones (punto o número)

**Cajón de apps**
- Grilla o lista, columnas, orden (A–Z, Z–A, más usadas, recientes), grupos por categoría
- Buscador arriba o abajo, sin tildes, con búsqueda web de respaldo; índice de letras; opacidad
- Carpetas del cajón (menú de la app → "Mover a una carpeta"), buscador que se puede ocultar
- Ocultar apps; ahora lista **todas** las apps instaladas (permiso de visibilidad de paquetes)

**Gestos configurables**
- Deslizar arriba / abajo, doble toque y botón Inicio: cajón, buscar, notificaciones, ajustes rápidos,
  bloquear, recientes, menú del escritorio, ajustes o abrir una app

**Temas de un toque** (Ajustes → Temas)
- Yaal, estilo HTC Sense (siete páginas con vista Leap, reloj de tarjetas en panel, dock de tres teclas con arco, cajón con pestañas, Personalizar), estilo Xperia, estilo Gingerbread/Holo
  (cajón por páginas, dock plano) y estilo MIUI/iOS clásico; son inspirados en el estilo, sin recursos de las marcas

**Estilo Yaal**
- Viento: los íconos se inclinan y se asientan al deslizar entre páginas
- Carpetas en abanico, indicador de página en curva, cajón en arco
- Menú radial alrededor del dedo, vibraciones distintas por gesto, apertura de apps desde el ícono
- Reloj de hojas afiladas (o simple), acento tomado del fondo de pantalla, tonos cálidos de noche
- Profundidad: el escritorio se aleja y se desenfoca al abrir el cajón (desenfoque en Android 12+)

**Sistema**
- Ocultar barra de estado, permitir rotación, copia de seguridad y restauración (JSON)

Permisos opcionales que se activan desde Ajustes: acceso a notificaciones (insignias) y servicio de
accesibilidad (bloquear pantalla y recientes; no lee el contenido de la pantalla).

No incluido: desplazamiento infinito, gestos de pellizco, gestos sobre íconos, íconos personalizados por app,
widgets superpuestos, restaurar widgets desde la copia.

## Estructura

```
app/src/main/java/app/yaal/launcher/
  domain/   modelo (HomeItem) y LayoutOps: lógica pura de la grilla, con tests
  data/     apps instaladas, íconos, ajustes y persistencia del escritorio (JSON)
  widgets/  host de widgets y vista con arrastre
  ui/       LauncherRoot (pantalla), ViewModel, cajón, ajustes, menús, widgets
```

## Versiones

AGP 9.4.0 (Kotlin integrado), Gradle 9.6.0, Kotlin 2.3.20, Compose BOM 2026.08.00,
compileSdk 37, targetSdk 36, minSdk 26, JDK 17.

## Compilar

Subir `al.zip` a la raíz del repo: el workflow `.github/workflows/al.yml` lo descomprime,
corre los tests, compila el APK, lo sube como artifact y borra los artifacts anteriores.

Local: `./gradlew :app:assembleRelease`

## Firma

El APK se firma con `app/signing.keystore` (clave de uso personal incluida en el proyecto), así
cada versión nueva se instala encima de la anterior sin desinstalar.

## Dejarlo como launcher

Instalar el APK, tocar el botón Inicio y elegir "Yaal" → Siempre.
