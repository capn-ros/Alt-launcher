# AL Launcher

Launcher nativo para Android (Kotlin + Jetpack Compose), sin dependencias de terceros.

## Funciones

- Escritorio con varias páginas (se crean solas al llenarse y al arrastrar al borde)
- Dock configurable (3 a 6 apps); el dock inicial se arma con teléfono, mensajes, navegador y cámara
- Cajón de apps: deslizar hacia arriba, buscador sin tildes, índice alfabético, arrastrar al escritorio
- Carpetas: soltar una app sobre otra; renombrar, abrir y arrastrar apps afuera
- Widgets reales del sistema: selector con vista previa, enlace y configuración, mover y cambiar tamaño
- Menús al mantener apretado: atajos de la app, info, desinstalar, quitar, ocultar
- Zonas superiores al arrastrar: Quitar / Info / Desinstalar
- Perfiles (trabajo / clon) con su insignia; íconos adaptativos con la forma del sistema
- Deslizar hacia abajo abre las notificaciones
- Apps nuevas, actualizadas o desinstaladas se reflejan solas
- Ajustes: grilla, dock, tamaño de íconos, nombres, apps ocultas, bloquear escritorio, restablecer
- Botón Inicio: vuelve a la primera página y cierra todo

## Estructura

```
app/src/main/java/app/al/launcher/
  domain/   modelo (HomeItem) y LayoutOps: lógica pura de la grilla, con tests
  data/     apps instaladas, íconos, ajustes y persistencia del escritorio (JSON)
  widgets/  host de widgets y vista con arrastre
  ui/       LauncherRoot (pantalla), ViewModel, cajón, ajustes, menús, widgets
```

## Versiones

AGP 9.4.0 (Kotlin integrado), Gradle 9.6.0, Kotlin 2.3.20, Compose BOM 2026.08.00,
compileSdk 37, targetSdk 36, minSdk 26, JDK 17.

## Compilar

Subir `al.zip` a la raíz del repo: el workflow `.github/workflows/al.yml` lo descomprime,
corre los tests, compila el APK, lo sube como artifact y borra los artifacts anteriores.

Local: `./gradlew :app:assembleRelease`

## Firma

El APK se firma con `app/signing.keystore` (clave de uso personal incluida en el proyecto), así
cada versión nueva se instala encima de la anterior sin desinstalar.

## Dejarlo como launcher

Instalar el APK, tocar el botón Inicio y elegir "AL Launcher" → Siempre.
